# Changelog — Tejidos Castañeda ERP

Historial de construcción del sistema, fase por fase. El README principal
describe el estado *actual*; este archivo documenta cómo se llegó ahí,
incluyendo bugs reales encontrados y corregidos durante las pruebas.

## Fase 6 — Transferencias avanzadas y notificaciones
- Historial de transferencias con paginación (15 por página) y filtro por
  sucursal. Probado con 10 transferencias reales.
- Reporte "productos sin movimiento" filtrable por sucursal.
- Campana de notificaciones con alertas de stock bajo, filtradas a la
  sucursal del usuario, revisadas automáticamente cada 2 minutos.

## Fase 5 — Multi-sucursal: transferencias, reportes y permisos
- Transferencias de inventario entre sucursales, validando stock disponible
  antes de mover nada, dentro de una transacción atómica.
- Reportes y dashboard filtrados por sucursal (el Administrador puede ver
  todas o elegir una; el resto de roles queda limitado a la suya).
- Permisos reales por sucursal: un empleado no puede abrir caja, comprar ni
  transferir stock fuera de su propia sede (validado en el backend, no solo
  ocultado en la interfaz).
- **Bug real encontrado y corregido**: el endpoint para crear usuarios no
  leía `sucursal_id` del `req.body`, así que la sucursal asignada se perdía
  silenciosamente. Solo se detectó corriendo una prueba end-to-end real
  (crear empleado → asignar sede → loguearse → verificar), no por revisión
  de código. Corregido en `usuarioController.js`.

## Fase 4 — Multi-sucursal, ofertas y factura térmica
- Inventario multi-sucursal real: tabla `producto_stock_sucursal`, cada
  usuario/caja/venta/compra asociada a una sede, agregado global
  recalculado automáticamente.
- Ofertas automáticas por producto: el POS detecta y cobra el precio de
  oferta sin intervención manual.
- Factura para impresora térmica (formatos 58mm y 80mm) con QR incluido.
- **Bug real encontrado y corregido**: `/api/salud` quedaba bloqueado por el
  middleware de autenticación de otro router debido al orden de montaje de
  rutas en `server.js`. Se movió antes del router de catálogos.
- Todo este bloque de trabajo se validó con un entorno de prueba real fuera
  del proyecto (Node 22 + su módulo `node:sqlite` integrado) corriendo el
  flujo completo: login → producto → caja → cupón → venta → verificación de
  stock → reporte JSON y PDF real.

## Fase 3 — Excel real, impuestos y cupones en el POS
- Importador con soporte real de `.xlsx`/`.xls` (antes solo CSV), usando la
  librería `xlsx` (SheetJS).
- Impuestos aplicados automáticamente en el POS sobre la base imponible,
  desglosados en carrito y factura.
- Cupones validados (vigencia, usos, estado) y aplicados como descuento real
  en el total de la venta.
- Reportes exportables también en PDF (antes solo CSV), generados con
  `pdfkit`.

## Fase 2 — Compras, apartados, reportes e importador
- Compras a proveedores con actualización automática de stock y costo.
- Apartados (separe) con abonos parciales y saldo de cliente.
- Reportes exportables a CSV: ventas por período, más vendidos, sin
  movimiento, ganancias, inventario, clientes con saldo.
- Configuración general del negocio (nombre, logo, moneda, formato de fecha).
- Importador masivo de productos vía CSV con vista previa y detección de
  errores fila por fila.

## Fase 1 — Arquitectura base
- Autenticación JWT con contraseñas cifradas.
- Roles y permisos totalmente dinámicos y configurables desde la interfaz.
- Esquema de base de datos completo (29+ tablas) para todo el negocio.
- Productos con variantes (color/talla), precio detal/mayorista, imágenes.
- POS funcional con carrito, caja, métodos de pago y factura con doble QR.
- Dashboard, clientes, proveedores, categorías, modo claro/oscuro.

## Nota sobre la corrección de la sección de migración a MySQL/PostgreSQL
En las primeras fases se afirmó que migrar de SQLite a MySQL/PostgreSQL era
"cambiar un archivo". Eso era impreciso: `better-sqlite3` es síncrono y
`mysql2`/`pg` son asíncronos, así que el cambio real implica volver `async`
cada método de los modelos y cada controlador que los usa, además de
adaptar transacciones y la sintaxis específica del esquema. La corrección
completa y honesta de esto quedó documentada en el README principal, sección
"Migrar a otra base de datos".
