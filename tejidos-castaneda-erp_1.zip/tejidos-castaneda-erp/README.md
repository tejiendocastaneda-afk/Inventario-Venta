# Tejidos Castañeda — Sistema Contable + POS + Inventario

Sistema de gestión empresarial real para Tejidos Castañeda: punto de venta,
inventario multi-sucursal, contabilidad básica y reportes. Backend en
Node.js/Express + SQLite, frontend en HTML/CSS/JS vanilla (sin frameworks).

Todo el código fue probado de extremo a extremo con datos reales (no solo
revisado por sintaxis) — ver `CHANGELOG.md` para el detalle de cómo se
construyó cada módulo y qué bugs reales se encontraron y corrigieron en
el camino.

## Funcionalidades

**Seguridad y usuarios**
- Autenticación JWT con contraseñas cifradas (bcrypt).
- Roles y permisos totalmente dinámicos: crear, editar, eliminar y duplicar
  roles; activar/desactivar cada permiso individual desde la interfaz.
- Logs de actividad, protección CSRF/XSS básica, rate limiting.

**Ventas y caja**
- POS con búsqueda rápida por nombre/código/SKU/código de barras.
- Apertura y cierre de caja, con arqueo automático.
- Métodos de pago configurables (efectivo, transferencia, Nequi, tarjetas...).
- Cupones de descuento (porcentaje o valor fijo) validados por vigencia y usos.
- Impuestos aplicados automáticamente y desglosados en la factura.
- Ofertas automáticas por producto (precio especial detectado sin intervención).
- Apartados (separe) con abonos parciales y saldo por cliente.
- Factura con doble código QR (datos de la venta + enlace al sitio web) e
  impresión directa en formato térmico (58mm / 80mm).

**Productos e inventario**
- Productos con variantes (color/talla), precio detal/mayorista, imágenes,
  categorías, marcas y etiquetas.
- Importador masivo desde Excel (`.xlsx`/`.xls`) o CSV, con vista previa y
  detección de errores fila por fila antes de importar en firme.
- **Inventario multi-sucursal real**: cada sede tiene su propio stock;
  transferencias entre sucursales con validación de disponibilidad;
  compras y ventas descuentan/aumentan la sede correcta automáticamente.
- Alertas de stock bajo (notificaciones en la interfaz, filtradas por sede).

**Terceros y compras**
- Clientes y proveedores con CRUD completo.
- Compras a proveedores con actualización automática de inventario y costo.

**Reportes y dashboard**
- Dashboard con ventas de hoy/mes, gráfico de 7 días, productos más vendidos.
- Reportes exportables en CSV y PDF: ventas por período, más vendidos, sin
  movimiento, ganancias, inventario con valor, clientes con saldo pendiente.
- Todo filtrable por sucursal (el Administrador ve todas o elige una; el
  resto de roles queda limitado automáticamente a la suya).

**Interfaz**
- Modo claro/oscuro con persistencia.
- Diseño responsive (PC, tablet, celular).

## Instalación (en tu computador, para desarrollo)

Requiere **Node.js 18 o superior**.

```bash
cd backend
npm install
cp .env.example .env
```

Abre `.env` y cambia `JWT_SECRET` por una cadena larga y aleatoria propia
(nunca uses la de ejemplo en producción).

```bash
npm start        # o "npm run dev" si instalas nodemon (npm install -D nodemon)
```

Abre `http://localhost:4000` en el navegador. **La primera vez que arranca**,
el sistema detecta que la base de datos está vacía y crea automáticamente
los roles, permisos, la sucursal principal y el usuario administrador —
no necesitas correr ningún comando aparte. El usuario y contraseña
inicial se imprimen en la terminal (no se muestran en pantalla por
seguridad). **Cambia esa contraseña en tu primer inicio de sesión** desde
Configuración → Cambiar mi contraseña.

Si alguna vez quieres volver a sembrar los datos base manualmente (por
ejemplo, en una base de datos ya existente a la que le faltan permisos
nuevos), puedes correr `npm run seed` — es seguro, no duplica nada.

## Despliegue a producción (para que funcione 24/7, no solo en tu PC)

### Paso 1 — Subir el código a GitHub

```bash
cd tejidos-castaneda-erp
git init
git add .
git commit -m "Sistema Tejidos Castañeda ERP"
```

Crea un repositorio nuevo en GitHub (recomendado: **privado**). Luego:

```bash
git remote add origin https://github.com/TU-USUARIO/tejidos-castaneda-erp.git
git branch -M main
git push -u origin main
```

### Paso 2 — Desplegar en Railway (recomendado)

Railway es la opción más simple para este proyecto: conecta tu repo de
GitHub, detecta Node.js automáticamente, y ofrece **almacenamiento
persistente** (necesario porque este sistema usa SQLite, un archivo que
debe sobrevivir entre reinicios — no todos los hostings gratuitos lo
permiten).

1. Crea una cuenta en [railway.com](https://railway.com) y conecta tu GitHub.
2. **New Project → Deploy from GitHub repo** → elige tu repositorio.
3. En la configuración del servicio, define **Root Directory**: `backend`
   (porque el `package.json` vive ahí, no en la raíz del repo).
4. Agrega un **Volume** (almacenamiento persistente) y móntalo, por ejemplo,
   en `/data`.
5. En **Variables**, agrega:
   - `JWT_SECRET` = una cadena larga y aleatoria tuya (no la de ejemplo)
   - `DB_PATH` = `/data/tejidos_castaneda.db` (para que la base de datos
     viva dentro del volumen persistente, no se borre en cada despliegue)
   - `CORS_ORIGIN` = `*` (o el dominio exacto si luego pones uno propio)
6. Railway detecta automáticamente `npm start` como comando de arranque.
   Despliega.
7. Al primer arranque, el sistema se auto-configura solo — no necesitas
   entrar por consola a correr nada.
8. Railway te da una URL pública (algo como
   `tejidos-castaneda-erp-production.up.railway.app`) — esa es la dirección
   que usas para entrar al sistema desde cualquier navegador.

**Costo aproximado**: el plan Hobby de Railway cuesta $5 USD/mes e incluye
$5 de uso; para el volumen de Tejidos Castañeda, normalmente se mantiene
dentro de ese rango o muy cerca. Verifica el precio actual en
[railway.com/pricing](https://railway.com/pricing) porque las plataformas
cambian sus planes con frecuencia.

### Alternativa más económica (a futuro): un VPS propio

Si más adelante quieres reducir costos, un servidor privado virtual (VPS)
de unos $4-6 USD/mes (DigitalOcean, Hetzner, etc.) con Node.js, PM2 y Nginx
puede salir más barato a largo plazo, pero requiere más configuración
manual por consola (SSH, firewall, certificado SSL). Si llegas a ese
punto, te ayudo paso a paso — es una sesión aparte por lo técnico que es.

## Estructura del proyecto

```
tejidos-castaneda-erp/
├── backend/
│   ├── config/database.js      # Conexión SQLite (ver sección de migración)
│   ├── models/                 # Acceso a datos: Usuario, Rol, Producto, Venta, Caja, Compra, Sucursal
│   ├── controllers/            # Lógica de cada endpoint
│   ├── routes/                 # Definición de rutas REST
│   ├── middleware/              # auth.js, permisos.js, upload.js
│   ├── utils/seed.js            # Datos iniciales (roles, permisos, sucursal, admin)
│   ├── uploads/products/        # Fotos de productos subidas (no se versiona)
│   └── server.js
├── frontend/
│   ├── index.html
│   ├── css/                    # theme.css (variables de diseño), app.css (componentes)
│   └── js/                     # api.js, auth.js, theme.js, dashboard.js, productos.js,
│                                # pos.js, modulos-operativos.js, app.js (router)
├── database/
│   └── schema.sql               # Esquema completo, validado
├── CHANGELOG.md                 # Historial de desarrollo fase por fase
└── README.md
```

## Cómo funcionan los permisos

1. `permisos` es el catálogo maestro (ej. `productos.crear`, `caja.abrir`).
2. `rol_permisos` conecta cada rol con permisos activables/desactivables.
3. El middleware `requierePermiso('clave')` protege cada ruta sensible.
4. El rol **Administrador** siempre tiene acceso total (bandera `es_sistema`).
5. Desde *Roles y permisos* en la interfaz puedes crear roles nuevos,
   duplicar uno existente y marcar/desmarcar cada permiso con checkboxes.

## Cómo funciona el inventario multi-sucursal

- `productos.stock_total` es el **agregado global** (suma de todas las sedes).
- `producto_stock_sucursal` es la fuente de verdad **por sede**.
- Cada venta hereda la sucursal de la sesión de caja activa; cada compra y
  transferencia especifica su sucursal explícitamente.
- Un usuario no-Administrador solo puede operar (caja, compras,
  transferencias) sobre su propia sucursal — validado en el backend.

## Migrar a MySQL o PostgreSQL

Esto es más que cambiar un archivo, pero tampoco es un rediseño completo.
Así queda repartido el trabajo real:

- **Lo fácil**: cambiar el driver en `config/database.js` (de
  `better-sqlite3` a `mysql2` o `pg`).
- **Lo que realmente toma tiempo**: `better-sqlite3` es **síncrono**
  (`db.prepare().get()` devuelve el resultado de inmediato); `mysql2` y `pg`
  son **asíncronos** (basados en promesas). Cada método en `models/*.js`
  necesita volverse `async`/`await`, y cada controlador que llama a un
  modelo también.
- Las transacciones (`db.transaction(fn)`) no existen igual en esos
  drivers; se reemplazan por `BEGIN`/`COMMIT`/`ROLLBACK` manuales dentro de
  un `try/catch`.
- El esquema (`database/schema.sql`) usa `AUTOINCREMENT` y `datetime('now')`
  (sintaxis de SQLite). Para MySQL: `AUTO_INCREMENT` y `NOW()`. Para
  PostgreSQL: `SERIAL`/`GENERATED ALWAYS AS IDENTITY` y `NOW()`.
- La estructura de tablas, nombres de columnas y la lógica de negocio **no
  cambian** — es trabajo mecánico pero real, no una migración de líneas.

## Notas de dependencias

- `xss-clean` está deprecado en npm pero sigue siendo funcional; se usa para
  sanitización básica de inputs. Verás una advertencia al instalar — no es
  un error, es solo una advertencia de mantenimiento del paquete.
- `multer` está fijado en la rama 2.x (no 1.x) porque la 1.x tiene
  vulnerabilidades conocidas reportadas por npm.
