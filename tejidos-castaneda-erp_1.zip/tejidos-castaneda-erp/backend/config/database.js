/**
 * Conexión a la base de datos.
 *
 * Se usa better-sqlite3 (síncrono, rápido, ideal para POS local).
 * La capa de acceso a datos (models/) sólo usa SQL estándar y
 * parámetros posicionales "?" para que migrar a MySQL/PostgreSQL
 * en el futuro sólo implique cambiar este archivo y el driver,
 * no reescribir los modelos.
 */

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', '..', 'database', 'tejidos_castaneda.db');
const SCHEMA_PATH = path.join(__dirname, '..', '..', 'database', 'schema.sql');

const dbExists = fs.existsSync(DB_PATH);

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

if (!dbExists) {
    console.log('[DB] Base de datos no encontrada. Creando esquema inicial...');
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    db.exec(schema);
    console.log('[DB] Esquema creado en', DB_PATH);
} else {
    // Asegura que el esquema esté al día si se agregaron tablas nuevas
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    db.exec(schema);
}

module.exports = db;
