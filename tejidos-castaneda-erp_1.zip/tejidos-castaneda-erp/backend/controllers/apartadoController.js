const db = require('../config/database');

exports.listar = (req, res) => {
    const filas = db.prepare(`
        SELECT v.id, v.numero_factura, v.total, v.abono_apartado, v.creado_en,
               (v.total - v.abono_apartado) AS saldo,
               c.id AS cliente_id, c.nombre_completo AS cliente_nombre, c.telefono
        FROM ventas v
        JOIN clientes c ON c.id = v.cliente_id
        WHERE v.es_apartado = 1 AND v.estado != 'anulada'
        ORDER BY v.creado_en DESC
    `).all();
    res.json(filas);
};

exports.registrarAbono = (req, res) => {
    try {
        const { monto } = req.body;
        const venta = db.prepare('SELECT * FROM ventas WHERE id = ? AND es_apartado = 1').get(req.params.id);
        if (!venta) return res.status(404).json({ error: 'Apartado no encontrado.' });

        const saldoActual = venta.total - venta.abono_apartado;
        if (monto > saldoActual) {
            return res.status(400).json({ error: `El abono no puede superar el saldo pendiente (${saldoActual}).` });
        }

        const tx = db.transaction(() => {
            const nuevoAbono = venta.abono_apartado + monto;
            const completado = nuevoAbono >= venta.total;
            db.prepare(`
                UPDATE ventas SET abono_apartado = ?, estado = ? WHERE id = ?
            `).run(nuevoAbono, completado ? 'completada' : 'apartado', venta.id);

            db.prepare(`UPDATE clientes SET saldo_pendiente = saldo_pendiente - ? WHERE id = ?`)
                .run(monto, venta.cliente_id);

            if (venta.caja_sesion_id) {
                db.prepare(`
                    INSERT INTO caja_movimientos (caja_sesion_id, tipo, concepto, monto)
                    VALUES (?, 'ingreso', ?, ?)
                `).run(venta.caja_sesion_id, `Abono apartado ${venta.numero_factura}`, monto);
            }
        });
        tx();

        res.json({ mensaje: 'Abono registrado correctamente.' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};
