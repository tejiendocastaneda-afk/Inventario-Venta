const bcrypt = require('bcryptjs');
const Usuario = require('../models/Usuario');
const Rol = require('../models/Rol');
const { generarToken } = require('../middleware/auth');
const db = require('../config/database');

exports.login = async (req, res) => {
    try {
        const { usuario, password } = req.body;
        if (!usuario || !password) {
            return res.status(400).json({ error: 'Usuario y contraseña son requeridos.' });
        }

        const encontrado = Usuario.porUsuario(usuario);
        if (!encontrado || encontrado.activo !== 1) {
            return res.status(401).json({ error: 'Credenciales inválidas o usuario inactivo.' });
        }

        const valido = bcrypt.compareSync(password, encontrado.password_hash);
        if (!valido) {
            return res.status(401).json({ error: 'Credenciales inválidas.' });
        }

        Usuario.actualizarUltimoLogin(encontrado.id);
        const token = generarToken(encontrado);

        db.prepare(`INSERT INTO logs_actividad (usuario_id, accion, detalle, ip) VALUES (?, 'login', 'Inicio de sesión', ?)`)
            .run(encontrado.id, req.ip);

        const permisos = Rol.permisosDelRol(encontrado.rol_id).filter(p => p.activo === 1).map(p => p.clave);

        res.json({
            token,
            usuario: {
                id: encontrado.id,
                nombre_completo: encontrado.nombre_completo,
                usuario: encontrado.usuario,
                rol_id: encontrado.rol_id,
                rol_nombre: encontrado.rol_nombre,
                sucursal_id: encontrado.sucursal_id,
                sucursal_nombre: encontrado.sucursal_nombre,
                es_admin: encontrado.rol_nombre === 'Administrador'
            },
            permisos
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al iniciar sesión.' });
    }
};

exports.perfil = (req, res) => {
    const usuario = Usuario.porId(req.user.id);
    if (!usuario) return res.status(404).json({ error: 'Usuario no encontrado.' });
    const permisos = Rol.permisosDelRol(usuario.rol_id).filter(p => p.activo === 1).map(p => p.clave);
    res.json({ usuario, permisos });
};

exports.cambiarPassword = async (req, res) => {
    try {
        const { password_actual, password_nueva } = req.body;
        const usuario = Usuario.porUsuario(req.user.usuario);
        const valido = bcrypt.compareSync(password_actual, usuario.password_hash);
        if (!valido) return res.status(401).json({ error: 'Contraseña actual incorrecta.' });

        const hash = bcrypt.hashSync(password_nueva, 10);
        db.prepare('UPDATE usuarios SET password_hash = ? WHERE id = ?').run(hash, usuario.id);
        res.json({ mensaje: 'Contraseña actualizada correctamente.' });
    } catch (err) {
        res.status(500).json({ error: 'Error al cambiar la contraseña.' });
    }
};
