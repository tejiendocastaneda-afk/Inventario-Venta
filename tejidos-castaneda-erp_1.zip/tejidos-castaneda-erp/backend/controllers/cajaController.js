const Caja = require('../models/Caja');

exports.sesionActual = (req, res) => {
    const sesion = Caja.sesionAbiertaDeUsuario(req.user.id);
    res.json(sesion || null);
};

exports.abrir = (req, res) => {
    try {
        const { monto_apertura, notas, sucursal_id } = req.body;
        // Solo el Administrador puede elegir una sucursal distinta a la suya;
        // el resto de roles siempre abre caja en su sucursal asignada.
        const esAdmin = req.user.rol_nombre === 'Administrador';
        const sucursalFinal = (esAdmin && sucursal_id) ? sucursal_id : req.user.sucursal_id;
        res.status(201).json(Caja.abrir(req.user.id, monto_apertura || 0, notas, sucursalFinal));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.cerrar = (req, res) => {
    try {
        const { monto_cierre_real } = req.body;
        res.json(Caja.cerrar(req.params.id, monto_cierre_real));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.movimientos = (req, res) => {
    res.json(Caja.movimientos(req.params.id));
};

exports.registrarMovimiento = (req, res) => {
    try {
        const { tipo, concepto, monto } = req.body;
        Caja.registrarMovimiento(req.params.id, tipo, concepto, monto);
        res.status(201).json({ mensaje: 'Movimiento registrado.' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.historial = (req, res) => {
    const { pagina, por_pagina } = req.query;
    res.json(Caja.historial({ pagina: Number(pagina) || 1, por_pagina: Number(por_pagina) || 20 }));
};
