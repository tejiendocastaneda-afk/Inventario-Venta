const db = require('../config/database');

/** Fábrica genérica de CRUD simple para catálogos de una sola tabla */
function crudSimple(tabla, columnas) {
    return {
        listar: (req, res) => {
            res.json(db.prepare(`SELECT * FROM ${tabla} ORDER BY id DESC`).all());
        },
        crear: (req, res) => {
            const valores = columnas.map(c => req.body[c] ?? null);
            const placeholders = columnas.map(() => '?').join(', ');
            const info = db.prepare(`INSERT INTO ${tabla} (${columnas.join(', ')}) VALUES (${placeholders})`).run(...valores);
            res.status(201).json(db.prepare(`SELECT * FROM ${tabla} WHERE id = ?`).get(info.lastInsertRowid));
        },
        actualizar: (req, res) => {
            const sets = columnas.filter(c => req.body[c] !== undefined);
            if (!sets.length) return res.json(db.prepare(`SELECT * FROM ${tabla} WHERE id = ?`).get(req.params.id));
            const setClause = sets.map(c => `${c} = ?`).join(', ');
            const valores = sets.map(c => req.body[c]);
            valores.push(req.params.id);
            db.prepare(`UPDATE ${tabla} SET ${setClause} WHERE id = ?`).run(...valores);
            res.json(db.prepare(`SELECT * FROM ${tabla} WHERE id = ?`).get(req.params.id));
        },
        eliminar: (req, res) => {
            db.prepare(`DELETE FROM ${tabla} WHERE id = ?`).run(req.params.id);
            res.json({ mensaje: 'Eliminado correctamente.' });
        }
    };
}

module.exports = {
    categorias: crudSimple('categorias', ['nombre', 'categoria_padre_id', 'orden', 'activo']),
    marcas: crudSimple('marcas', ['nombre']),
    clientes: crudSimple('clientes', ['nombre_completo', 'documento', 'telefono', 'correo', 'direccion', 'ciudad']),
    proveedores: crudSimple('proveedores', ['nombre_empresa', 'contacto', 'telefono', 'correo', 'direccion']),
    metodosPago: crudSimple('metodos_pago', ['nombre', 'icono', 'color', 'tipo_recargo', 'valor_recargo', 'activo', 'orden']),
    impuestos: crudSimple('impuestos', ['nombre', 'porcentaje', 'activo', 'por_defecto']),
    cupones: crudSimple('cupones', ['codigo', 'tipo', 'valor', 'fecha_inicio', 'fecha_fin', 'usos_maximos', 'activo']),

    /**
     * Valida un cupón por código para usarlo en el POS: revisa que exista,
     * esté activo, dentro de fechas, y no haya agotado sus usos.
     */
    validarCupon: (req, res) => {
        const cupon = db.prepare('SELECT * FROM cupones WHERE codigo = ?').get(req.params.codigo.trim().toUpperCase());
        if (!cupon) return res.status(404).json({ error: 'Cupón no encontrado.' });
        if (!cupon.activo) return res.status(400).json({ error: 'Este cupón está desactivado.' });

        const hoy = new Date().toISOString().slice(0, 10);
        if (cupon.fecha_inicio && hoy < cupon.fecha_inicio) return res.status(400).json({ error: 'Este cupón todavía no está vigente.' });
        if (cupon.fecha_fin && hoy > cupon.fecha_fin) return res.status(400).json({ error: 'Este cupón ya venció.' });
        if (cupon.usos_maximos && cupon.usos_actuales >= cupon.usos_maximos) {
            return res.status(400).json({ error: 'Este cupón alcanzó su número máximo de usos.' });
        }

        res.json(cupon);
    }
};
