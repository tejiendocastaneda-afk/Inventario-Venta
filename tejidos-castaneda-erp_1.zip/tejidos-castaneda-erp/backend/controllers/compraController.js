const Compra = require('../models/Compra');

exports.registrar = (req, res) => {
    try {
        const { proveedor_id, sucursal_id, items } = req.body;
        if (!proveedor_id || !items || !items.length) {
            return res.status(400).json({ error: 'proveedor_id e items son requeridos.' });
        }
        const esAdmin = req.user.rol_nombre === 'Administrador';
        const sucursalFinal = (esAdmin && sucursal_id) ? sucursal_id : req.user.sucursal_id;
        const compra = Compra.registrar({ proveedor_id, usuario_id: req.user.id, sucursal_id: sucursalFinal, items });
        res.status(201).json(compra);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.obtener = (req, res) => {
    const compra = Compra.porId(req.params.id);
    if (!compra) return res.status(404).json({ error: 'Compra no encontrada.' });
    res.json(compra);
};

exports.listar = (req, res) => {
    const { pagina, por_pagina } = req.query;
    res.json(Compra.listar({ pagina: Number(pagina) || 1, por_pagina: Number(por_pagina) || 30 }));
};
