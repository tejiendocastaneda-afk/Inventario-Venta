const db = require('../config/database');

exports.resumen = (req, res) => {
    const esAdmin = req.user.rol_nombre === 'Administrador';
    const sucursalId = esAdmin ? (req.query.sucursal_id ? Number(req.query.sucursal_id) : null) : req.user.sucursal_id;
    const filtroSucursal = sucursalId ? 'AND sucursal_id = ?' : '';
    const paramSucursal = sucursalId ? [sucursalId] : [];

    const ventasHoy = db.prepare(`
        SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS cantidad
        FROM ventas WHERE date(creado_en) = date('now') AND estado = 'completada' ${filtroSucursal}
    `).get(...paramSucursal);

    const ventasMes = db.prepare(`
        SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS cantidad
        FROM ventas WHERE strftime('%Y-%m', creado_en) = strftime('%Y-%m', 'now') AND estado = 'completada' ${filtroSucursal}
    `).get(...paramSucursal);

    const productosActivos = db.prepare(`SELECT COUNT(*) AS n FROM productos WHERE estado = 'activo'`).get().n;

    const productosBajoStock = sucursalId
        ? db.prepare(`
            SELECT COUNT(*) AS n FROM productos p
            JOIN producto_stock_sucursal pss ON pss.producto_id = p.id AND pss.sucursal_id = ?
            WHERE p.estado = 'activo' AND pss.stock <= p.stock_minimo
        `).get(sucursalId).n
        : db.prepare(`SELECT COUNT(*) AS n FROM productos WHERE estado = 'activo' AND stock_total <= stock_minimo`).get().n;

    const clientesTotal = db.prepare(`SELECT COUNT(*) AS n FROM clientes`).get().n;

    const ventasUltimos7Dias = db.prepare(`
        SELECT date(creado_en) AS fecha, COALESCE(SUM(total),0) AS total
        FROM ventas
        WHERE creado_en >= date('now', '-6 days') AND estado = 'completada' ${filtroSucursal}
        GROUP BY date(creado_en)
        ORDER BY fecha
    `).all(...paramSucursal);

    const productosMasVendidos = db.prepare(`
        SELECT p.nombre, SUM(vd.cantidad) AS unidades_vendidas
        FROM venta_detalle vd
        JOIN productos p ON p.id = vd.producto_id
        JOIN ventas v ON v.id = vd.venta_id AND v.estado = 'completada' ${sucursalId ? 'AND v.sucursal_id = ?' : ''}
        GROUP BY p.id
        ORDER BY unidades_vendidas DESC
        LIMIT 5
    `).all(...paramSucursal);

    const cajaAbierta = db.prepare(`SELECT COUNT(*) AS n FROM caja_sesiones WHERE estado = 'abierta' ${filtroSucursal}`).get(...paramSucursal).n;

    res.json({
        ventas_hoy: ventasHoy,
        ventas_mes: ventasMes,
        productos_activos: productosActivos,
        productos_bajo_stock: productosBajoStock,
        clientes_total: clientesTotal,
        ventas_ultimos_7_dias: ventasUltimos7Dias,
        productos_mas_vendidos: productosMasVendidos,
        cajas_abiertas: cajaAbierta,
        sucursal_filtrada: sucursalId
    });
};
