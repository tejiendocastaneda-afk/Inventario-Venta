const db = require('../config/database');
const XLSX = require('xlsx');
const path = require('path');

/** Parser CSV simple (soporta comillas y comas dentro de campos) */
function parsearCSV(texto) {
    const filas = [];
    let fila = [], campo = '', dentroComillas = false;
    const limpio = texto.replace(/^\uFEFF/, '');

    for (let i = 0; i < limpio.length; i++) {
        const c = limpio[i];
        if (dentroComillas) {
            if (c === '"' && limpio[i + 1] === '"') { campo += '"'; i++; }
            else if (c === '"') dentroComillas = false;
            else campo += c;
        } else {
            if (c === '"') dentroComillas = true;
            else if (c === ',') { fila.push(campo); campo = ''; }
            else if (c === '\n' || c === '\r') {
                if (c === '\r' && limpio[i + 1] === '\n') i++;
                fila.push(campo); campo = '';
                if (fila.some(v => v !== '')) filas.push(fila);
                fila = [];
            } else campo += c;
        }
    }
    if (campo !== '' || fila.length) { fila.push(campo); filas.push(fila); }
    return filas;
}

/** Convierte un archivo Excel (.xlsx/.xls) a la misma estructura de filas [][] que produce parsearCSV */
function parsearExcel(buffer) {
    const libro = XLSX.read(buffer, { type: 'buffer' });
    const primeraHoja = libro.SheetNames[0];
    const hoja = libro.Sheets[primeraHoja];
    // header:1 => devuelve array de arrays (misma forma que el parser CSV), raw:false => valores como texto/número simple
    const filas = XLSX.utils.sheet_to_json(hoja, { header: 1, defval: '', raw: false });
    return filas.map(fila => fila.map(celda => String(celda ?? '').trim()));
}

/** Detecta el tipo de archivo por extensión y devuelve las filas ya parseadas */
function extraerFilas(archivo) {
    const ext = path.extname(archivo.originalname).toLowerCase();
    if (ext === '.csv') {
        return parsearCSV(archivo.buffer.toString('utf8'));
    }
    if (ext === '.xlsx' || ext === '.xls') {
        return parsearExcel(archivo.buffer);
    }
    throw new Error('Formato de archivo no soportado. Usa .csv, .xlsx o .xls');
}

const COLUMNAS_ESPERADAS = ['nombre', 'codigo', 'precio_detal', 'precio_mayorista', 'costo', 'stock_total', 'categoria', 'descripcion'];

/**
 * Vista previa: valida el archivo (CSV o Excel) y devuelve filas con errores
 * marcados, SIN escribir en la base de datos todavía.
 */
exports.previsualizar = (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ error: 'No se recibió ningún archivo.' });
        const filas = extraerFilas(req.file);
        if (!filas.length) return res.status(400).json({ error: 'El archivo está vacío.' });

        const encabezado = filas[0].map(h => h.trim().toLowerCase());
        const columnasFaltantes = ['nombre', 'precio_detal'].filter(c => !encabezado.includes(c));
        if (columnasFaltantes.length) {
            return res.status(400).json({ error: `Faltan columnas obligatorias: ${columnasFaltantes.join(', ')}` });
        }

        const filasDatos = filas.slice(1);
        const resultado = filasDatos.map((valores, i) => {
            const registro = {};
            encabezado.forEach((col, idx) => registro[col] = (valores[idx] || '').trim());

            const errores = [];
            if (!registro.nombre) errores.push('Nombre vacío');
            if (registro.precio_detal && isNaN(Number(registro.precio_detal))) errores.push('Precio detal no numérico');
            if (registro.precio_mayorista && isNaN(Number(registro.precio_mayorista))) errores.push('Precio mayorista no numérico');
            if (registro.stock_total && isNaN(Number(registro.stock_total))) errores.push('Stock no numérico');
            if (registro.codigo) {
                const existente = db.prepare('SELECT id FROM productos WHERE codigo = ?').get(registro.codigo);
                if (existente) registro._accion = 'actualizar';
                else registro._accion = 'crear';
            } else {
                registro._accion = 'crear';
            }

            return { fila: i + 2, ...registro, _errores: errores };
        });

        const validas = resultado.filter(r => r._errores.length === 0);
        const invalidas = resultado.filter(r => r._errores.length > 0);

        res.json({
            total: resultado.length,
            validas: validas.length,
            invalidas: invalidas.length,
            columnas_detectadas: encabezado,
            filas: resultado.slice(0, 500) // preview limitado, la importación real procesa todo
        });
    } catch (err) {
        res.status(400).json({ error: `Error al leer el archivo: ${err.message}` });
    }
};

/**
 * Importación real: crea o actualiza productos en bloque dentro de una
 * transacción. Sólo importa las filas sin errores. Acepta CSV y Excel.
 */
exports.importar = (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ error: 'No se recibió ningún archivo.' });
        const filas = extraerFilas(req.file);
        const encabezado = filas[0].map(h => h.trim().toLowerCase());
        const filasDatos = filas.slice(1);

        let creados = 0, actualizados = 0, omitidos = 0;

        const buscarCategoria = db.prepare('SELECT id FROM categorias WHERE nombre = ?');
        const crearCategoria = db.prepare('INSERT INTO categorias (nombre) VALUES (?)');
        const buscarProducto = db.prepare('SELECT id FROM productos WHERE codigo = ?');
        const crearProducto = db.prepare(`
            INSERT INTO productos (nombre, codigo, precio_detal, precio_mayorista, costo, stock_total, categoria_id, descripcion)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);
        const actualizarProducto = db.prepare(`
            UPDATE productos SET nombre = ?, precio_detal = ?, precio_mayorista = ?, costo = ?, stock_total = ?, categoria_id = ?, descripcion = ?, actualizado_en = datetime('now')
            WHERE codigo = ?
        `);

        const tx = db.transaction(() => {
            for (const valores of filasDatos) {
                const registro = {};
                encabezado.forEach((col, idx) => registro[col] = (valores[idx] || '').trim());

                if (!registro.nombre || (registro.precio_detal && isNaN(Number(registro.precio_detal)))) {
                    omitidos++;
                    continue;
                }

                let categoriaId = null;
                if (registro.categoria) {
                    let cat = buscarCategoria.get(registro.categoria);
                    if (!cat) { const info = crearCategoria.run(registro.categoria); categoriaId = info.lastInsertRowid; }
                    else categoriaId = cat.id;
                }

                const datosComunes = [
                    registro.nombre,
                    Number(registro.precio_detal) || 0,
                    Number(registro.precio_mayorista) || 0,
                    Number(registro.costo) || 0,
                    Number(registro.stock_total) || 0,
                    categoriaId,
                    registro.descripcion || null
                ];

                const existente = registro.codigo ? buscarProducto.get(registro.codigo) : null;
                if (existente) {
                    actualizarProducto.run(...datosComunes, registro.codigo);
                    actualizados++;
                } else {
                    crearProducto.run(datosComunes[0], registro.codigo || null, datosComunes[1], datosComunes[2], datosComunes[3], datosComunes[4], datosComunes[5], datosComunes[6]);
                    creados++;
                }
            }
        });
        tx();

        res.json({ mensaje: 'Importación completada.', creados, actualizados, omitidos });
    } catch (err) {
        res.status(400).json({ error: `Error al importar: ${err.message}` });
    }
};

