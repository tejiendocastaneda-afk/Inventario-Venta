const db = require('../config/database');

/**
 * Devuelve los productos cuyo stock está en o por debajo del mínimo
 * configurado, en la sucursal del usuario (o en todas si es Administrador
 * y no especifica una sucursal).
 */
exports.stockBajo = (req, res) => {
    const esAdmin = req.user.rol_nombre === 'Administrador';
    const sucursalId = esAdmin ? (req.query.sucursal_id ? Number(req.query.sucursal_id) : null) : req.user.sucursal_id;

    const filas = sucursalId
        ? db.prepare(`
            SELECT p.id, p.codigo, p.nombre, COALESCE(pss.stock, 0) AS stock, p.stock_minimo, s.nombre AS sucursal_nombre
            FROM productos p
            JOIN producto_stock_sucursal pss ON pss.producto_id = p.id AND pss.sucursal_id = ?
            JOIN sucursales s ON s.id = ?
            WHERE p.estado = 'activo' AND pss.stock <= p.stock_minimo
            ORDER BY pss.stock ASC
        `).all(sucursalId, sucursalId)
        : db.prepare(`
            SELECT p.id, p.codigo, p.nombre, p.stock_total AS stock, p.stock_minimo, NULL AS sucursal_nombre
            FROM productos p
            WHERE p.estado = 'activo' AND p.stock_total <= p.stock_minimo
            ORDER BY p.stock_total ASC
        `).all();

    res.json(filas);
};
