const Producto = require('../models/Producto');
const Sucursal = require('../models/Sucursal');

exports.buscar = (req, res) => {
    const { q, categoria_id, marca_id, estado, en_oferta, pagina, por_pagina } = req.query;
    res.json(Producto.buscar({
        q, categoria_id, marca_id, estado, en_oferta,
        pagina: Number(pagina) || 1,
        por_pagina: Number(por_pagina) || 24
    }));
};

exports.obtener = (req, res) => {
    const producto = Producto.porId(req.params.id);
    if (!producto) return res.status(404).json({ error: 'Producto no encontrado.' });
    res.json(producto);
};

exports.buscarPorCodigo = (req, res) => {
    const producto = Producto.porCodigoOBarras(req.params.codigo);
    if (!producto) return res.status(404).json({ error: 'Producto no encontrado.' });
    res.json(producto);
};

exports.crear = (req, res) => {
    try {
        if (!req.body.nombre) return res.status(400).json({ error: 'El nombre es requerido.' });
        const producto = Producto.crear(req.body);

        // El stock inicial se asigna a la sucursal del usuario que crea el producto
        // (o a la primera sucursal activa disponible si no tiene una asignada).
        const sucursalId = req.user.sucursal_id || Sucursal.listar().find(s => s.activo)?.id;
        if (sucursalId && producto.stock_total > 0) {
            Sucursal.inicializarStock(producto.id, sucursalId, producto.stock_total);
        }

        res.status(201).json(producto);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.actualizar = (req, res) => {
    try {
        const producto = Producto.actualizar(req.params.id, req.body);
        if (!producto) return res.status(404).json({ error: 'Producto no encontrado.' });
        res.json(producto);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.eliminar = (req, res) => {
    Producto.eliminar(req.params.id);
    res.json({ mensaje: 'Producto eliminado.' });
};

exports.agregarVariante = (req, res) => {
    try {
        res.status(201).json(Producto.agregarVariante(req.params.id, req.body));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.subirImagenes = (req, res) => {
    try {
        const archivos = req.files || [];
        if (!archivos.length) return res.status(400).json({ error: 'No se recibieron imágenes.' });

        const imagenes = archivos.map((archivo, i) => {
            const url = `/uploads/products/${archivo.filename}`;
            return Producto.agregarImagen(req.params.id, url, i === 0 && req.body.es_principal === 'true');
        });
        res.status(201).json(imagenes);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.eliminarImagen = (req, res) => {
    Producto.eliminarImagen(req.params.imagenId);
    res.json({ mensaje: 'Imagen eliminada.' });
};
