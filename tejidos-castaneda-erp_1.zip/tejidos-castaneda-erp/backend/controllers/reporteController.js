const db = require('../config/database');
const PDFDocument = require('pdfkit');

/** Convierte un array de objetos a texto CSV (delimitado por coma, UTF-8 con BOM para Excel) */
function aCSV(filas) {
    if (!filas.length) return '\uFEFF';
    const columnas = Object.keys(filas[0]);
    const escapar = (v) => {
        if (v === null || v === undefined) return '';
        const s = String(v).replace(/"/g, '""');
        return /[",\n]/.test(s) ? `"${s}"` : s;
    };
    const encabezado = columnas.join(',');
    const cuerpo = filas.map(f => columnas.map(c => escapar(f[c])).join(',')).join('\n');
    return '\uFEFF' + encabezado + '\n' + cuerpo;
}

function responderCSV(res, nombreArchivo, filas) {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${nombreArchivo}"`);
    res.send(aCSV(filas));
}

/**
 * Genera un PDF tabular simple (encabezado + filas paginadas automáticamente
 * por pdfkit) y lo transmite directo a la respuesta HTTP.
 */
function responderPDF(res, nombreArchivo, titulo, filas) {
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${nombreArchivo}"`);

    const doc = new PDFDocument({ margin: 40, size: 'A4' });
    doc.pipe(res);

    doc.fontSize(16).fillColor('#1b2a4a').text('Tejidos Castañeda', { continued: false });
    doc.fontSize(11).fillColor('#666').text(titulo);
    doc.moveDown(0.6);
    doc.fontSize(9).fillColor('#999').text(`Generado el ${new Date().toLocaleString('es-CO')}`);
    doc.moveDown(1);

    if (!filas.length) {
        doc.fontSize(11).fillColor('#333').text('No hay datos disponibles para este reporte.');
        doc.end();
        return;
    }

    const columnas = Object.keys(filas[0]);
    const anchoDisponible = doc.page.width - doc.page.margins.left - doc.page.margins.right;
    const anchoColumna = anchoDisponible / columnas.length;
    const alturaFila = 20;

    function dibujarEncabezado(y) {
        doc.fontSize(8.5).fillColor('#fff');
        doc.rect(doc.page.margins.left, y, anchoDisponible, alturaFila).fill('#1b2a4a');
        doc.fillColor('#fff');
        columnas.forEach((col, i) => {
            doc.text(col.replace(/_/g, ' ').toUpperCase(), doc.page.margins.left + i * anchoColumna + 4, y + 6, { width: anchoColumna - 6 });
        });
    }

    let y = doc.y;
    dibujarEncabezado(y);
    y += alturaFila;

    filas.forEach((fila, idx) => {
        if (y + alturaFila > doc.page.height - doc.page.margins.bottom) {
            doc.addPage();
            y = doc.page.margins.top;
            dibujarEncabezado(y);
            y += alturaFila;
        }
        if (idx % 2 === 0) {
            doc.rect(doc.page.margins.left, y, anchoDisponible, alturaFila).fill('#f7f5f1');
        }
        doc.fontSize(8).fillColor('#26241d');
        columnas.forEach((col, i) => {
            const valor = fila[col] === null || fila[col] === undefined ? '' : String(fila[col]);
            doc.text(valor, doc.page.margins.left + i * anchoColumna + 4, y + 6, { width: anchoColumna - 6, ellipsis: true });
        });
        y += alturaFila;
    });

    doc.end();
}

/** Envía la respuesta en el formato solicitado (json | csv | pdf) */
function responder(req, res, { nombreArchivo, titulo, filas }) {
    const formato = req.query.formato_salida;
    if (formato === 'csv') return responderCSV(res, nombreArchivo.replace(/\.pdf$/, '.csv'), filas);
    if (formato === 'pdf') return responderPDF(res, nombreArchivo.replace(/\.csv$/, '.pdf'), titulo, filas);
    res.json(filas);
}

/**
 * Resuelve por cuál sucursal filtrar un reporte:
 * - Administrador: puede pedir cualquier sucursal vía ?sucursal_id=, o ver
 *   todas las sedes si no manda el parámetro (retorna null = sin filtro).
 * - Cualquier otro rol: siempre queda limitado a su propia sucursal,
 *   sin importar qué parámetro mande en la URL.
 */
function resolverSucursalFiltro(req) {
    const esAdmin = req.user.rol_nombre === 'Administrador';
    if (esAdmin) {
        return req.query.sucursal_id ? Number(req.query.sucursal_id) : null;
    }
    return req.user.sucursal_id || null;
}

exports.ventasPorPeriodo = (req, res) => {
    const { agrupar = 'dia', desde, hasta } = req.query;
    const formatos = { dia: '%Y-%m-%d', semana: '%Y-%W', mes: '%Y-%m', anio: '%Y' };
    const formato = formatos[agrupar] || formatos.dia;
    const sucursalId = resolverSucursalFiltro(req);

    const condiciones = ["estado = 'completada'"];
    const valores = [];
    if (desde) { condiciones.push('date(creado_en) >= date(?)'); valores.push(desde); }
    if (hasta) { condiciones.push('date(creado_en) <= date(?)'); valores.push(hasta); }
    if (sucursalId) { condiciones.push('sucursal_id = ?'); valores.push(sucursalId); }

    const filas = db.prepare(`
        SELECT strftime('${formato}', creado_en) AS periodo,
               COUNT(*) AS cantidad_ventas,
               SUM(total) AS total_ventas,
               SUM(subtotal) AS subtotal,
               SUM(descuento_total) AS descuentos
        FROM ventas
        WHERE ${condiciones.join(' AND ')}
        GROUP BY periodo
        ORDER BY periodo
    `).all(...valores);

    responder(req, res, { nombreArchivo: 'ventas_por_periodo.csv', titulo: 'Ventas por período', filas });
};

exports.productosMasVendidos = (req, res) => {
    const sucursalId = resolverSucursalFiltro(req);
    const condicionSucursal = sucursalId ? 'AND v.sucursal_id = ?' : '';
    const valores = sucursalId ? [sucursalId] : [];

    const filas = db.prepare(`
        SELECT p.nombre, p.codigo, SUM(vd.cantidad) AS unidades_vendidas, SUM(vd.subtotal) AS total_generado
        FROM venta_detalle vd
        JOIN productos p ON p.id = vd.producto_id
        JOIN ventas v ON v.id = vd.venta_id AND v.estado = 'completada' ${condicionSucursal}
        GROUP BY p.id
        ORDER BY unidades_vendidas DESC
        LIMIT 50
    `).all(...valores);
    responder(req, res, { nombreArchivo: 'productos_mas_vendidos.csv', titulo: 'Productos más vendidos', filas });
};

exports.productosSinMovimiento = (req, res) => {
    const sucursalId = resolverSucursalFiltro(req);

    const filas = sucursalId
        ? db.prepare(`
            SELECT p.nombre, p.codigo, COALESCE(pss.stock, 0) AS stock, p.actualizado_en
            FROM productos p
            LEFT JOIN producto_stock_sucursal pss ON pss.producto_id = p.id AND pss.sucursal_id = ?
            WHERE p.estado = 'activo'
            AND p.id NOT IN (
                SELECT DISTINCT vd.producto_id FROM venta_detalle vd
                JOIN ventas v ON v.id = vd.venta_id AND v.sucursal_id = ?
            )
            ORDER BY p.actualizado_en ASC
        `).all(sucursalId, sucursalId)
        : db.prepare(`
            SELECT p.nombre, p.codigo, p.stock_total AS stock, p.actualizado_en
            FROM productos p
            WHERE p.id NOT IN (SELECT DISTINCT producto_id FROM venta_detalle)
            AND p.estado = 'activo'
            ORDER BY p.actualizado_en ASC
        `).all();

    responder(req, res, { nombreArchivo: 'productos_sin_movimiento.csv', titulo: 'Productos sin movimiento', filas });
};

exports.gananciasPeriodo = (req, res) => {
    const { desde, hasta } = req.query;
    const sucursalId = resolverSucursalFiltro(req);
    const condiciones = ["v.estado = 'completada'"];
    const valores = [];
    if (desde) { condiciones.push('date(v.creado_en) >= date(?)'); valores.push(desde); }
    if (hasta) { condiciones.push('date(v.creado_en) <= date(?)'); valores.push(hasta); }
    if (sucursalId) { condiciones.push('v.sucursal_id = ?'); valores.push(sucursalId); }

    const filas = db.prepare(`
        SELECT date(v.creado_en) AS fecha,
               SUM(vd.subtotal) AS ingresos,
               SUM(vd.cantidad * p.costo) AS costos,
               SUM(vd.subtotal) - SUM(vd.cantidad * p.costo) AS ganancia
        FROM venta_detalle vd
        JOIN ventas v ON v.id = vd.venta_id
        JOIN productos p ON p.id = vd.producto_id
        WHERE ${condiciones.join(' AND ')}
        GROUP BY fecha
        ORDER BY fecha
    `).all(...valores);

    responder(req, res, { nombreArchivo: 'ganancias_periodo.csv', titulo: 'Ganancias por período', filas });
};

exports.inventarioActual = (req, res) => {
    const sucursalId = resolverSucursalFiltro(req);

    const filas = sucursalId
        ? db.prepare(`
            SELECT p.codigo, p.nombre, c.nombre AS categoria, COALESCE(pss.stock, 0) AS stock, p.stock_minimo,
                   p.precio_detal, p.precio_mayorista, p.costo,
                   (COALESCE(pss.stock, 0) * p.costo) AS valor_inventario
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            LEFT JOIN producto_stock_sucursal pss ON pss.producto_id = p.id AND pss.sucursal_id = ?
            ORDER BY p.nombre
        `).all(sucursalId)
        : db.prepare(`
            SELECT p.codigo, p.nombre, c.nombre AS categoria, p.stock_total AS stock, p.stock_minimo,
                   p.precio_detal, p.precio_mayorista, p.costo,
                   (p.stock_total * p.costo) AS valor_inventario
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            ORDER BY p.nombre
        `).all();

    responder(req, res, { nombreArchivo: 'inventario_actual.csv', titulo: 'Inventario actual', filas });
};

exports.clientesConSaldo = (req, res) => {
    const filas = db.prepare(`
        SELECT nombre_completo, documento, telefono, saldo_pendiente
        FROM clientes WHERE saldo_pendiente > 0
        ORDER BY saldo_pendiente DESC
    `).all();
    responder(req, res, { nombreArchivo: 'clientes_saldo_pendiente.csv', titulo: 'Clientes con saldo pendiente', filas });
};
