const Rol = require('../models/Rol');

exports.listar = (req, res) => {
    res.json(Rol.listarTodos());
};

exports.crear = (req, res) => {
    try {
        const { nombre, descripcion } = req.body;
        if (!nombre) return res.status(400).json({ error: 'El nombre del rol es requerido.' });
        res.status(201).json(Rol.crear({ nombre, descripcion }));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.editar = (req, res) => {
    try {
        const { nombre, descripcion } = req.body;
        res.json(Rol.editar(req.params.id, { nombre, descripcion }));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.eliminar = (req, res) => {
    try {
        Rol.eliminar(req.params.id);
        res.json({ mensaje: 'Rol eliminado.' });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.duplicar = (req, res) => {
    try {
        const { nuevo_nombre } = req.body;
        res.status(201).json(Rol.duplicar(req.params.id, nuevo_nombre));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.permisosDelRol = (req, res) => {
    res.json(Rol.permisosDelRol(req.params.id));
};

exports.actualizarPermisos = (req, res) => {
    try {
        const { permisos } = req.body; // [{ permiso_id, activo }]
        res.json(Rol.asignarPermisosMasivo(req.params.id, permisos));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.listarCatalogoPermisos = (req, res) => {
    res.json(Rol.listarPermisosMaestro());
};
