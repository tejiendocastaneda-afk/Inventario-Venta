const Sucursal = require('../models/Sucursal');

exports.listar = (req, res) => {
    res.json(Sucursal.listar());
};

exports.crear = (req, res) => {
    try {
        if (!req.body.nombre) return res.status(400).json({ error: 'El nombre de la sucursal es requerido.' });
        res.status(201).json(Sucursal.crear(req.body));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.actualizar = (req, res) => {
    try {
        res.json(Sucursal.actualizar(req.params.id, req.body));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.eliminar = (req, res) => {
    try {
        Sucursal.eliminar(req.params.id);
        res.json({ mensaje: 'Sucursal eliminada.' });
    } catch (err) {
        res.status(400).json({ error: 'No se puede eliminar: revisa que no tenga ventas, compras o usuarios asociados.' });
    }
};

exports.stockPorProducto = (req, res) => {
    res.json(Sucursal.stockPorProducto(req.params.productoId));
};

exports.transferirStock = (req, res) => {
    try {
        const { producto_id, sucursal_origen_id, sucursal_destino_id, cantidad, notas } = req.body;
        if (!producto_id || !sucursal_origen_id || !sucursal_destino_id || !cantidad) {
            return res.status(400).json({ error: 'producto_id, sucursal_origen_id, sucursal_destino_id y cantidad son requeridos.' });
        }

        const esAdmin = req.user.rol_nombre === 'Administrador';
        if (!esAdmin && Number(sucursal_origen_id) !== req.user.sucursal_id) {
            return res.status(403).json({ error: 'Solo puedes transferir stock desde tu propia sucursal.' });
        }

        const resultado = Sucursal.transferirStock({
            producto_id, sucursal_origen_id, sucursal_destino_id,
            cantidad: Number(cantidad), usuario_id: req.user.id, notas
        });
        res.status(201).json(resultado);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.listarTransferencias = (req, res) => {
    const { producto_id, sucursal_id, pagina, por_pagina } = req.query;
    res.json(Sucursal.listarTransferencias({
        producto_id, sucursal_id,
        pagina: Number(pagina) || 1,
        por_pagina: Number(por_pagina) || 20
    }));
};
