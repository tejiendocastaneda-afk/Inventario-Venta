const bcrypt = require('bcryptjs');
const Usuario = require('../models/Usuario');

exports.listar = (req, res) => {
    res.json(Usuario.listar());
};

exports.crear = (req, res) => {
    try {
        const { nombre_completo, usuario, correo, password, rol_id, telefono, sucursal_id } = req.body;
        if (!nombre_completo || !usuario || !password || !rol_id) {
            return res.status(400).json({ error: 'nombre_completo, usuario, password y rol_id son requeridos.' });
        }
        const password_hash = bcrypt.hashSync(password, 10);
        res.status(201).json(Usuario.crear({ nombre_completo, usuario, correo, password_hash, rol_id, telefono, sucursal_id }));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.actualizar = (req, res) => {
    try {
        res.json(Usuario.actualizar(req.params.id, req.body));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};

exports.eliminar = (req, res) => {
    Usuario.eliminar(req.params.id);
    res.json({ mensaje: 'Usuario eliminado.' });
};
