const Venta = require('../models/Venta');
const QRCode = require('qrcode');

exports.registrar = async (req, res) => {
    try {
        const { cliente_id, caja_sesion_id, items, pagos, tipo_precio, descuento_total, impuesto_total, cupon_id, es_apartado, abono_apartado } = req.body;

        if (!items || !items.length) {
            return res.status(400).json({ error: 'La venta debe tener al menos un producto.' });
        }

        const venta = Venta.registrar({
            cliente_id, usuario_id: req.user.id, caja_sesion_id, items, pagos,
            tipo_precio, descuento_total, impuesto_total, cupon_id, es_apartado, abono_apartado
        });

        // QR 1: datos completos de la factura. QR 2: enlace a la web oficial.
        const datosFactura = JSON.stringify({
            factura: venta.numero_factura,
            total: venta.total,
            fecha: venta.creado_en,
            vendedor: venta.vendedor_nombre
        });
        const qrFactura = await QRCode.toDataURL(datosFactura);
        const qrSitioWeb = await QRCode.toDataURL(process.env.SITIO_WEB_URL || 'https://tejidoscastaneda.com');

        res.status(201).json({ ...venta, qr_factura: qrFactura, qr_sitio_web: qrSitioWeb });
    } catch (err) {
        console.error(err);
        res.status(400).json({ error: err.message });
    }
};

exports.obtener = (req, res) => {
    const venta = Venta.porId(req.params.id);
    if (!venta) return res.status(404).json({ error: 'Venta no encontrada.' });
    res.json(venta);
};

exports.listar = (req, res) => {
    const { desde, hasta, estado, pagina, por_pagina } = req.query;
    res.json(Venta.listar({ desde, hasta, estado, pagina: Number(pagina) || 1, por_pagina: Number(por_pagina) || 30 }));
};

exports.anular = (req, res) => {
    try {
        res.json(Venta.anular(req.params.id));
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
};
