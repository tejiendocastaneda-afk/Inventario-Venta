const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'cambia-esta-clave-en-produccion';

/**
 * Verifica el token JWT enviado en el header Authorization: Bearer <token>
 * Adjunta el usuario decodificado (id, usuario, rol_id, rol) a req.user
 */
function autenticar(req, res, next) {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;

    if (!token) {
        return res.status(401).json({ error: 'No autenticado. Token requerido.' });
    }

    try {
        const payload = jwt.verify(token, JWT_SECRET);
        req.user = payload;
        next();
    } catch (err) {
        return res.status(401).json({ error: 'Token inválido o expirado.' });
    }
}

function generarToken(usuario) {
    return jwt.sign(
        {
            id: usuario.id,
            usuario: usuario.usuario,
            nombre_completo: usuario.nombre_completo,
            rol_id: usuario.rol_id,
            rol_nombre: usuario.rol_nombre,
            sucursal_id: usuario.sucursal_id
        },
        JWT_SECRET,
        { expiresIn: '12h' }
    );
}

module.exports = { autenticar, generarToken, JWT_SECRET };
