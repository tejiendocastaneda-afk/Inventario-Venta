const db = require('../config/database');

/**
 * Verifica si el rol del usuario autenticado tiene un permiso activo.
 * Uso: router.post('/productos', autenticar, requierePermiso('productos.crear'), controlador)
 *
 * El administrador de sistema (rol es_sistema = 1 con nombre 'Administrador')
 * tiene acceso total sin necesidad de permisos individuales.
 */
function requierePermiso(clavePermiso) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({ error: 'No autenticado.' });
        }

        const rol = db.prepare('SELECT * FROM roles WHERE id = ?').get(req.user.rol_id);
        if (!rol) {
            return res.status(403).json({ error: 'Rol no válido.' });
        }

        if (rol.es_sistema === 1 && rol.nombre === 'Administrador') {
            return next(); // acceso total
        }

        const permiso = db.prepare(`
            SELECT rp.activo
            FROM rol_permisos rp
            JOIN permisos p ON p.id = rp.permiso_id
            WHERE rp.rol_id = ? AND p.clave = ?
        `).get(req.user.rol_id, clavePermiso);

        if (!permiso || permiso.activo !== 1) {
            return res.status(403).json({ error: `No tienes permiso para: ${clavePermiso}` });
        }

        next();
    };
}

module.exports = { requierePermiso };
