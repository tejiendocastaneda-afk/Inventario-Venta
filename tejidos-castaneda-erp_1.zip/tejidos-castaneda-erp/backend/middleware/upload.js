const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '..', 'uploads', 'products'));
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        cb(null, `${uuidv4()}${ext}`);
    }
});

function filtroImagenes(req, file, cb) {
    const permitidos = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (permitidos.includes(ext)) cb(null, true);
    else cb(new Error('Formato de imagen no permitido.'));
}

const upload = multer({
    storage,
    fileFilter: filtroImagenes,
    limits: { fileSize: 8 * 1024 * 1024, files: 10 } // 8MB por imagen, hasta 10 a la vez
});

/** Subida en memoria para archivos CSV/Excel de importación (no se guardan en disco) */
const uploadMemoria = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 25 * 1024 * 1024 }, // 25MB, suficiente para catálogos grandes en CSV
    fileFilter: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        if (['.csv', '.xlsx', '.xls'].includes(ext)) cb(null, true);
        else cb(new Error('Formato no soportado. Usa .csv, .xlsx o .xls'));
    }
});

module.exports = upload;
module.exports.uploadMemoria = uploadMemoria;

