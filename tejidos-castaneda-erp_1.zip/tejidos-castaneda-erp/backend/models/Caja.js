const db = require('../config/database');

const Caja = {
    sesionAbiertaDeUsuario(usuarioId) {
        return db.prepare(`
            SELECT cs.*, s.nombre AS sucursal_nombre
            FROM caja_sesiones cs LEFT JOIN sucursales s ON s.id = cs.sucursal_id
            WHERE cs.usuario_id = ? AND cs.estado = 'abierta'
        `).get(usuarioId);
    },

    abrir(usuarioId, montoApertura, notas, sucursalId) {
        const existente = this.sesionAbiertaDeUsuario(usuarioId);
        if (existente) throw new Error('Ya existe una sesión de caja abierta para este usuario.');
        const info = db.prepare(`
            INSERT INTO caja_sesiones (usuario_id, monto_apertura, notas, sucursal_id) VALUES (?, ?, ?, ?)
        `).run(usuarioId, montoApertura, notas || null, sucursalId || null);
        return db.prepare('SELECT * FROM caja_sesiones WHERE id = ?').get(info.lastInsertRowid);
    },

    cerrar(sesionId, montoCierreReal) {
        const sesion = db.prepare('SELECT * FROM caja_sesiones WHERE id = ?').get(sesionId);
        if (!sesion) throw new Error('Sesión de caja no encontrada.');

        const { total: totalMovimientos } = db.prepare(`
            SELECT COALESCE(SUM(monto), 0) AS total FROM caja_movimientos WHERE caja_sesion_id = ?
        `).get(sesionId);

        const montoEsperado = sesion.monto_apertura + totalMovimientos;
        const diferencia = montoCierreReal - montoEsperado;

        db.prepare(`
            UPDATE caja_sesiones
            SET estado = 'cerrada', monto_cierre_esperado = ?, monto_cierre_real = ?, diferencia = ?, cerrada_en = datetime('now')
            WHERE id = ?
        `).run(montoEsperado, montoCierreReal, diferencia, sesionId);

        return db.prepare('SELECT * FROM caja_sesiones WHERE id = ?').get(sesionId);
    },

    movimientos(sesionId) {
        return db.prepare('SELECT * FROM caja_movimientos WHERE caja_sesion_id = ? ORDER BY creado_en').all(sesionId);
    },

    registrarMovimiento(sesionId, tipo, concepto, monto) {
        db.prepare(`INSERT INTO caja_movimientos (caja_sesion_id, tipo, concepto, monto) VALUES (?, ?, ?, ?)`)
            .run(sesionId, tipo, concepto, monto);
    },

    historial({ pagina = 1, por_pagina = 20 } = {}) {
        const offset = (pagina - 1) * por_pagina;
        return db.prepare(`
            SELECT cs.*, u.nombre_completo AS usuario_nombre
            FROM caja_sesiones cs JOIN usuarios u ON u.id = cs.usuario_id
            ORDER BY cs.abierta_en DESC
            LIMIT ? OFFSET ?
        `).all(por_pagina, offset);
    }
};

module.exports = Caja;
