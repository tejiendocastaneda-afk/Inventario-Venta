const db = require('../config/database');
const Sucursal = require('./Sucursal');

const Compra = {
    /**
     * Registra una compra a proveedor y aumenta el stock de cada producto
     * EN LA SUCURSAL indicada, dentro de una transacción atómica.
     * items: [{ producto_id, cantidad, costo_unitario }]
     */
    registrar({ proveedor_id, usuario_id, sucursal_id, items }) {
        const tx = db.transaction(() => {
            const total = items.reduce((acc, i) => acc + i.cantidad * i.costo_unitario, 0);

            const infoCompra = db.prepare(`
                INSERT INTO compras (proveedor_id, usuario_id, sucursal_id, total, estado)
                VALUES (?, ?, ?, ?, 'recibida')
            `).run(proveedor_id, usuario_id, sucursal_id || null, total);
            const compraId = infoCompra.lastInsertRowid;

            const insertarDetalle = db.prepare(`
                INSERT INTO compra_detalle (compra_id, producto_id, cantidad, costo_unitario)
                VALUES (?, ?, ?, ?)
            `);
            const actualizarCosto = db.prepare(`UPDATE productos SET costo = ? WHERE id = ?`);
            const registrarMovimiento = db.prepare(`
                INSERT INTO inventario_movimientos (producto_id, sucursal_id, tipo, cantidad, motivo, usuario_id)
                VALUES (?, ?, 'entrada', ?, 'Compra #' || ?, ?)
            `);

            for (const item of items) {
                insertarDetalle.run(compraId, item.producto_id, item.cantidad, item.costo_unitario);
                actualizarCosto.run(item.costo_unitario, item.producto_id);

                if (sucursal_id) {
                    Sucursal.ajustarStock(item.producto_id, sucursal_id, item.cantidad);
                } else {
                    db.prepare('UPDATE productos SET stock_total = stock_total + ? WHERE id = ?').run(item.cantidad, item.producto_id);
                }
                registrarMovimiento.run(item.producto_id, sucursal_id || null, item.cantidad, compraId, usuario_id);
            }

            return this.porId(compraId);
        });

        return tx();
    },

    porId(id) {
        const compra = db.prepare(`
            SELECT c.*, p.nombre_empresa AS proveedor_nombre, u.nombre_completo AS usuario_nombre, s.nombre AS sucursal_nombre
            FROM compras c
            JOIN proveedores p ON p.id = c.proveedor_id
            JOIN usuarios u ON u.id = c.usuario_id
            LEFT JOIN sucursales s ON s.id = c.sucursal_id
            WHERE c.id = ?
        `).get(id);
        if (!compra) return null;

        compra.detalle = db.prepare(`
            SELECT cd.*, pr.nombre AS producto_nombre
            FROM compra_detalle cd JOIN productos pr ON pr.id = cd.producto_id
            WHERE cd.compra_id = ?
        `).all(id);

        return compra;
    },

    listar({ pagina = 1, por_pagina = 30 } = {}) {
        const offset = (pagina - 1) * por_pagina;
        return db.prepare(`
            SELECT c.id, c.total, c.estado, c.creado_en,
                   p.nombre_empresa AS proveedor_nombre, u.nombre_completo AS usuario_nombre, s.nombre AS sucursal_nombre
            FROM compras c
            JOIN proveedores p ON p.id = c.proveedor_id
            JOIN usuarios u ON u.id = c.usuario_id
            LEFT JOIN sucursales s ON s.id = c.sucursal_id
            ORDER BY c.creado_en DESC
            LIMIT ? OFFSET ?
        `).all(por_pagina, offset);
    }
};

module.exports = Compra;
