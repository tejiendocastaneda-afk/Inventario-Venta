const db = require('../config/database');

const Producto = {
    /**
     * Búsqueda paginada con filtros (soporta catálogos grandes gracias a
     * los índices definidos en el esquema).
     */
    buscar({ q, categoria_id, marca_id, estado, en_oferta, pagina = 1, por_pagina = 24 }) {
        const condiciones = [];
        const valores = [];

        if (q) {
            condiciones.push(`(p.nombre LIKE ? OR p.codigo LIKE ? OR p.sku LIKE ? OR p.codigo_barras LIKE ?)`);
            valores.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`);
        }
        if (categoria_id) {
            condiciones.push('p.categoria_id = ?');
            valores.push(categoria_id);
        }
        if (marca_id) {
            condiciones.push('p.marca_id = ?');
            valores.push(marca_id);
        }
        if (estado) {
            condiciones.push('p.estado = ?');
            valores.push(estado);
        }
        if (en_oferta !== undefined && en_oferta !== '') {
            condiciones.push('p.en_oferta = ?');
            valores.push(Number(en_oferta));
        }

        const where = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';
        const offset = (pagina - 1) * por_pagina;

        const total = db.prepare(`SELECT COUNT(*) AS n FROM productos p ${where}`).get(...valores).n;

        const filas = db.prepare(`
            SELECT p.*, c.nombre AS categoria_nombre, m.nombre AS marca_nombre,
                   (SELECT url FROM producto_imagenes pi WHERE pi.producto_id = p.id AND pi.es_principal = 1 LIMIT 1) AS imagen_principal
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            LEFT JOIN marcas m ON m.id = p.marca_id
            ${where}
            ORDER BY p.actualizado_en DESC
            LIMIT ? OFFSET ?
        `).all(...valores, por_pagina, offset);

        return { total, pagina, por_pagina, productos: filas };
    },

    porId(id) {
        const producto = db.prepare(`
            SELECT p.*, c.nombre AS categoria_nombre, m.nombre AS marca_nombre
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            LEFT JOIN marcas m ON m.id = p.marca_id
            WHERE p.id = ?
        `).get(id);
        if (!producto) return null;

        producto.variantes = db.prepare('SELECT * FROM producto_variantes WHERE producto_id = ?').all(id);
        producto.imagenes = db.prepare('SELECT * FROM producto_imagenes WHERE producto_id = ? ORDER BY orden').all(id);
        producto.etiquetas = db.prepare(`
            SELECT e.id, e.nombre FROM etiquetas e
            JOIN producto_etiquetas pe ON pe.etiqueta_id = e.id
            WHERE pe.producto_id = ?
        `).all(id);
        return producto;
    },

    porCodigoOBarras(codigo) {
        return db.prepare(`
            SELECT * FROM productos WHERE codigo = ? OR codigo_barras = ? OR sku = ?
        `).get(codigo, codigo, codigo);
    },

    crear(datos) {
        const info = db.prepare(`
            INSERT INTO productos
                (nombre, codigo, sku, codigo_barras, descripcion, categoria_id, subcategoria_id,
                 marca_id, proveedor_id, precio_detal, precio_mayorista, costo, stock_total,
                 stock_minimo, en_oferta, precio_oferta, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            datos.nombre, datos.codigo || null, datos.sku || null, datos.codigo_barras || null,
            datos.descripcion || null, datos.categoria_id || null, datos.subcategoria_id || null,
            datos.marca_id || null, datos.proveedor_id || null,
            datos.precio_detal || 0, datos.precio_mayorista || 0, datos.costo || 0,
            datos.stock_total || 0, datos.stock_minimo || 0,
            datos.en_oferta ? 1 : 0, datos.precio_oferta || null, datos.estado || 'activo'
        );
        return this.porId(info.lastInsertRowid);
    },

    actualizar(id, datos) {
        const campos = [
            'nombre', 'codigo', 'sku', 'codigo_barras', 'descripcion', 'categoria_id', 'subcategoria_id',
            'marca_id', 'proveedor_id', 'precio_detal', 'precio_mayorista', 'costo', 'stock_total',
            'stock_minimo', 'en_oferta', 'precio_oferta', 'estado'
        ];
        const sets = [];
        const valores = [];
        for (const c of campos) {
            if (datos[c] !== undefined) {
                sets.push(`${c} = ?`);
                valores.push(datos[c]);
            }
        }
        if (!sets.length) return this.porId(id);
        valores.push(id);
        db.prepare(`UPDATE productos SET ${sets.join(', ')}, actualizado_en = datetime('now') WHERE id = ?`).run(...valores);
        return this.porId(id);
    },

    eliminar(id) {
        return db.prepare('DELETE FROM productos WHERE id = ?').run(id);
    },

    agregarVariante(productoId, { color, talla, sku_variante, codigo_barras_variante, stock, precio_detal_override, precio_mayorista_override, imagen_url }) {
        const info = db.prepare(`
            INSERT INTO producto_variantes
                (producto_id, color, talla, sku_variante, codigo_barras_variante, stock, precio_detal_override, precio_mayorista_override, imagen_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(productoId, color || null, talla || null, sku_variante || null, codigo_barras_variante || null,
               stock || 0, precio_detal_override || null, precio_mayorista_override || null, imagen_url || null);
        this.recalcularStockTotal(productoId);
        return db.prepare('SELECT * FROM producto_variantes WHERE id = ?').get(info.lastInsertRowid);
    },

    recalcularStockTotal(productoId) {
        const { total } = db.prepare('SELECT COALESCE(SUM(stock),0) AS total FROM producto_variantes WHERE producto_id = ?').get(productoId);
        if (total > 0) {
            db.prepare('UPDATE productos SET stock_total = ? WHERE id = ?').run(total, productoId);
        }
    },

    agregarImagen(productoId, url, esPrincipal = false) {
        if (esPrincipal) {
            db.prepare('UPDATE producto_imagenes SET es_principal = 0 WHERE producto_id = ?').run(productoId);
        }
        const info = db.prepare(`
            INSERT INTO producto_imagenes (producto_id, url, es_principal) VALUES (?, ?, ?)
        `).run(productoId, url, esPrincipal ? 1 : 0);
        return db.prepare('SELECT * FROM producto_imagenes WHERE id = ?').get(info.lastInsertRowid);
    },

    eliminarImagen(imagenId) {
        return db.prepare('DELETE FROM producto_imagenes WHERE id = ?').run(imagenId);
    }
};

module.exports = Producto;
