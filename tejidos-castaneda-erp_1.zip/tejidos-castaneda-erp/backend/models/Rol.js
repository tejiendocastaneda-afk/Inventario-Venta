const db = require('../config/database');

const Rol = {
    listarTodos() {
        return db.prepare('SELECT * FROM roles ORDER BY id').all();
    },

    porId(id) {
        return db.prepare('SELECT * FROM roles WHERE id = ?').get(id);
    },

    crear({ nombre, descripcion }) {
        const info = db.prepare(`INSERT INTO roles (nombre, descripcion) VALUES (?, ?)`).run(nombre, descripcion || null);
        return this.porId(info.lastInsertRowid);
    },

    editar(id, { nombre, descripcion }) {
        db.prepare(`UPDATE roles SET nombre = ?, descripcion = ?, actualizado_en = datetime('now') WHERE id = ?`)
            .run(nombre, descripcion || null, id);
        return this.porId(id);
    },

    eliminar(id) {
        const rol = this.porId(id);
        if (rol && rol.es_sistema === 1) {
            throw new Error('No se puede eliminar un rol de sistema.');
        }
        return db.prepare('DELETE FROM roles WHERE id = ?').run(id);
    },

    duplicar(id, nuevoNombre) {
        const original = this.porId(id);
        if (!original) throw new Error('Rol no encontrado.');
        const nuevo = this.crear({ nombre: nuevoNombre, descripcion: `Copia de ${original.nombre}` });
        const permisos = db.prepare('SELECT permiso_id, activo FROM rol_permisos WHERE rol_id = ?').all(id);
        const insertar = db.prepare('INSERT INTO rol_permisos (rol_id, permiso_id, activo) VALUES (?, ?, ?)');
        const tx = db.transaction((perms) => {
            for (const p of perms) insertar.run(nuevo.id, p.permiso_id, p.activo);
        });
        tx(permisos);
        return nuevo;
    },

    permisosDelRol(rolId) {
        return db.prepare(`
            SELECT p.id, p.clave, p.modulo, p.etiqueta, p.descripcion,
                   COALESCE(rp.activo, 0) AS activo
            FROM permisos p
            LEFT JOIN rol_permisos rp ON rp.permiso_id = p.id AND rp.rol_id = ?
            ORDER BY p.modulo, p.etiqueta
        `).all(rolId);
    },

    asignarPermiso(rolId, permisoId, activo) {
        db.prepare(`
            INSERT INTO rol_permisos (rol_id, permiso_id, activo)
            VALUES (?, ?, ?)
            ON CONFLICT(rol_id, permiso_id) DO UPDATE SET activo = excluded.activo
        `).run(rolId, permisoId, activo ? 1 : 0);
    },

    asignarPermisosMasivo(rolId, permisos) {
        // permisos: [{ permiso_id, activo }]
        const tx = db.transaction((lista) => {
            for (const p of lista) this.asignarPermiso(rolId, p.permiso_id, p.activo);
        });
        tx(permisos);
        return this.permisosDelRol(rolId);
    },

    listarPermisosMaestro() {
        return db.prepare('SELECT * FROM permisos ORDER BY modulo, etiqueta').all();
    },

    crearPermisoMaestro({ clave, modulo, etiqueta, descripcion }) {
        const info = db.prepare(`
            INSERT INTO permisos (clave, modulo, etiqueta, descripcion) VALUES (?, ?, ?, ?)
        `).run(clave, modulo, etiqueta, descripcion || null);
        return db.prepare('SELECT * FROM permisos WHERE id = ?').get(info.lastInsertRowid);
    }
};

module.exports = Rol;
