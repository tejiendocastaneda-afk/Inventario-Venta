const db = require('../config/database');

const Sucursal = {
    listar() {
        return db.prepare('SELECT * FROM sucursales ORDER BY nombre').all();
    },

    porId(id) {
        return db.prepare('SELECT * FROM sucursales WHERE id = ?').get(id);
    },

    crear({ nombre, ciudad, direccion, telefono }) {
        const info = db.prepare(`
            INSERT INTO sucursales (nombre, ciudad, direccion, telefono) VALUES (?, ?, ?, ?)
        `).run(nombre, ciudad || null, direccion || null, telefono || null);
        return this.porId(info.lastInsertRowid);
    },

    actualizar(id, { nombre, ciudad, direccion, telefono, activo }) {
        db.prepare(`
            UPDATE sucursales SET nombre = ?, ciudad = ?, direccion = ?, telefono = ?, activo = ?
            WHERE id = ?
        `).run(nombre, ciudad || null, direccion || null, telefono || null, activo === undefined ? 1 : activo, id);
        return this.porId(id);
    },

    eliminar(id) {
        return db.prepare('DELETE FROM sucursales WHERE id = ?').run(id);
    },

    /** Devuelve el desglose de stock de un producto en todas las sucursales */
    stockPorProducto(productoId) {
        return db.prepare(`
            SELECT s.id AS sucursal_id, s.nombre AS sucursal_nombre, COALESCE(pss.stock, 0) AS stock
            FROM sucursales s
            LEFT JOIN producto_stock_sucursal pss ON pss.sucursal_id = s.id AND pss.producto_id = ?
            WHERE s.activo = 1
            ORDER BY s.nombre
        `).all(productoId);
    },

    /** Ajusta (suma o resta) el stock de un producto en una sucursal específica y recalcula el agregado global */
    ajustarStock(productoId, sucursalId, delta) {
        const existente = db.prepare('SELECT stock FROM producto_stock_sucursal WHERE producto_id = ? AND sucursal_id = ?').get(productoId, sucursalId);
        if (existente) {
            db.prepare('UPDATE producto_stock_sucursal SET stock = stock + ? WHERE producto_id = ? AND sucursal_id = ?').run(delta, productoId, sucursalId);
        } else {
            db.prepare('INSERT INTO producto_stock_sucursal (producto_id, sucursal_id, stock) VALUES (?, ?, ?)').run(productoId, sucursalId, Math.max(0, delta));
        }
        // El agregado global en productos.stock_total siempre refleja la suma de todas las sedes
        db.prepare(`
            UPDATE productos SET stock_total = (
                SELECT COALESCE(SUM(stock), 0) FROM producto_stock_sucursal WHERE producto_id = ?
            ) WHERE id = ?
        `).run(productoId, productoId);
    },

    /** Inicializa el stock de un producto nuevo en una sucursal (usado al crear productos) */
    inicializarStock(productoId, sucursalId, stockInicial) {
        db.prepare(`
            INSERT INTO producto_stock_sucursal (producto_id, sucursal_id, stock) VALUES (?, ?, ?)
            ON CONFLICT(producto_id, sucursal_id) DO UPDATE SET stock = excluded.stock
        `).run(productoId, sucursalId, stockInicial || 0);
    },

    /**
     * Transfiere stock de una sucursal a otra dentro de una transacción
     * atómica. Valida que la sede de origen tenga suficiente stock.
     */
    transferirStock({ producto_id, sucursal_origen_id, sucursal_destino_id, cantidad, usuario_id, notas }) {
        if (sucursal_origen_id === sucursal_destino_id) {
            throw new Error('La sucursal de origen y destino no pueden ser la misma.');
        }
        if (cantidad <= 0) {
            throw new Error('La cantidad a transferir debe ser mayor a cero.');
        }

        const tx = db.transaction(() => {
            const origen = db.prepare('SELECT stock FROM producto_stock_sucursal WHERE producto_id = ? AND sucursal_id = ?').get(producto_id, sucursal_origen_id);
            const stockDisponible = origen?.stock || 0;
            if (stockDisponible < cantidad) {
                throw new Error(`Stock insuficiente en la sucursal de origen (disponible: ${stockDisponible}, solicitado: ${cantidad}).`);
            }

            this.ajustarStock(producto_id, sucursal_origen_id, -cantidad);
            this.ajustarStock(producto_id, sucursal_destino_id, cantidad);

            db.prepare(`
                INSERT INTO transferencias_stock (producto_id, sucursal_origen_id, sucursal_destino_id, cantidad, usuario_id, notas)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run(producto_id, sucursal_origen_id, sucursal_destino_id, cantidad, usuario_id, notas || null);

            db.prepare(`
                INSERT INTO inventario_movimientos (producto_id, sucursal_id, tipo, cantidad, motivo, usuario_id)
                VALUES (?, ?, 'salida', ?, 'Transferencia a otra sucursal', ?)
            `).run(producto_id, sucursal_origen_id, cantidad, usuario_id);
            db.prepare(`
                INSERT INTO inventario_movimientos (producto_id, sucursal_id, tipo, cantidad, motivo, usuario_id)
                VALUES (?, ?, 'entrada', ?, 'Transferencia desde otra sucursal', ?)
            `).run(producto_id, sucursal_destino_id, cantidad, usuario_id);
        });

        tx();
        return this.stockPorProducto(producto_id);
    },

    listarTransferencias({ producto_id, sucursal_id, pagina = 1, por_pagina = 30 } = {}) {
        const condiciones = [];
        const valores = [];
        if (producto_id) { condiciones.push('t.producto_id = ?'); valores.push(producto_id); }
        if (sucursal_id) { condiciones.push('(t.sucursal_origen_id = ? OR t.sucursal_destino_id = ?)'); valores.push(sucursal_id, sucursal_id); }
        const where = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';
        const offset = (pagina - 1) * por_pagina;

        const total = db.prepare(`SELECT COUNT(*) AS n FROM transferencias_stock t ${where}`).get(...valores).n;

        const filas = db.prepare(`
            SELECT t.*, p.nombre AS producto_nombre, p.codigo,
                   so.nombre AS sucursal_origen_nombre, sd.nombre AS sucursal_destino_nombre,
                   u.nombre_completo AS usuario_nombre
            FROM transferencias_stock t
            JOIN productos p ON p.id = t.producto_id
            JOIN sucursales so ON so.id = t.sucursal_origen_id
            JOIN sucursales sd ON sd.id = t.sucursal_destino_id
            JOIN usuarios u ON u.id = t.usuario_id
            ${where}
            ORDER BY t.creado_en DESC
            LIMIT ? OFFSET ?
        `).all(...valores, por_pagina, offset);

        return { total, pagina, por_pagina, transferencias: filas };
    }
};

module.exports = Sucursal;
