const db = require('../config/database');

const Usuario = {
    porUsuario(usuario) {
        return db.prepare(`
            SELECT u.*, r.nombre AS rol_nombre, s.nombre AS sucursal_nombre
            FROM usuarios u
            JOIN roles r ON r.id = u.rol_id
            LEFT JOIN sucursales s ON s.id = u.sucursal_id
            WHERE u.usuario = ?
        `).get(usuario);
    },

    porId(id) {
        return db.prepare(`
            SELECT u.id, u.nombre_completo, u.usuario, u.correo, u.activo, u.foto_url,
                   u.telefono, u.rol_id, r.nombre AS rol_nombre, u.sucursal_id, s.nombre AS sucursal_nombre
            FROM usuarios u
            JOIN roles r ON r.id = u.rol_id
            LEFT JOIN sucursales s ON s.id = u.sucursal_id
            WHERE u.id = ?
        `).get(id);
    },

    listar() {
        return db.prepare(`
            SELECT u.id, u.nombre_completo, u.usuario, u.correo, u.activo,
                   u.rol_id, r.nombre AS rol_nombre, u.sucursal_id, s.nombre AS sucursal_nombre,
                   u.ultimo_login, u.creado_en
            FROM usuarios u
            JOIN roles r ON r.id = u.rol_id
            LEFT JOIN sucursales s ON s.id = u.sucursal_id
            ORDER BY u.nombre_completo
        `).all();
    },

    crear({ nombre_completo, usuario, correo, password_hash, rol_id, telefono, sucursal_id }) {
        const info = db.prepare(`
            INSERT INTO usuarios (nombre_completo, usuario, correo, password_hash, rol_id, telefono, sucursal_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(nombre_completo, usuario, correo || null, password_hash, rol_id, telefono || null, sucursal_id || null);
        return this.porId(info.lastInsertRowid);
    },

    actualizarUltimoLogin(id) {
        db.prepare(`UPDATE usuarios SET ultimo_login = datetime('now') WHERE id = ?`).run(id);
    },

    actualizar(id, campos) {
        const permitidos = ['nombre_completo', 'correo', 'rol_id', 'telefono', 'activo', 'foto_url', 'sucursal_id'];
        const sets = [];
        const valores = [];
        for (const campo of permitidos) {
            if (campos[campo] !== undefined) {
                sets.push(`${campo} = ?`);
                valores.push(campos[campo]);
            }
        }
        if (!sets.length) return this.porId(id);
        valores.push(id);
        db.prepare(`UPDATE usuarios SET ${sets.join(', ')}, actualizado_en = datetime('now') WHERE id = ?`).run(...valores);
        return this.porId(id);
    },

    eliminar(id) {
        return db.prepare('DELETE FROM usuarios WHERE id = ?').run(id);
    }
};

module.exports = Usuario;
