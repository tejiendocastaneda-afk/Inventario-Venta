const db = require('../config/database');
const Sucursal = require('./Sucursal');

function generarNumeroFactura() {
    const fecha = new Date();
    const yyyymmdd = fecha.toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.floor(1000 + Math.random() * 9000);
    return `TC-${yyyymmdd}-${random}`;
}

const Venta = {
    /**
     * Registra una venta completa dentro de una transacción:
     * descuenta stock, calcula totales, guarda detalle y pagos.
     * items: [{ producto_id, variante_id, cantidad, precio_unitario, descuento }]
     * pagos: [{ metodo_pago_id, monto }]
     */
    registrar({ cliente_id, usuario_id, caja_sesion_id, items, pagos, tipo_precio, descuento_total = 0, impuesto_total = 0, cupon_id = null, es_apartado = false, abono_apartado = 0 }) {
        const tx = db.transaction(() => {
            let subtotal = 0;
            for (const item of items) {
                subtotal += (item.precio_unitario * item.cantidad) - (item.descuento || 0);
            }
            const total = subtotal - descuento_total + impuesto_total;
            const numero_factura = generarNumeroFactura();

            // La venta hereda la sucursal de la sesión de caja activa (cada caja pertenece a una sede)
            let sucursal_id = null;
            if (caja_sesion_id) {
                const sesion = db.prepare('SELECT sucursal_id FROM caja_sesiones WHERE id = ?').get(caja_sesion_id);
                sucursal_id = sesion?.sucursal_id || null;
            }

            const infoVenta = db.prepare(`
                INSERT INTO ventas
                    (numero_factura, cliente_id, usuario_id, caja_sesion_id, sucursal_id, subtotal, descuento_total,
                     impuesto_total, total, tipo_precio, cupon_id, estado, es_apartado, abono_apartado)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `).run(
                numero_factura, cliente_id || null, usuario_id, caja_sesion_id || null, sucursal_id,
                subtotal, descuento_total, impuesto_total, total, tipo_precio || 'detal',
                cupon_id, es_apartado ? 'apartado' : 'completada', es_apartado ? 1 : 0, abono_apartado
            );

            const ventaId = infoVenta.lastInsertRowid;

            const insertarDetalle = db.prepare(`
                INSERT INTO venta_detalle (venta_id, producto_id, variante_id, cantidad, precio_unitario, descuento, subtotal)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `);
            const descontarStockVariante = db.prepare(`UPDATE producto_variantes SET stock = stock - ? WHERE id = ?`);
            const registrarMovimiento = db.prepare(`
                INSERT INTO inventario_movimientos (producto_id, variante_id, sucursal_id, tipo, cantidad, motivo, usuario_id)
                VALUES (?, ?, ?, 'salida', ?, 'Venta ' || ?, ?)
            `);

            for (const item of items) {
                const itemSubtotal = (item.precio_unitario * item.cantidad) - (item.descuento || 0);
                insertarDetalle.run(ventaId, item.producto_id, item.variante_id || null, item.cantidad, item.precio_unitario, item.descuento || 0, itemSubtotal);

                if (!es_apartado) {
                    if (sucursal_id) {
                        Sucursal.ajustarStock(item.producto_id, sucursal_id, -item.cantidad);
                    } else {
                        // Sin sucursal asociada (ventas antiguas o sesión sin sede): se descuenta del agregado global
                        db.prepare(`UPDATE productos SET stock_total = stock_total - ? WHERE id = ?`).run(item.cantidad, item.producto_id);
                    }
                    if (item.variante_id) descontarStockVariante.run(item.cantidad, item.variante_id);
                    registrarMovimiento.run(item.producto_id, item.variante_id || null, sucursal_id, item.cantidad, numero_factura, usuario_id);
                }
            }

            const insertarPago = db.prepare(`INSERT INTO venta_pagos (venta_id, metodo_pago_id, monto) VALUES (?, ?, ?)`);
            for (const pago of (pagos || [])) {
                insertarPago.run(ventaId, pago.metodo_pago_id, pago.monto);
            }

            if (caja_sesion_id) {
                db.prepare(`
                    INSERT INTO caja_movimientos (caja_sesion_id, tipo, concepto, monto)
                    VALUES (?, 'venta', ?, ?)
                `).run(caja_sesion_id, `Venta ${numero_factura}`, total);
            }

            if (cliente_id && es_apartado) {
                db.prepare(`UPDATE clientes SET saldo_pendiente = saldo_pendiente + ? WHERE id = ?`)
                    .run(total - abono_apartado, cliente_id);
            }

            if (cupon_id) {
                db.prepare(`UPDATE cupones SET usos_actuales = usos_actuales + 1 WHERE id = ?`).run(cupon_id);
            }

            return this.porId(ventaId);
        });

        return tx();
    },

    porId(id) {
        const venta = db.prepare(`
            SELECT v.*, c.nombre_completo AS cliente_nombre, u.nombre_completo AS vendedor_nombre, s.nombre AS sucursal_nombre
            FROM ventas v
            LEFT JOIN clientes c ON c.id = v.cliente_id
            JOIN usuarios u ON u.id = v.usuario_id
            LEFT JOIN sucursales s ON s.id = v.sucursal_id
            WHERE v.id = ?
        `).get(id);
        if (!venta) return null;

        venta.detalle = db.prepare(`
            SELECT vd.*, p.nombre AS producto_nombre, p.codigo,
                   pv.color, pv.talla
            FROM venta_detalle vd
            JOIN productos p ON p.id = vd.producto_id
            LEFT JOIN producto_variantes pv ON pv.id = vd.variante_id
            WHERE vd.venta_id = ?
        `).all(id);

        venta.pagos = db.prepare(`
            SELECT vp.*, mp.nombre AS metodo_nombre
            FROM venta_pagos vp JOIN metodos_pago mp ON mp.id = vp.metodo_pago_id
            WHERE vp.venta_id = ?
        `).all(id);

        return venta;
    },

    listar({ desde, hasta, estado, pagina = 1, por_pagina = 30 } = {}) {
        const condiciones = [];
        const valores = [];
        if (desde) { condiciones.push('date(v.creado_en) >= date(?)'); valores.push(desde); }
        if (hasta) { condiciones.push('date(v.creado_en) <= date(?)'); valores.push(hasta); }
        if (estado) { condiciones.push('v.estado = ?'); valores.push(estado); }
        const where = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';
        const offset = (pagina - 1) * por_pagina;

        return db.prepare(`
            SELECT v.id, v.numero_factura, v.total, v.estado, v.creado_en,
                   c.nombre_completo AS cliente_nombre, u.nombre_completo AS vendedor_nombre
            FROM ventas v
            LEFT JOIN clientes c ON c.id = v.cliente_id
            JOIN usuarios u ON u.id = v.usuario_id
            ${where}
            ORDER BY v.creado_en DESC
            LIMIT ? OFFSET ?
        `).all(...valores, por_pagina, offset);
    },

    anular(id) {
        const venta = this.porId(id);
        if (!venta) throw new Error('Venta no encontrada.');
        const tx = db.transaction(() => {
            for (const item of venta.detalle) {
                if (venta.sucursal_id) {
                    Sucursal.ajustarStock(item.producto_id, venta.sucursal_id, item.cantidad);
                } else {
                    db.prepare('UPDATE productos SET stock_total = stock_total + ? WHERE id = ?').run(item.cantidad, item.producto_id);
                }
                if (item.variante_id) {
                    db.prepare('UPDATE producto_variantes SET stock = stock + ? WHERE id = ?').run(item.cantidad, item.variante_id);
                }
            }
            db.prepare(`UPDATE ventas SET estado = 'anulada' WHERE id = ?`).run(id);
        });
        tx();
        return this.porId(id);
    }
};

module.exports = Venta;
