const router = require('express').Router();
const apartadoController = require('../controllers/apartadoController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/', requierePermiso('ventas.ver'), apartadoController.listar);
router.post('/:id/abonos', requierePermiso('ventas.crear'), apartadoController.registrarAbono);

module.exports = router;
