const router = require('express').Router();
const authController = require('../controllers/authController');
const { autenticar } = require('../middleware/auth');

router.post('/login', authController.login);
router.get('/perfil', autenticar, authController.perfil);
router.post('/cambiar-password', autenticar, authController.cambiarPassword);

module.exports = router;
