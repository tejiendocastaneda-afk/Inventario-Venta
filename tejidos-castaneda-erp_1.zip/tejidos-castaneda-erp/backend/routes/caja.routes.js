const router = require('express').Router();
const cajaController = require('../controllers/cajaController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/actual', cajaController.sesionActual);
router.post('/abrir', requierePermiso('caja.abrir'), cajaController.abrir);
router.post('/:id/cerrar', requierePermiso('caja.cerrar'), cajaController.cerrar);
router.get('/:id/movimientos', cajaController.movimientos);
router.post('/:id/movimientos', requierePermiso('caja.abrir'), cajaController.registrarMovimiento);
router.get('/historial', requierePermiso('caja.ver_historial'), cajaController.historial);

module.exports = router;
