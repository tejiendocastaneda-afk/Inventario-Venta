const router = require('express').Router();
const catalogo = require('../controllers/catalogoController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

function montarCrud(basePath, controlador, permisoModulo) {
    router.get(`/${basePath}`, controlador.listar);
    router.post(`/${basePath}`, requierePermiso(`${permisoModulo}.crear`), controlador.crear);
    router.put(`/${basePath}/:id`, requierePermiso(`${permisoModulo}.editar`), controlador.actualizar);
    router.delete(`/${basePath}/:id`, requierePermiso(`${permisoModulo}.eliminar`), controlador.eliminar);
}

montarCrud('categorias', catalogo.categorias, 'categorias');
montarCrud('marcas', catalogo.marcas, 'categorias');
montarCrud('clientes', catalogo.clientes, 'clientes');
montarCrud('proveedores', catalogo.proveedores, 'proveedores');
montarCrud('metodos-pago', catalogo.metodosPago, 'configuracion');
montarCrud('impuestos', catalogo.impuestos, 'configuracion');
montarCrud('cupones', catalogo.cupones, 'productos');
router.get('/cupones/validar/:codigo', catalogo.validarCupon);

module.exports = router;
