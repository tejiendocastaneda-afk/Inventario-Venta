const router = require('express').Router();
const compraController = require('../controllers/compraController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/', requierePermiso('proveedores.ver'), compraController.listar);
router.get('/:id', requierePermiso('proveedores.ver'), compraController.obtener);
router.post('/', requierePermiso('proveedores.editar'), compraController.registrar);

module.exports = router;
