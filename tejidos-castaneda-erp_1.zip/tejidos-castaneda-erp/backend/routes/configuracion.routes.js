const router = require('express').Router();
const db = require('../config/database');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/', (req, res) => {
    const filas = db.prepare('SELECT clave, valor FROM configuracion').all();
    const objeto = {};
    filas.forEach(f => objeto[f.clave] = f.valor);
    res.json(objeto);
});

router.put('/', requierePermiso('configuracion.editar'), (req, res) => {
    const entradas = Object.entries(req.body);
    const upsert = db.prepare(`
        INSERT INTO configuracion (clave, valor) VALUES (?, ?)
        ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor
    `);
    const tx = db.transaction(() => { for (const [k, v] of entradas) upsert.run(k, String(v)); });
    tx();
    res.json({ mensaje: 'Configuración actualizada.' });
});

module.exports = router;
