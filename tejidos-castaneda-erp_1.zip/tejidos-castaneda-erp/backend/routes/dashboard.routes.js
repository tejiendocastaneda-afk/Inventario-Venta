const router = require('express').Router();
const dashboardController = require('../controllers/dashboardController');
const { autenticar } = require('../middleware/auth');

router.get('/resumen', autenticar, dashboardController.resumen);

module.exports = router;
