const router = require('express').Router();
const importadorController = require('../controllers/importadorController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');
const upload = require('../middleware/upload');

router.use(autenticar);
router.use(requierePermiso('productos.crear'));

router.post('/previsualizar', upload.uploadMemoria.single('archivo'), importadorController.previsualizar);
router.post('/importar', upload.uploadMemoria.single('archivo'), importadorController.importar);

module.exports = router;
