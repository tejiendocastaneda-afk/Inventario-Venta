const router = require('express').Router();
const notificacionController = require('../controllers/notificacionController');
const { autenticar } = require('../middleware/auth');

router.get('/stock-bajo', autenticar, notificacionController.stockBajo);

module.exports = router;
