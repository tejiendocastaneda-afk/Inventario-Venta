const router = require('express').Router();
const productoController = require('../controllers/productoController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');
const upload = require('../middleware/upload');

router.use(autenticar);

router.get('/', productoController.buscar);
router.get('/codigo/:codigo', productoController.buscarPorCodigo);
router.get('/:id', productoController.obtener);

router.post('/', requierePermiso('productos.crear'), productoController.crear);
router.put('/:id', requierePermiso('productos.editar'), productoController.actualizar);
router.delete('/:id', requierePermiso('productos.eliminar'), productoController.eliminar);

router.post('/:id/variantes', requierePermiso('productos.editar'), productoController.agregarVariante);

router.post('/:id/imagenes', requierePermiso('productos.editar'), upload.array('imagenes', 10), productoController.subirImagenes);
router.delete('/imagenes/:imagenId', requierePermiso('productos.editar'), productoController.eliminarImagen);

module.exports = router;
