const router = require('express').Router();
const reporteController = require('../controllers/reporteController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);
router.use(requierePermiso('reportes.ver'));

router.get('/ventas-periodo', reporteController.ventasPorPeriodo);
router.get('/productos-mas-vendidos', reporteController.productosMasVendidos);
router.get('/productos-sin-movimiento', reporteController.productosSinMovimiento);
router.get('/ganancias', reporteController.gananciasPeriodo);
router.get('/inventario', reporteController.inventarioActual);
router.get('/clientes-saldo', reporteController.clientesConSaldo);

module.exports = router;
