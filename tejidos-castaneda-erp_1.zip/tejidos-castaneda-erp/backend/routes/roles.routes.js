const router = require('express').Router();
const rolController = require('../controllers/rolController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/', requierePermiso('roles.ver'), rolController.listar);
router.post('/', requierePermiso('roles.crear'), rolController.crear);
router.put('/:id', requierePermiso('roles.editar'), rolController.editar);
router.delete('/:id', requierePermiso('roles.eliminar'), rolController.eliminar);
router.post('/:id/duplicar', requierePermiso('roles.crear'), rolController.duplicar);

router.get('/:id/permisos', requierePermiso('roles.ver'), rolController.permisosDelRol);
router.put('/:id/permisos', requierePermiso('roles.editar'), rolController.actualizarPermisos);

router.get('/permisos/catalogo', requierePermiso('roles.ver'), rolController.listarCatalogoPermisos);

module.exports = router;
