const router = require('express').Router();
const sucursalController = require('../controllers/sucursalController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/', sucursalController.listar);
router.post('/', requierePermiso('configuracion.editar'), sucursalController.crear);
router.put('/:id', requierePermiso('configuracion.editar'), sucursalController.actualizar);
router.delete('/:id', requierePermiso('configuracion.editar'), sucursalController.eliminar);
router.get('/stock/:productoId', sucursalController.stockPorProducto);
router.post('/transferencias', requierePermiso('inventario.ajustar'), sucursalController.transferirStock);
router.get('/transferencias', sucursalController.listarTransferencias);

module.exports = router;
