const router = require('express').Router();
const usuarioController = require('../controllers/usuarioController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/', requierePermiso('usuarios.ver'), usuarioController.listar);
router.post('/', requierePermiso('usuarios.crear'), usuarioController.crear);
router.put('/:id', requierePermiso('usuarios.editar'), usuarioController.actualizar);
router.delete('/:id', requierePermiso('usuarios.eliminar'), usuarioController.eliminar);

module.exports = router;
