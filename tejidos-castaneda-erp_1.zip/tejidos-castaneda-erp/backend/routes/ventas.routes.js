const router = require('express').Router();
const ventaController = require('../controllers/ventaController');
const { autenticar } = require('../middleware/auth');
const { requierePermiso } = require('../middleware/permisos');

router.use(autenticar);

router.get('/', requierePermiso('ventas.ver'), ventaController.listar);
router.get('/:id', requierePermiso('ventas.ver'), ventaController.obtener);
router.post('/', requierePermiso('ventas.crear'), ventaController.registrar);
router.post('/:id/anular', requierePermiso('ventas.anular'), ventaController.anular);

module.exports = router;
