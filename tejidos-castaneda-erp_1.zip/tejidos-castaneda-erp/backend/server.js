require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const xssClean = require('xss-clean');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;

// ---------- Auto-configuración en el primer arranque ----------
// Si la base de datos está recién creada (sin usuarios), siembra roles,
// permisos, la sucursal principal y el usuario administrador automáticamente.
// Esto evita tener que entrar por SSH/consola a correr "npm run seed" a mano
// cuando el sistema se despliega en un servidor.
(function autoSeedSiEsNecesario() {
    const db = require('./config/database');
    const { n } = db.prepare('SELECT COUNT(*) AS n FROM usuarios').get();
    if (n === 0) {
        console.log('[INIT] Base de datos vacía detectada. Creando configuración inicial...');
        const ejecutarSeed = require('./utils/seed');
        ejecutarSeed();
    }
})();

// ---------- Seguridad ----------
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(xssClean()); // sanea inputs contra XSS
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

const limiterLogin = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 20,
    message: { error: 'Demasiados intentos de inicio de sesión. Intenta de nuevo en unos minutos.' }
});
app.use('/api/auth/login', limiterLogin);

const limiterGeneral = rateLimit({ windowMs: 60 * 1000, max: 300 });
app.use('/api/', limiterGeneral);

// ---------- Archivos estáticos ----------
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// ---------- Rutas API ----------
app.get('/api/salud', (req, res) => res.json({ estado: 'ok', proyecto: 'Tejidos Castañeda ERP' }));

app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/roles', require('./routes/roles.routes'));
app.use('/api/usuarios', require('./routes/usuarios.routes'));
app.use('/api/productos', require('./routes/productos.routes'));
app.use('/api/ventas', require('./routes/ventas.routes'));
app.use('/api/caja', require('./routes/caja.routes'));
app.use('/api/dashboard', require('./routes/dashboard.routes'));
app.use('/api/compras', require('./routes/compras.routes'));
app.use('/api/reportes', require('./routes/reportes.routes'));
app.use('/api/apartados', require('./routes/apartados.routes'));
app.use('/api/configuracion', require('./routes/configuracion.routes'));
app.use('/api/importador', require('./routes/importador.routes'));
app.use('/api/sucursales', require('./routes/sucursales.routes'));
app.use('/api/notificaciones', require('./routes/notificaciones.routes'));
app.use('/api', require('./routes/catalogos.routes'));


// Fallback SPA -> index.html
app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next();
    res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

// ---------- Manejo de errores ----------
app.use((err, req, res, next) => {
    console.error(err);
    res.status(err.status || 500).json({ error: err.message || 'Error interno del servidor.' });
});

app.listen(PORT, () => {
    console.log(`\n  Tejidos Castañeda ERP corriendo en http://localhost:${PORT}\n`);
});
