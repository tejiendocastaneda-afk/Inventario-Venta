/**
 * Siembra inicial de la base de datos:
 * - Roles base (Administrador, Propietario, Empleado, Cajero, Supervisor, Invitado)
 * - Catálogo maestro de permisos
 * - Usuario administrador por defecto
 * - Métodos de pago e impuesto IVA por defecto
 *
 * Ejecutar: npm run seed
 */
const db = require('../config/database');
const bcrypt = require('bcryptjs');

const PERMISOS = [
    ['ventas.ver', 'ventas', 'Ver ventas'],
    ['ventas.crear', 'ventas', 'Registrar ventas'],
    ['ventas.anular', 'ventas', 'Anular ventas'],
    ['ventas.editar_precio', 'ventas', 'Modificar precio en el POS'],
    ['ventas.aplicar_descuento', 'ventas', 'Aplicar descuentos'],
    ['ventas.devoluciones', 'ventas', 'Hacer devoluciones'],
    ['caja.abrir', 'caja', 'Abrir caja'],
    ['caja.cerrar', 'caja', 'Cerrar caja'],
    ['caja.ver_historial', 'caja', 'Ver historial de caja'],
    ['productos.ver', 'productos', 'Ver productos'],
    ['productos.crear', 'productos', 'Crear productos'],
    ['productos.editar', 'productos', 'Editar productos'],
    ['productos.eliminar', 'productos', 'Eliminar productos'],
    ['categorias.crear', 'categorias', 'Crear categorías/marcas'],
    ['categorias.editar', 'categorias', 'Editar categorías/marcas'],
    ['categorias.eliminar', 'categorias', 'Eliminar categorías/marcas'],
    ['clientes.ver', 'clientes', 'Ver clientes'],
    ['clientes.crear', 'clientes', 'Crear clientes'],
    ['clientes.editar', 'clientes', 'Editar clientes'],
    ['clientes.eliminar', 'clientes', 'Eliminar clientes'],
    ['proveedores.ver', 'proveedores', 'Ver proveedores'],
    ['proveedores.crear', 'proveedores', 'Crear proveedores'],
    ['proveedores.editar', 'proveedores', 'Editar proveedores'],
    ['proveedores.eliminar', 'proveedores', 'Eliminar proveedores'],
    ['reportes.ver', 'reportes', 'Ver reportes y estadísticas'],
    ['reportes.exportar', 'reportes', 'Exportar reportes'],
    ['usuarios.ver', 'usuarios', 'Ver usuarios'],
    ['usuarios.crear', 'usuarios', 'Crear usuarios'],
    ['usuarios.editar', 'usuarios', 'Editar usuarios'],
    ['usuarios.eliminar', 'usuarios', 'Eliminar usuarios'],
    ['roles.ver', 'roles', 'Ver roles y permisos'],
    ['roles.crear', 'roles', 'Crear roles'],
    ['roles.editar', 'roles', 'Editar roles y permisos'],
    ['roles.eliminar', 'roles', 'Eliminar roles'],
    ['configuracion.ver', 'configuracion', 'Ver configuración general'],
    ['configuracion.editar', 'configuracion', 'Editar configuración general'],
    ['inventario.ver', 'inventario', 'Ver inventario y movimientos'],
    ['inventario.ajustar', 'inventario', 'Realizar ajustes de inventario'],
];

/**
 * Ejecuta la siembra de datos iniciales. Es segura de correr varias veces
 * (usa INSERT OR IGNORE / ON CONFLICT), así que no duplica nada si ya existen.
 */
function ejecutarSeed() {
    const tx = db.transaction(() => {
    // Sucursal principal por defecto (Otanche, Boyacá — la sede original del negocio)
    db.prepare(`
        INSERT OR IGNORE INTO sucursales (nombre, ciudad, direccion) VALUES ('Otanche - Boyacá', 'Otanche', NULL)
    `).run();
    const sucursalPrincipal = db.prepare("SELECT id FROM sucursales WHERE nombre = 'Otanche - Boyacá'").get();

    // Roles base
    const rolesBase = [
        ['Administrador', 'Acceso total al sistema', 1],
        ['Propietario', 'Dueño del negocio', 0],
        ['Empleado', 'Personal general de la tienda', 0],
        ['Cajero', 'Maneja caja y ventas', 0],
        ['Supervisor', 'Supervisa operación diaria', 0],
        ['Invitado', 'Acceso muy limitado, solo lectura', 0],
    ];

    const insertarRol = db.prepare('INSERT OR IGNORE INTO roles (nombre, descripcion, es_sistema) VALUES (?, ?, ?)');
    for (const r of rolesBase) insertarRol.run(...r);

    // Catálogo de permisos
    const insertarPermiso = db.prepare('INSERT OR IGNORE INTO permisos (clave, modulo, etiqueta) VALUES (?, ?, ?)');
    for (const p of PERMISOS) insertarPermiso.run(...p);

    // Rol Cajero: permisos operativos básicos activados por defecto
    const rolCajero = db.prepare("SELECT id FROM roles WHERE nombre = 'Cajero'").get();
    const permisosCajero = ['ventas.ver', 'ventas.crear', 'caja.abrir', 'caja.cerrar', 'productos.ver', 'clientes.ver', 'clientes.crear'];
    const asignar = db.prepare(`
        INSERT INTO rol_permisos (rol_id, permiso_id, activo)
        SELECT ?, id, 1 FROM permisos WHERE clave = ?
        ON CONFLICT(rol_id, permiso_id) DO UPDATE SET activo = 1
    `);
    for (const clave of permisosCajero) asignar.run(rolCajero.id, clave);

    // Usuario administrador por defecto
    const rolAdmin = db.prepare("SELECT id FROM roles WHERE nombre = 'Administrador'").get();
    const existeAdmin = db.prepare("SELECT id FROM usuarios WHERE usuario = 'admin'").get();
    if (!existeAdmin) {
        const hash = bcrypt.hashSync('Admin123!', 10);
        db.prepare(`
            INSERT INTO usuarios (nombre_completo, usuario, correo, password_hash, rol_id, sucursal_id)
            VALUES ('Administrador General', 'admin', 'admin@tejidoscastaneda.com', ?, ?, ?)
        `).run(hash, rolAdmin.id, sucursalPrincipal.id);
        console.log('[SEED] Usuario admin creado -> usuario: admin / contraseña: Admin123!');
        console.log('[SEED] IMPORTANTE: cambia esta contraseña en el primer inicio de sesión.');
    }

    // Métodos de pago por defecto
    const metodos = [
        ['Efectivo', 'cash', '#16a34a', 'ninguno', 0, 1],
        ['Transferencia', 'bank', '#2563eb', 'ninguno', 0, 2],
        ['Nequi', 'phone', '#7c3aed', 'ninguno', 0, 3],
        ['Daviplata', 'phone', '#dc2626', 'ninguno', 0, 4],
        ['Tarjeta Crédito', 'card', '#0891b2', 'porcentaje', 3, 5],
        ['Tarjeta Débito', 'card', '#0e7490', 'porcentaje', 1.5, 6],
    ];
    const insertarMetodo = db.prepare(`
        INSERT OR IGNORE INTO metodos_pago (nombre, icono, color, tipo_recargo, valor_recargo, orden)
        VALUES (?, ?, ?, ?, ?, ?)
    `);
    for (const m of metodos) insertarMetodo.run(...m);

    // Impuesto IVA por defecto
    db.prepare(`INSERT OR IGNORE INTO impuestos (nombre, porcentaje, por_defecto) VALUES ('IVA 19%', 19, 1)`).run();
    db.prepare(`INSERT OR IGNORE INTO impuestos (nombre, porcentaje, por_defecto) VALUES ('Exento 0%', 0, 0)`).run();

    // Categorías base de ejemplo (acorde al negocio real)
    const categorias = ['Ruanas', 'Chompas', 'Yetis', 'Busos', 'Camisetas'];
    const insertarCategoria = db.prepare('INSERT OR IGNORE INTO categorias (nombre) VALUES (?)');
    for (const c of categorias) insertarCategoria.run(c);

    // Configuración general por defecto
    const config = [
        ['nombre_negocio', 'Tejidos Castañeda'],
        ['moneda', 'COP'],
        ['formato_fecha', 'DD/MM/YYYY'],
        ['tema', 'claro'],
    ];
    const insertarConfig = db.prepare('INSERT OR IGNORE INTO configuracion (clave, valor) VALUES (?, ?)');
    for (const c of config) insertarConfig.run(...c);
    });

    tx();
    console.log('[SEED] Datos iniciales verificados/creados correctamente.');
}

module.exports = ejecutarSeed;

// Si se ejecuta directamente con "node utils/seed.js" o "npm run seed"
if (require.main === module) {
    ejecutarSeed();
}
