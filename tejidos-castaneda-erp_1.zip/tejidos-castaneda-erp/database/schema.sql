-- ============================================================
-- TEJIDOS CASTAÑEDA - ERP / POS / INVENTARIO / CONTABLE
-- Esquema de base de datos (SQLite -> migrable a MySQL/PostgreSQL)
-- Convenciones: snake_case, llaves foráneas explícitas, timestamps
-- ============================================================

PRAGMA foreign_keys = ON;

-- ============ SUCURSALES (multi-sede) ============

CREATE TABLE IF NOT EXISTS sucursales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE,       -- ej: "Otanche - Boyacá", "Quito - Ecuador"
    ciudad TEXT,
    direccion TEXT,
    telefono TEXT,
    activo INTEGER NOT NULL DEFAULT 1,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Stock desagregado por sucursal. productos.stock_total sigue existiendo
-- como el AGREGADO global (suma de todas las sucursales) para no romper
-- las pantallas que ya lo usan; esta tabla es la fuente de verdad por sede.
CREATE TABLE IF NOT EXISTS producto_stock_sucursal (
    producto_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    sucursal_id INTEGER NOT NULL REFERENCES sucursales(id) ON DELETE CASCADE,
    stock INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (producto_id, sucursal_id)
);

-- Transferencias de stock entre sucursales (ej: enviar mercancía de
-- Otanche a la sede de Ecuador)
CREATE TABLE IF NOT EXISTS transferencias_stock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    sucursal_origen_id INTEGER NOT NULL REFERENCES sucursales(id),
    sucursal_destino_id INTEGER NOT NULL REFERENCES sucursales(id),
    cantidad INTEGER NOT NULL,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    notas TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============ SEGURIDAD / USUARIOS / ROLES / PERMISOS ============

CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE,
    descripcion TEXT,
    es_sistema INTEGER NOT NULL DEFAULT 0, -- roles base no eliminables (Administrador)
    creado_en TEXT NOT NULL DEFAULT (datetime('now')),
    actualizado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Catálogo maestro de permisos disponibles en el sistema
CREATE TABLE IF NOT EXISTS permisos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clave TEXT NOT NULL UNIQUE,      -- ej: ventas.crear, caja.abrir, productos.editar_precio
    modulo TEXT NOT NULL,            -- ej: ventas, caja, productos, reportes
    etiqueta TEXT NOT NULL,          -- ej: "Puede registrar ventas"
    descripcion TEXT
);

-- Relación N:M rol <-> permiso (activable/desactivable)
CREATE TABLE IF NOT EXISTS rol_permisos (
    rol_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permiso_id INTEGER NOT NULL REFERENCES permisos(id) ON DELETE CASCADE,
    activo INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (rol_id, permiso_id)
);

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre_completo TEXT NOT NULL,
    usuario TEXT NOT NULL UNIQUE,
    correo TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    rol_id INTEGER NOT NULL REFERENCES roles(id),
    sucursal_id INTEGER REFERENCES sucursales(id),
    activo INTEGER NOT NULL DEFAULT 1,
    foto_url TEXT,
    telefono TEXT,
    ultimo_login TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now')),
    actualizado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sesiones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL,
    ip TEXT,
    user_agent TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now')),
    expira_en TEXT NOT NULL,
    revocado INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS logs_actividad (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER REFERENCES usuarios(id),
    accion TEXT NOT NULL,          -- ej: "producto.crear"
    entidad TEXT,                  -- ej: "productos"
    entidad_id INTEGER,
    detalle TEXT,                  -- JSON con detalles del cambio
    ip TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============ CATEGORÍAS / MARCAS / ETIQUETAS ============

CREATE TABLE IF NOT EXISTS categorias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    categoria_padre_id INTEGER REFERENCES categorias(id),
    orden INTEGER DEFAULT 0,
    activo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS marcas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS etiquetas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
);

-- ============ PRODUCTOS / VARIANTES / IMÁGENES ============

CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    codigo TEXT UNIQUE,             -- código interno
    sku TEXT UNIQUE,
    codigo_barras TEXT UNIQUE,
    descripcion TEXT,
    categoria_id INTEGER REFERENCES categorias(id),
    subcategoria_id INTEGER REFERENCES categorias(id),
    marca_id INTEGER REFERENCES marcas(id),
    proveedor_id INTEGER REFERENCES proveedores(id),
    precio_detal REAL NOT NULL DEFAULT 0,
    precio_mayorista REAL NOT NULL DEFAULT 0,
    costo REAL NOT NULL DEFAULT 0,
    stock_total INTEGER NOT NULL DEFAULT 0,
    stock_minimo INTEGER NOT NULL DEFAULT 0,
    en_oferta INTEGER NOT NULL DEFAULT 0,
    precio_oferta REAL,
    estado TEXT NOT NULL DEFAULT 'activo', -- activo | inactivo | agotado
    creado_en TEXT NOT NULL DEFAULT (datetime('now')),
    actualizado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Variantes: combinación color/talla, cada una con su propio stock
CREATE TABLE IF NOT EXISTS producto_variantes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    color TEXT,
    talla TEXT,
    sku_variante TEXT UNIQUE,
    codigo_barras_variante TEXT UNIQUE,
    stock INTEGER NOT NULL DEFAULT 0,
    precio_detal_override REAL,      -- si es distinto al del producto base
    precio_mayorista_override REAL,
    imagen_url TEXT
);

CREATE TABLE IF NOT EXISTS producto_imagenes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    es_principal INTEGER NOT NULL DEFAULT 0,
    orden INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS producto_etiquetas (
    producto_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    etiqueta_id INTEGER NOT NULL REFERENCES etiquetas(id) ON DELETE CASCADE,
    PRIMARY KEY (producto_id, etiqueta_id)
);

CREATE TABLE IF NOT EXISTS producto_relacionados (
    producto_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    relacionado_id INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
    PRIMARY KEY (producto_id, relacionado_id)
);

CREATE TABLE IF NOT EXISTS cupones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT NOT NULL UNIQUE,
    tipo TEXT NOT NULL,             -- porcentaje | valor_fijo
    valor REAL NOT NULL,
    fecha_inicio TEXT,
    fecha_fin TEXT,
    usos_maximos INTEGER,
    usos_actuales INTEGER DEFAULT 0,
    activo INTEGER NOT NULL DEFAULT 1
);

-- ============ CLIENTES / PROVEEDORES ============

CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre_completo TEXT NOT NULL,
    documento TEXT UNIQUE,
    telefono TEXT,
    correo TEXT,
    direccion TEXT,
    ciudad TEXT,
    saldo_pendiente REAL NOT NULL DEFAULT 0,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS proveedores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre_empresa TEXT NOT NULL,
    contacto TEXT,
    telefono TEXT,
    correo TEXT,
    direccion TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============ MÉTODOS DE PAGO / IMPUESTOS ============

CREATE TABLE IF NOT EXISTS metodos_pago (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE,     -- Efectivo, Nequi, Daviplata...
    icono TEXT,
    color TEXT,
    tipo_recargo TEXT DEFAULT 'ninguno', -- ninguno | porcentaje | valor_fijo
    valor_recargo REAL DEFAULT 0,
    activo INTEGER NOT NULL DEFAULT 1,
    orden INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS impuestos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,           -- IVA 19%
    porcentaje REAL NOT NULL,
    activo INTEGER NOT NULL DEFAULT 1,
    por_defecto INTEGER NOT NULL DEFAULT 0
);

-- ============ CAJA ============

CREATE TABLE IF NOT EXISTS caja_sesiones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    sucursal_id INTEGER REFERENCES sucursales(id),
    monto_apertura REAL NOT NULL DEFAULT 0,
    monto_cierre_esperado REAL,
    monto_cierre_real REAL,
    diferencia REAL,
    estado TEXT NOT NULL DEFAULT 'abierta', -- abierta | cerrada
    abierta_en TEXT NOT NULL DEFAULT (datetime('now')),
    cerrada_en TEXT,
    notas TEXT
);

CREATE TABLE IF NOT EXISTS caja_movimientos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    caja_sesion_id INTEGER NOT NULL REFERENCES caja_sesiones(id) ON DELETE CASCADE,
    tipo TEXT NOT NULL,             -- ingreso | egreso | venta
    concepto TEXT NOT NULL,
    monto REAL NOT NULL,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ============ VENTAS / FACTURACIÓN ============

CREATE TABLE IF NOT EXISTS ventas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero_factura TEXT NOT NULL UNIQUE,
    cliente_id INTEGER REFERENCES clientes(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id), -- vendedor
    caja_sesion_id INTEGER REFERENCES caja_sesiones(id),
    sucursal_id INTEGER REFERENCES sucursales(id),
    subtotal REAL NOT NULL DEFAULT 0,
    descuento_total REAL NOT NULL DEFAULT 0,
    impuesto_total REAL NOT NULL DEFAULT 0,
    total REAL NOT NULL DEFAULT 0,
    tipo_precio TEXT NOT NULL DEFAULT 'detal', -- detal | mayorista
    cupon_id INTEGER REFERENCES cupones(id),
    estado TEXT NOT NULL DEFAULT 'completada', -- completada | anulada | apartado
    es_apartado INTEGER NOT NULL DEFAULT 0,
    abono_apartado REAL DEFAULT 0,
    qr_url TEXT,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS venta_detalle (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    venta_id INTEGER NOT NULL REFERENCES ventas(id) ON DELETE CASCADE,
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    variante_id INTEGER REFERENCES producto_variantes(id),
    cantidad INTEGER NOT NULL,
    precio_unitario REAL NOT NULL,
    descuento REAL NOT NULL DEFAULT 0,
    subtotal REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS venta_pagos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    venta_id INTEGER NOT NULL REFERENCES ventas(id) ON DELETE CASCADE,
    metodo_pago_id INTEGER NOT NULL REFERENCES metodos_pago(id),
    monto REAL NOT NULL
);

-- ============ INVENTARIO / COMPRAS ============

CREATE TABLE IF NOT EXISTS inventario_movimientos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    variante_id INTEGER REFERENCES producto_variantes(id),
    sucursal_id INTEGER REFERENCES sucursales(id),
    tipo TEXT NOT NULL,             -- entrada | salida | transferencia | ajuste
    cantidad INTEGER NOT NULL,
    motivo TEXT,
    usuario_id INTEGER REFERENCES usuarios(id),
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS compras (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proveedor_id INTEGER NOT NULL REFERENCES proveedores(id),
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id),
    sucursal_id INTEGER REFERENCES sucursales(id),
    total REAL NOT NULL DEFAULT 0,
    estado TEXT NOT NULL DEFAULT 'recibida',
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS compra_detalle (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    compra_id INTEGER NOT NULL REFERENCES compras(id) ON DELETE CASCADE,
    producto_id INTEGER NOT NULL REFERENCES productos(id),
    cantidad INTEGER NOT NULL,
    costo_unitario REAL NOT NULL
);

-- ============ CONFIGURACIÓN GENERAL ============

CREATE TABLE IF NOT EXISTS configuracion (
    clave TEXT PRIMARY KEY,
    valor TEXT
);

-- Índices clave para rendimiento con catálogos grandes (100k+ productos)
CREATE INDEX IF NOT EXISTS idx_productos_nombre ON productos(nombre);
CREATE INDEX IF NOT EXISTS idx_productos_codigo ON productos(codigo);
CREATE INDEX IF NOT EXISTS idx_productos_barras ON productos(codigo_barras);
CREATE INDEX IF NOT EXISTS idx_productos_categoria ON productos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_ventas_fecha ON ventas(creado_en);
CREATE INDEX IF NOT EXISTS idx_variantes_producto ON producto_variantes(producto_id);
