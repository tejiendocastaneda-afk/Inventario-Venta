/**
 * Cliente HTTP centralizado hacia la API REST del backend.
 * Todas las peticiones autenticadas incluyen el token JWT guardado
 * en memoria (sesionActual) tras el login.
 */
const API_BASE = '/api';

const Estado = {
  token: null,
  usuario: null,
  permisos: []
};

function tienePermiso(clave) {
  return Estado.usuario?.es_admin || Estado.permisos.includes(clave);
}

async function apiFetch(ruta, { method = 'GET', body, headers = {}, isFormData = false } = {}) {
  const opts = { method, headers: { ...headers } };

  if (Estado.token) opts.headers['Authorization'] = `Bearer ${Estado.token}`;

  if (body !== undefined) {
    if (isFormData) {
      opts.body = body; // el navegador define el Content-Type con boundary
    } else {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
  }

  const resp = await fetch(`${API_BASE}${ruta}`, opts);
  let data = null;
  try { data = await resp.json(); } catch (_) { /* respuesta vacía */ }

  if (!resp.ok) {
    const mensaje = data?.error || `Error ${resp.status}`;
    throw new Error(mensaje);
  }
  return data;
}

const api = {
  login: (usuario, password) => apiFetch('/auth/login', { method: 'POST', body: { usuario, password } }),
  perfil: () => apiFetch('/auth/perfil'),
  cambiarPassword: (password_actual, password_nueva) => apiFetch('/auth/cambiar-password', { method: 'POST', body: { password_actual, password_nueva } }),

  dashboard: () => apiFetch('/dashboard/resumen'),

  productos: {
    buscar: (params = {}) => apiFetch(`/productos?${new URLSearchParams(params)}`),
    obtener: (id) => apiFetch(`/productos/${id}`),
    crear: (datos) => apiFetch('/productos', { method: 'POST', body: datos }),
    actualizar: (id, datos) => apiFetch(`/productos/${id}`, { method: 'PUT', body: datos }),
    eliminar: (id) => apiFetch(`/productos/${id}`, { method: 'DELETE' }),
    subirImagenes: (id, formData) => apiFetch(`/productos/${id}/imagenes`, { method: 'POST', body: formData, isFormData: true })
  },

  categorias: {
    listar: () => apiFetch('/categorias'),
    crear: (datos) => apiFetch('/categorias', { method: 'POST', body: datos }),
    eliminar: (id) => apiFetch(`/categorias/${id}`, { method: 'DELETE' })
  },

  clientes: {
    listar: () => apiFetch('/clientes'),
    crear: (datos) => apiFetch('/clientes', { method: 'POST', body: datos }),
    eliminar: (id) => apiFetch(`/clientes/${id}`, { method: 'DELETE' })
  },

  proveedores: {
    listar: () => apiFetch('/proveedores'),
    crear: (datos) => apiFetch('/proveedores', { method: 'POST', body: datos }),
    eliminar: (id) => apiFetch(`/proveedores/${id}`, { method: 'DELETE' })
  },

  metodosPago: {
    listar: () => apiFetch('/metodos-pago')
  },

  impuestos: {
    listar: () => apiFetch('/impuestos')
  },

  sucursales: {
    listar: () => apiFetch('/sucursales'),
    crear: (datos) => apiFetch('/sucursales', { method: 'POST', body: datos }),
    actualizar: (id, datos) => apiFetch(`/sucursales/${id}`, { method: 'PUT', body: datos }),
    eliminar: (id) => apiFetch(`/sucursales/${id}`, { method: 'DELETE' }),
    stockPorProducto: (productoId) => apiFetch(`/sucursales/stock/${productoId}`),
    transferir: (datos) => apiFetch('/sucursales/transferencias', { method: 'POST', body: datos }),
    listarTransferencias: (params = {}) => apiFetch(`/sucursales/transferencias?${new URLSearchParams(params)}`)
  },

  notificaciones: {
    stockBajo: (params = {}) => apiFetch(`/notificaciones/stock-bajo?${new URLSearchParams(params)}`)
  },

  cupones: {
    validar: (codigo) => apiFetch(`/cupones/validar/${encodeURIComponent(codigo)}`)
  },

  ventas: {
    listar: (params = {}) => apiFetch(`/ventas?${new URLSearchParams(params)}`),
    obtener: (id) => apiFetch(`/ventas/${id}`),
    registrar: (datos) => apiFetch('/ventas', { method: 'POST', body: datos }),
    anular: (id) => apiFetch(`/ventas/${id}/anular`, { method: 'POST' })
  },

  caja: {
    actual: () => apiFetch('/caja/actual'),
    abrir: (datos) => apiFetch('/caja/abrir', { method: 'POST', body: datos }),
    cerrar: (id, datos) => apiFetch(`/caja/${id}/cerrar`, { method: 'POST', body: datos })
  },

  usuarios: {
    listar: () => apiFetch('/usuarios'),
    crear: (datos) => apiFetch('/usuarios', { method: 'POST', body: datos })
  },

  roles: {
    listar: () => apiFetch('/roles'),
    crear: (datos) => apiFetch('/roles', { method: 'POST', body: datos }),
    permisos: (id) => apiFetch(`/roles/${id}/permisos`),
    actualizarPermisos: (id, permisos) => apiFetch(`/roles/${id}/permisos`, { method: 'PUT', body: { permisos } })
  },

  compras: {
    listar: () => apiFetch('/compras'),
    registrar: (datos) => apiFetch('/compras', { method: 'POST', body: datos })
  },

  apartados: {
    listar: () => apiFetch('/apartados'),
    abonar: (id, monto) => apiFetch(`/apartados/${id}/abonos`, { method: 'POST', body: { monto } })
  },

  reportes: {
    ventasPeriodo: (params = {}) => apiFetch(`/reportes/ventas-periodo?${new URLSearchParams(params)}`),
    masVendidos: () => apiFetch('/reportes/productos-mas-vendidos'),
    sinMovimiento: () => apiFetch('/reportes/productos-sin-movimiento'),
    ganancias: (params = {}) => apiFetch(`/reportes/ganancias?${new URLSearchParams(params)}`),
    inventario: () => apiFetch('/reportes/inventario'),
    clientesSaldo: () => apiFetch('/reportes/clientes-saldo')
  },

  configuracion: {
    obtener: () => apiFetch('/configuracion'),
    guardar: (datos) => apiFetch('/configuracion', { method: 'PUT', body: datos })
  },

  importador: {
    previsualizar: (formData) => apiFetch('/importador/previsualizar', { method: 'POST', body: formData, isFormData: true }),
    importar: (formData) => apiFetch('/importador/importar', { method: 'POST', body: formData, isFormData: true })
  }
};

/** Descarga un endpoint de reporte en el formato solicitado (csv | pdf) */
function descargarReporte(ruta, nombreArchivo, formato = 'csv') {
  const url = `${API_BASE}${ruta}${ruta.includes('?') ? '&' : '?'}formato_salida=${formato}`;
  fetch(url, { headers: { Authorization: `Bearer ${Estado.token}` } })
    .then(resp => resp.blob())
    .then(blob => {
      const enlace = document.createElement('a');
      enlace.href = URL.createObjectURL(blob);
      enlace.download = nombreArchivo.replace(/\.(csv|pdf)$/, `.${formato}`);
      enlace.click();
    })
    .catch(err => mostrarToast('No se pudo descargar el archivo: ' + err.message, 'error'));
}
// Alias retrocompatible
function descargarCSV(ruta, nombreArchivo) { descargarReporte(ruta, nombreArchivo, 'csv'); }


function mostrarToast(mensaje, tipo = 'info') {
  const contenedor = document.getElementById('toasts');
  const toast = document.createElement('div');
  toast.className = `toast ${tipo}`;
  toast.textContent = mensaje;
  contenedor.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
