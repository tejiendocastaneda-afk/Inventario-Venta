/**
 * Router simple de la SPA: cada item del menú lateral invoca una
 * función de render que llena #vista-contenedor.
 */
const VISTAS = {
  dashboard: { titulo: 'Dashboard', render: renderDashboard },
  pos: { titulo: 'Punto de Venta', render: renderPOS },
  productos: { titulo: 'Productos', render: renderProductos },
  ventas: { titulo: 'Historial de Ventas', render: renderVentas },
  caja: { titulo: 'Caja', render: renderCajaVista },
  categorias: { titulo: 'Categorías', render: (c) => renderCrudSimple(c, 'Categorías', api.categorias, [{ campo: 'nombre', etiqueta: 'Nombre' }]) },
  clientes: { titulo: 'Clientes', render: (c) => renderCrudSimple(c, 'Clientes', api.clientes, [
      { campo: 'nombre_completo', etiqueta: 'Nombre completo' },
      { campo: 'documento', etiqueta: 'Documento' },
      { campo: 'telefono', etiqueta: 'Teléfono' },
      { campo: 'correo', etiqueta: 'Correo' }
  ]) },
  proveedores: { titulo: 'Proveedores', render: (c) => renderCrudSimple(c, 'Proveedores', api.proveedores, [
      { campo: 'nombre_empresa', etiqueta: 'Empresa' },
      { campo: 'contacto', etiqueta: 'Contacto' },
      { campo: 'telefono', etiqueta: 'Teléfono' },
      { campo: 'correo', etiqueta: 'Correo' }
  ]) },
  usuarios: { titulo: 'Usuarios', render: renderUsuarios },
  roles: { titulo: 'Roles y permisos', render: renderRoles },
  configuracion: { titulo: 'Configuración', render: renderConfiguracion },
  compras: { titulo: 'Compras a proveedores', render: renderCompras },
  transferencias: { titulo: 'Transferencias entre sucursales', render: renderTransferencias },
  apartados: { titulo: 'Apartados', render: renderApartados },
  reportes: { titulo: 'Reportes', render: renderReportes },
  importar: { titulo: 'Importar productos', render: renderImportador },
  ofertas: { titulo: 'Ofertas', render: renderOfertas },
  sucursales: { titulo: 'Sucursales', render: (c) => renderCrudSimple(c, 'Sucursales', api.sucursales, [
      { campo: 'nombre', etiqueta: 'Nombre' },
      { campo: 'ciudad', etiqueta: 'Ciudad' },
      { campo: 'direccion', etiqueta: 'Dirección' },
      { campo: 'telefono', etiqueta: 'Teléfono' }
  ]) }
};


function iniciarNavegacion() {
  const nav = document.getElementById('nav-principal');
  nav.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => irAVista(item.dataset.vista));
  });
  irAVista('dashboard');
  iniciarNotificaciones();
}

async function iniciarNotificaciones() {
  const boton = document.getElementById('btn-notificaciones');
  const badge = document.getElementById('badge-notificaciones');

  async function actualizarBadge() {
    try {
      const productos = await api.notificaciones.stockBajo();
      if (productos.length > 0) {
        badge.textContent = productos.length;
        badge.classList.remove('oculto');
      } else {
        badge.classList.add('oculto');
      }
      return productos;
    } catch (_) { return []; }
  }

  boton.addEventListener('click', async () => {
    const productos = await actualizarBadge();
    crearModal(`
      <h3>Alertas de stock bajo${!Estado.usuario.es_admin ? ` — ${Estado.usuario.sucursal_nombre || 'tu sucursal'}` : ''}</h3>
      ${productos.length ? `
        <ul class="lista-simple">
          ${productos.map(p => `
            <li>
              <span>${p.nombre}${p.codigo ? ` (${p.codigo})` : ''}${p.sucursal_nombre ? ` · ${p.sucursal_nombre}` : ''}</span>
              <strong style="color:var(--rojo-600);">${p.stock} / mín. ${p.stock_minimo}</strong>
            </li>
          `).join('')}
        </ul>
      ` : `<p style="color:var(--texto-tenue);">No hay productos con stock bajo por ahora. 🎉</p>`}
      <button class="btn btn-primario" data-cerrar style="width:100%; margin-top:14px;">Cerrar</button>
    `);
  });

  await actualizarBadge();
  // Revisa cada 2 minutos si algo cambió (nuevas ventas, transferencias, etc.)
  setInterval(actualizarBadge, 120000);
}

async function irAVista(clave) {
  const vista = VISTAS[clave];
  if (!vista) return;

  document.querySelectorAll('.nav-item').forEach(i => i.classList.toggle('activo', i.dataset.vista === clave));
  document.getElementById('titulo-vista').textContent = vista.titulo;

  const contenedor = document.getElementById('vista-contenedor');
  contenedor.innerHTML = '';
  await vista.render(contenedor);
}

/* ---------- Historial de ventas ---------- */
async function renderVentas(contenedor) {
  contenedor.innerHTML = `<p style="color:var(--texto-tenue)">Cargando ventas…</p>`;
  try {
    const ventas = await api.ventas.listar({ por_pagina: 50 });
    contenedor.innerHTML = `
      <div class="tarjeta">
        <table class="tabla">
          <thead><tr><th>Factura</th><th>Fecha</th><th>Cliente</th><th>Vendedor</th><th>Total</th><th>Estado</th></tr></thead>
          <tbody>
            ${ventas.length ? ventas.map(v => `
              <tr>
                <td>${v.numero_factura}</td>
                <td>${new Date(v.creado_en).toLocaleString('es-CO')}</td>
                <td>${v.cliente_nombre || 'Cliente general'}</td>
                <td>${v.vendedor_nombre}</td>
                <td>${formatoCOP(v.total)}</td>
                <td><span class="badge ${v.estado === 'completada' ? 'badge-verde' : v.estado === 'anulada' ? 'badge-rojo' : 'badge-ocre'}">${v.estado}</span></td>
              </tr>
            `).join('') : `<tr><td colspan="6" style="text-align:center; color:var(--texto-tenue);">Aún no hay ventas registradas.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    contenedor.innerHTML = `<p style="color:var(--rojo-600)">${err.message}</p>`;
  }
}

/* ---------- Caja: historial de sesiones ---------- */
async function renderCajaVista(contenedor) {
  contenedor.innerHTML = `<p style="color:var(--texto-tenue)">Consulta el módulo de <strong>Punto de Venta</strong> para abrir o cerrar caja. Aquí verás el historial una vez tengas sesiones registradas.</p>`;
}

/* ---------- CRUD simple reutilizable (categorías, clientes, proveedores) ---------- */
async function renderCrudSimple(contenedor, titulo, recurso, campos) {
  contenedor.innerHTML = `
    <div class="fila entre gap-12" style="margin-bottom:16px;">
      <span></span>
      <button class="btn btn-acento" id="btn-nuevo-registro">+ Nuevo</button>
    </div>
    <div class="tarjeta">
      <table class="tabla">
        <thead><tr>${campos.map(c => `<th>${c.etiqueta}</th>`).join('')}<th></th></tr></thead>
        <tbody id="cuerpo-tabla"><tr><td colspan="${campos.length + 1}">Cargando…</td></tr></tbody>
      </table>
    </div>
  `;

  async function recargar() {
    const cuerpo = document.getElementById('cuerpo-tabla');
    try {
      const registros = await recurso.listar();
      cuerpo.innerHTML = registros.length ? registros.map(r => `
        <tr>
          ${campos.map(c => `<td>${r[c.campo] ?? ''}</td>`).join('')}
          <td><button class="btn btn-peligro btn-sm" data-eliminar="${r.id}">Eliminar</button></td>
        </tr>
      `).join('') : `<tr><td colspan="${campos.length + 1}" style="text-align:center; color:var(--texto-tenue);">Sin registros todavía.</td></tr>`;

      cuerpo.querySelectorAll('[data-eliminar]').forEach(btn => {
        btn.addEventListener('click', async () => {
          if (!confirm('¿Eliminar este registro?')) return;
          try { await recurso.eliminar(btn.dataset.eliminar); recargar(); }
          catch (err) { mostrarToast(err.message, 'error'); }
        });
      });
    } catch (err) {
      cuerpo.innerHTML = `<tr><td colspan="${campos.length + 1}" style="color:var(--rojo-600)">${err.message}</td></tr>`;
    }
  }

  document.getElementById('btn-nuevo-registro').addEventListener('click', () => {
    const fondo = crearModal(`
      <h3>Nuevo registro — ${titulo}</h3>
      <form id="form-crud-simple">
        ${campos.map(c => `<div class="campo"><label>${c.etiqueta}</label><input name="${c.campo}"></div>`).join('')}
        <div class="fila entre gap-12" style="margin-top:16px;">
          <button type="button" class="btn btn-fantasma" data-cerrar>Cancelar</button>
          <button type="submit" class="btn btn-primario">Guardar</button>
        </div>
      </form>
    `);
    fondo.querySelector('#form-crud-simple').addEventListener('submit', async (e) => {
      e.preventDefault();
      const datos = Object.fromEntries(new FormData(e.target).entries());
      try { await recurso.crear(datos); fondo.remove(); recargar(); }
      catch (err) { mostrarToast(err.message, 'error'); }
    });
  });

  recargar();
}

/* ---------- Usuarios ---------- */
async function renderUsuarios(contenedor) {
  contenedor.innerHTML = `<p style="color:var(--texto-tenue)">Cargando usuarios…</p>`;
  try {
    const [usuarios, roles, sucursales] = await Promise.all([api.usuarios.listar(), api.roles.listar(), api.sucursales.listar()]);
    contenedor.innerHTML = `
      <div class="fila entre gap-12" style="margin-bottom:16px;">
        <span></span>
        <button class="btn btn-acento" id="btn-nuevo-usuario">+ Nuevo usuario</button>
      </div>
      <div class="tarjeta">
        <table class="tabla">
          <thead><tr><th>Nombre</th><th>Usuario</th><th>Rol</th><th>Sucursal</th><th>Estado</th></tr></thead>
          <tbody>
            ${usuarios.map(u => `
              <tr>
                <td>${u.nombre_completo}</td>
                <td>${u.usuario}</td>
                <td>${u.rol_nombre}</td>
                <td>${u.sucursal_nombre || '—'}</td>
                <td><span class="badge ${u.activo ? 'badge-verde' : 'badge-rojo'}">${u.activo ? 'Activo' : 'Inactivo'}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    document.getElementById('btn-nuevo-usuario').addEventListener('click', () => {
      const fondo = crearModal(`
        <h3>Nuevo usuario</h3>
        <form id="form-usuario">
          <div class="campo"><label>Nombre completo</label><input name="nombre_completo" required></div>
          <div class="campo"><label>Usuario</label><input name="usuario" required></div>
          <div class="campo"><label>Correo</label><input type="email" name="correo"></div>
          <div class="campo"><label>Contraseña</label><input type="password" name="password" required></div>
          <div class="campo">
            <label>Rol</label>
            <select name="rol_id">${roles.map(r => `<option value="${r.id}">${r.nombre}</option>`).join('')}</select>
          </div>
          <div class="campo">
            <label>Sucursal</label>
            <select name="sucursal_id">
              <option value="">Sin asignar</option>
              ${sucursales.map(s => `<option value="${s.id}">${s.nombre}</option>`).join('')}
            </select>
          </div>
          <div class="fila entre gap-12" style="margin-top:16px;">
            <button type="button" class="btn btn-fantasma" data-cerrar>Cancelar</button>
            <button type="submit" class="btn btn-primario">Crear usuario</button>
          </div>
        </form>
      `);
      fondo.querySelector('#form-usuario').addEventListener('submit', async (e) => {
        e.preventDefault();
        const datos = Object.fromEntries(new FormData(e.target).entries());
        if (!datos.sucursal_id) delete datos.sucursal_id;
        try { await api.usuarios.crear(datos); mostrarToast('Usuario creado.', 'exito'); fondo.remove(); renderUsuarios(contenedor); }
        catch (err) { mostrarToast(err.message, 'error'); }
      });
    });
  } catch (err) {
    contenedor.innerHTML = `<p style="color:var(--rojo-600)">${err.message}</p>`;
  }
}

/* ---------- Roles y permisos ---------- */
async function renderRoles(contenedor) {
  contenedor.innerHTML = `<div class="fila gap-16" style="align-items:flex-start;" id="layout-roles"></div>`;
  const layout = document.getElementById('layout-roles');
  layout.innerHTML = `
    <div class="tarjeta tarjeta-pad" style="width:240px; flex-shrink:0;">
      <div class="fila entre" style="margin-bottom:10px;"><strong>Roles</strong><button class="btn btn-sm btn-acento" id="btn-nuevo-rol">+</button></div>
      <div id="lista-roles"></div>
    </div>
    <div class="tarjeta tarjeta-pad" style="flex:1;" id="panel-permisos">
      <p style="color:var(--texto-tenue)">Selecciona un rol para configurar sus permisos.</p>
    </div>
  `;

  const roles = await api.roles.listar();
  document.getElementById('lista-roles').innerHTML = roles.map(r => `
    <div class="nav-item" data-rol="${r.id}" style="color:var(--texto); margin-bottom:4px;">${r.nombre}${r.es_sistema ? ' 🔒' : ''}</div>
  `).join('');

  document.querySelectorAll('[data-rol]').forEach(el => {
    el.addEventListener('click', () => cargarPermisosDeRol(el.dataset.rol, el.textContent.replace('🔒', '').trim()));
  });

  document.getElementById('btn-nuevo-rol').addEventListener('click', () => {
    const fondo = crearModal(`
      <h3>Nuevo rol</h3>
      <form id="form-rol">
        <div class="campo"><label>Nombre del rol</label><input name="nombre" required></div>
        <div class="campo"><label>Descripción</label><input name="descripcion"></div>
        <div class="fila entre gap-12" style="margin-top:16px;">
          <button type="button" class="btn btn-fantasma" data-cerrar>Cancelar</button>
          <button type="submit" class="btn btn-primario">Crear rol</button>
        </div>
      </form>
    `);
    fondo.querySelector('#form-rol').addEventListener('submit', async (e) => {
      e.preventDefault();
      const datos = Object.fromEntries(new FormData(e.target).entries());
      try { await api.roles.crear(datos); fondo.remove(); renderRoles(contenedor); }
      catch (err) { mostrarToast(err.message, 'error'); }
    });
  });
}

async function cargarPermisosDeRol(rolId, nombreRol) {
  const panel = document.getElementById('panel-permisos');
  panel.innerHTML = `<p style="color:var(--texto-tenue)">Cargando permisos…</p>`;

  const permisos = await api.roles.permisos(rolId);
  const porModulo = {};
  permisos.forEach(p => { (porModulo[p.modulo] ||= []).push(p); });

  panel.innerHTML = `
    <h3 style="margin-top:0;">Permisos de "${nombreRol}"</h3>
    <form id="form-permisos">
      ${Object.entries(porModulo).map(([modulo, lista]) => `
        <div style="margin-bottom:16px;">
          <div style="font-weight:700; font-size:.85rem; text-transform:uppercase; color:var(--texto-tenue); margin-bottom:8px;">${modulo}</div>
          ${lista.map(p => `
            <label class="fila gap-8" style="padding:6px 0; font-size:.88rem; cursor:pointer;">
              <input type="checkbox" data-permiso="${p.id}" ${p.activo ? 'checked' : ''}>
              ${p.etiqueta}
            </label>
          `).join('')}
        </div>
      `).join('')}
      <button type="submit" class="btn btn-primario">Guardar permisos</button>
    </form>
  `;

  document.getElementById('form-permisos').addEventListener('submit', async (e) => {
    e.preventDefault();
    const checks = panel.querySelectorAll('[data-permiso]');
    const permisosPayload = Array.from(checks).map(c => ({ permiso_id: Number(c.dataset.permiso), activo: c.checked ? 1 : 0 }));
    try {
      await api.roles.actualizarPermisos(rolId, permisosPayload);
      mostrarToast('Permisos actualizados.', 'exito');
    } catch (err) {
      mostrarToast(err.message, 'error');
    }
  });
}

/* ---------- Configuración general ---------- */
async function renderConfiguracion(contenedor) {
  contenedor.innerHTML = `<p style="color:var(--texto-tenue)">Cargando configuración…</p>`;
  let config = {};
  try { config = await api.configuracion.obtener(); } catch (_) { config = {}; }

  contenedor.innerHTML = `
    <div class="tarjeta tarjeta-pad" style="max-width:560px; margin-bottom:20px;">
      <h3 style="margin-top:0;">Datos del negocio</h3>
      <form id="form-config">
        <div class="campo"><label>Nombre del negocio</label><input name="nombre_negocio" value="${config.nombre_negocio || 'Tejidos Castañeda'}"></div>
        <div class="campo"><label>URL del logo (opcional)</label><input name="logo_url" value="${config.logo_url || ''}"></div>
        <div class="fila gap-12">
          <div class="campo" style="flex:1"><label>Moneda</label><input name="moneda" value="${config.moneda || 'COP'}"></div>
          <div class="campo" style="flex:1">
            <label>Formato de fecha</label>
            <select name="formato_fecha">
              <option ${config.formato_fecha === 'DD/MM/YYYY' ? 'selected' : ''}>DD/MM/YYYY</option>
              <option ${config.formato_fecha === 'MM/DD/YYYY' ? 'selected' : ''}>MM/DD/YYYY</option>
              <option ${config.formato_fecha === 'YYYY-MM-DD' ? 'selected' : ''}>YYYY-MM-DD</option>
            </select>
          </div>
        </div>
        <div class="campo">
          <label>Sitio web (para el QR de la factura)</label>
          <input name="sitio_web" value="${config.sitio_web || ''}" placeholder="https://tejidoscastaneda.com">
        </div>
        <button type="submit" class="btn btn-primario">Guardar configuración</button>
      </form>
    </div>

    <div class="tarjeta tarjeta-pad" style="max-width:560px;">
      <h3 style="margin-top:0;">Cambiar mi contraseña</h3>
      <p style="color:var(--texto-tenue); font-size:.85rem; margin-top:-8px;">
        Cambia la contraseña de tu propia cuenta (<strong>${Estado.usuario.usuario}</strong>).
      </p>
      <div id="cambiar-password-error" class="login-error oculto"></div>
      <form id="form-cambiar-password">
        <div class="campo"><label>Contraseña actual</label><input type="password" name="password_actual" required></div>
        <div class="campo"><label>Contraseña nueva</label><input type="password" name="password_nueva" minlength="6" required></div>
        <div class="campo"><label>Confirmar contraseña nueva</label><input type="password" name="password_confirmar" minlength="6" required></div>
        <button type="submit" class="btn btn-primario">Cambiar contraseña</button>
      </form>
    </div>
  `;

  document.getElementById('form-config').addEventListener('submit', async (e) => {
    e.preventDefault();
    const datos = Object.fromEntries(new FormData(e.target).entries());
    try {
      await api.configuracion.guardar(datos);
      mostrarToast('Configuración guardada.', 'exito');
    } catch (err) {
      mostrarToast(err.message, 'error');
    }
  });

  document.getElementById('form-cambiar-password').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorDiv = document.getElementById('cambiar-password-error');
    errorDiv.classList.add('oculto');
    const datos = Object.fromEntries(new FormData(e.target).entries());

    if (datos.password_nueva !== datos.password_confirmar) {
      errorDiv.textContent = 'La confirmación no coincide con la contraseña nueva.';
      errorDiv.classList.remove('oculto');
      return;
    }

    try {
      await api.cambiarPassword(datos.password_actual, datos.password_nueva);
      mostrarToast('Contraseña actualizada correctamente.', 'exito');
      e.target.reset();
    } catch (err) {
      errorDiv.textContent = err.message;
      errorDiv.classList.remove('oculto');
    }
  });
}

