/**
 * Manejo de sesión: login, logout y arranque de la app cuando ya
 * hay una sesión guardada (sessionStorage, se limpia al cerrar pestaña).
 */
document.addEventListener('DOMContentLoaded', () => {
  const formLogin = document.getElementById('form-login');
  const loginError = document.getElementById('login-error');

  const sesionGuardada = sessionStorage.getItem('tc_sesion');
  if (sesionGuardada) {
    try {
      const datos = JSON.parse(sesionGuardada);
      Estado.token = datos.token;
      Estado.usuario = datos.usuario;
      Estado.permisos = datos.permisos;
      mostrarApp();
    } catch (_) { sessionStorage.removeItem('tc_sesion'); }
  }

  formLogin.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('oculto');
    const usuario = document.getElementById('login-usuario').value.trim();
    const password = document.getElementById('login-password').value;

    try {
      const resp = await api.login(usuario, password);
      Estado.token = resp.token;
      Estado.usuario = resp.usuario;
      Estado.permisos = resp.permisos;
      sessionStorage.setItem('tc_sesion', JSON.stringify(resp));
      mostrarApp();
    } catch (err) {
      loginError.textContent = err.message;
      loginError.classList.remove('oculto');
    }
  });

  document.getElementById('btn-logout').addEventListener('click', () => {
    sessionStorage.removeItem('tc_sesion');
    Estado.token = null;
    Estado.usuario = null;
    Estado.permisos = [];
    document.getElementById('app-shell').classList.add('oculto');
    document.getElementById('pantalla-login').classList.remove('oculto');
  });
});

function mostrarApp() {
  document.getElementById('pantalla-login').classList.add('oculto');
  document.getElementById('app-shell').classList.remove('oculto');

  document.getElementById('nombre-usuario').textContent = Estado.usuario.nombre_completo;
  document.getElementById('rol-usuario').textContent = Estado.usuario.rol_nombre;
  document.getElementById('sucursal-usuario').textContent = Estado.usuario.sucursal_nombre || 'Sin sucursal asignada';
  document.getElementById('avatar-usuario').textContent = Estado.usuario.nombre_completo.charAt(0).toUpperCase();

  if (!Estado.usuario.es_admin) {
    document.getElementById('grupo-admin').classList.add('oculto');
  }

  if (typeof iniciarNavegacion === 'function') iniciarNavegacion();
}
