function formatoCOP(valor) {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(valor || 0);
}

async function renderDashboard(contenedor) {
  contenedor.innerHTML = `<p style="color:var(--texto-tenue)">Cargando indicadores…</p>`;

  let d;
  try {
    d = await api.dashboard();
  } catch (err) {
    contenedor.innerHTML = `<p style="color:var(--rojo-600)">No se pudo cargar el dashboard: ${err.message}</p>`;
    return;
  }

  const maxVenta = Math.max(1, ...d.ventas_ultimos_7_dias.map(v => v.total));

  contenedor.innerHTML = `
    <div class="grid kpis">
      <div class="tarjeta kpi">
        <div class="etiqueta">Ventas de hoy</div>
        <div class="valor">${formatoCOP(d.ventas_hoy.total)}</div>
        <div class="sub">${d.ventas_hoy.cantidad} transacciones</div>
      </div>
      <div class="tarjeta kpi">
        <div class="etiqueta">Ventas del mes</div>
        <div class="valor">${formatoCOP(d.ventas_mes.total)}</div>
        <div class="sub">${d.ventas_mes.cantidad} transacciones</div>
      </div>
      <div class="tarjeta kpi">
        <div class="etiqueta">Productos activos</div>
        <div class="valor">${d.productos_activos}</div>
        <div class="sub">${d.productos_bajo_stock} con stock bajo</div>
      </div>
      <div class="tarjeta kpi">
        <div class="etiqueta">Clientes</div>
        <div class="valor">${d.clientes_total}</div>
        <div class="sub">${d.cajas_abiertas} caja(s) abierta(s)</div>
      </div>
    </div>

    <div class="grid paneles-dash">
      <div class="tarjeta tarjeta-pad">
        <h3 style="margin-top:0;">Ventas — últimos 7 días</h3>
        <div class="mini-grafico">
          ${d.ventas_ultimos_7_dias.length ? d.ventas_ultimos_7_dias.map(v => `
            <div class="barra" style="height:${Math.max(4, (v.total / maxVenta) * 100)}%;" title="${formatoCOP(v.total)}">
              <span class="etq">${v.fecha.slice(5)}</span>
            </div>
          `).join('') : '<p style="color:var(--texto-tenue)">Aún no hay ventas registradas.</p>'}
        </div>
      </div>
      <div class="tarjeta tarjeta-pad">
        <h3 style="margin-top:0;">Productos más vendidos</h3>
        <ul class="lista-simple">
          ${d.productos_mas_vendidos.length ? d.productos_mas_vendidos.map(p => `
            <li><span>${p.nombre}</span><strong>${p.unidades_vendidas} und.</strong></li>
          `).join('') : '<li style="color:var(--texto-tenue)">Sin datos todavía.</li>'}
        </ul>
      </div>
    </div>
  `;
}
