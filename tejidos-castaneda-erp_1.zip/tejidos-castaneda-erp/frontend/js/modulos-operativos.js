/* ============================================================
   COMPRAS A PROVEEDORES
   ============================================================ */
async function renderCompras(contenedor) {
  contenedor.innerHTML = `
    <div class="fila entre gap-12" style="margin-bottom:16px;">
      <span></span>
      <button class="btn btn-acento" id="btn-nueva-compra">+ Registrar compra</button>
    </div>
    <div class="tarjeta">
      <table class="tabla">
        <thead><tr><th>#</th><th>Proveedor</th><th>Sucursal</th><th>Total</th><th>Estado</th><th>Fecha</th></tr></thead>
        <tbody id="cuerpo-compras"><tr><td colspan="6">Cargando…</td></tr></tbody>
      </table>
    </div>
  `;

  async function recargar() {
    try {
      const compras = await api.compras.listar();
      document.getElementById('cuerpo-compras').innerHTML = compras.length ? compras.map(c => `
        <tr><td>#${c.id}</td><td>${c.proveedor_nombre}</td><td>${c.sucursal_nombre || '—'}</td><td>${formatoCOP(c.total)}</td>
        <td><span class="badge badge-verde">${c.estado}</span></td><td>${new Date(c.creado_en).toLocaleDateString('es-CO')}</td></tr>
      `).join('') : `<tr><td colspan="6" style="text-align:center; color:var(--texto-tenue);">Sin compras registradas.</td></tr>`;
    } catch (err) { mostrarToast(err.message, 'error'); }
  }

  document.getElementById('btn-nueva-compra').addEventListener('click', async () => {
    const [proveedores, sucursales] = await Promise.all([api.proveedores.listar(), api.sucursales.listar()]);
    if (!proveedores.length) return mostrarToast('Primero crea un proveedor en el módulo Proveedores.', 'error');

    let items = [];
    const fondo = crearModal(`
      <h3>Registrar compra</h3>
      <div class="campo">
        <label>Proveedor</label>
        <select id="compra-proveedor">${proveedores.map(p => `<option value="${p.id}">${p.nombre_empresa}</option>`).join('')}</select>
      </div>
      ${sucursales.length > 1 ? `
        <div class="campo">
          <label>Sucursal que recibe la mercancía</label>
          <select id="compra-sucursal">${sucursales.map(s => `<option value="${s.id}" ${s.id === Estado.usuario.sucursal_id ? 'selected' : ''}>${s.nombre}</option>`).join('')}</select>
        </div>
      ` : ''}
      <div class="campo">
        <label>Buscar producto para agregar</label>
        <input type="search" id="compra-buscador-producto" placeholder="Nombre o código…">
        <div id="compra-resultados" style="max-height:140px; overflow-y:auto;"></div>
      </div>
      <div id="compra-items" style="margin:12px 0;"><p style="color:var(--texto-tenue); font-size:.85rem;">Aún no hay productos agregados.</p></div>
      <div class="fila entre gap-12" style="margin-top:14px;">
        <button type="button" class="btn btn-fantasma" data-cerrar>Cancelar</button>
        <button type="button" class="btn btn-acento" id="btn-guardar-compra">Guardar compra</button>
      </div>
    `);

    function pintarItems() {
      const cont = document.getElementById('compra-items');
      cont.innerHTML = items.length ? items.map((it, i) => `
        <div class="fila entre gap-8" style="padding:6px 0; font-size:.85rem;">
          <span>${it.nombre}</span>
          <span class="fila gap-8">
            Cant: <input type="number" min="1" value="${it.cantidad}" data-idx="${i}" data-campo="cantidad" style="width:60px;">
            Costo: <input type="number" min="0" value="${it.costo_unitario}" data-idx="${i}" data-campo="costo_unitario" style="width:90px;">
          </span>
        </div>
      `).join('') : '<p style="color:var(--texto-tenue); font-size:.85rem;">Aún no hay productos agregados.</p>';

      cont.querySelectorAll('input').forEach(inp => {
        inp.addEventListener('input', () => {
          items[inp.dataset.idx][inp.dataset.campo] = Number(inp.value) || 0;
        });
      });
    }

    document.getElementById('compra-buscador-producto').addEventListener('input', async (e) => {
      const q = e.target.value;
      if (!q) { document.getElementById('compra-resultados').innerHTML = ''; return; }
      const resp = await api.productos.buscar({ q, por_pagina: 6 });
      document.getElementById('compra-resultados').innerHTML = resp.productos.map(p => `
        <div class="nav-item" style="color:var(--texto);" data-id="${p.id}" data-nombre="${p.nombre}" data-costo="${p.costo}">${p.nombre}</div>
      `).join('');
      document.querySelectorAll('#compra-resultados [data-id]').forEach(el => {
        el.addEventListener('click', () => {
          items.push({ producto_id: Number(el.dataset.id), nombre: el.dataset.nombre, cantidad: 1, costo_unitario: Number(el.dataset.costo) || 0 });
          pintarItems();
        });
      });
    });

    document.getElementById('btn-guardar-compra').addEventListener('click', async () => {
      if (!items.length) return mostrarToast('Agrega al menos un producto.', 'error');
      try {
        const selectSucursal = document.getElementById('compra-sucursal');
        await api.compras.registrar({
          proveedor_id: Number(document.getElementById('compra-proveedor').value),
          sucursal_id: selectSucursal ? Number(selectSucursal.value) : undefined,
          items: items.map(({ producto_id, cantidad, costo_unitario }) => ({ producto_id, cantidad, costo_unitario }))
        });
        mostrarToast('Compra registrada. Stock actualizado.', 'exito');
        fondo.remove();
        recargar();
      } catch (err) { mostrarToast(err.message, 'error'); }
    });
  });

  recargar();
}

/* ============================================================
   APARTADOS (SEPARE) CON ABONOS
   ============================================================ */
async function renderApartados(contenedor) {
  contenedor.innerHTML = `<p style="color:var(--texto-tenue)">Cargando apartados…</p>`;
  try {
    const apartados = await api.apartados.listar();
    contenedor.innerHTML = `
      <div class="tarjeta">
        <table class="tabla">
          <thead><tr><th>Factura</th><th>Cliente</th><th>Total</th><th>Abonado</th><th>Saldo</th><th></th></tr></thead>
          <tbody>
            ${apartados.length ? apartados.map(a => `
              <tr>
                <td>${a.numero_factura}</td>
                <td>${a.cliente_nombre}<br><span style="font-size:.72rem; color:var(--texto-tenue);">${a.telefono || ''}</span></td>
                <td>${formatoCOP(a.total)}</td>
                <td>${formatoCOP(a.abono_apartado)}</td>
                <td><strong>${formatoCOP(a.saldo)}</strong></td>
                <td><button class="btn btn-sm btn-primario" data-abonar="${a.id}" data-saldo="${a.saldo}">Registrar abono</button></td>
              </tr>
            `).join('') : `<tr><td colspan="6" style="text-align:center; color:var(--texto-tenue);">No hay apartados pendientes.</td></tr>`}
          </tbody>
        </table>
      </div>
    `;

    contenedor.querySelectorAll('[data-abonar]').forEach(btn => {
      btn.addEventListener('click', () => {
        const fondo = crearModal(`
          <h3>Registrar abono</h3>
          <p style="color:var(--texto-tenue); font-size:.85rem;">Saldo pendiente: <strong>${formatoCOP(btn.dataset.saldo)}</strong></p>
          <div class="campo"><label>Monto del abono</label><input type="number" id="monto-abono" max="${btn.dataset.saldo}" required></div>
          <div class="fila entre gap-12" style="margin-top:14px;">
            <button class="btn btn-fantasma" data-cerrar>Cancelar</button>
            <button class="btn btn-acento" id="btn-confirmar-abono">Guardar abono</button>
          </div>
        `);
        fondo.querySelector('#btn-confirmar-abono').addEventListener('click', async () => {
          try {
            await api.apartados.abonar(btn.dataset.abonar, Number(document.getElementById('monto-abono').value));
            mostrarToast('Abono registrado.', 'exito');
            fondo.remove();
            renderApartados(contenedor);
          } catch (err) { mostrarToast(err.message, 'error'); }
        });
      });
    });
  } catch (err) {
    contenedor.innerHTML = `<p style="color:var(--rojo-600)">${err.message}</p>`;
  }
}

/* ============================================================
   REPORTES
   ============================================================ */
async function renderReportes(contenedor) {
  const reportes = [
    { id: 'ventas', ruta: '/reportes/ventas-periodo', archivo: 'ventas_por_periodo', titulo: 'Ventas por período', desc: 'Agrupadas por día, con totales y descuentos.' },
    { id: 'masvendidos', ruta: '/reportes/productos-mas-vendidos', archivo: 'productos_mas_vendidos', titulo: 'Productos más vendidos', desc: 'Top 50 por unidades vendidas.' },
    { id: 'sinmov', ruta: '/reportes/productos-sin-movimiento', archivo: 'productos_sin_movimiento', titulo: 'Productos sin movimiento', desc: 'Productos activos que nunca se han vendido.' },
    { id: 'ganancias', ruta: '/reportes/ganancias', archivo: 'ganancias_periodo', titulo: 'Ganancias por día', desc: 'Ingresos vs. costo de productos vendidos.' },
    { id: 'inventario', ruta: '/reportes/inventario', archivo: 'inventario_actual', titulo: 'Inventario actual', desc: 'Stock y valor de inventario por producto.' },
    { id: 'saldos', ruta: '/reportes/clientes-saldo', archivo: 'clientes_saldo_pendiente', titulo: 'Clientes con saldo pendiente', desc: 'Clientes con apartados sin terminar de pagar.' }
  ];

  let sucursalSeleccionada = '';
  let selectorHTML = '';
  if (Estado.usuario.es_admin) {
    const sucursales = await api.sucursales.listar();
    if (sucursales.length > 1) {
      selectorHTML = `
        <div class="campo" style="max-width:280px; margin-bottom:20px;">
          <label>Filtrar por sucursal (solo administradores)</label>
          <select id="reportes-sucursal">
            <option value="">Todas las sucursales</option>
            ${sucursales.map(s => `<option value="${s.id}">${s.nombre}</option>`).join('')}
          </select>
        </div>
      `;
    }
  } else {
    selectorHTML = `<p style="color:var(--texto-tenue); font-size:.85rem; margin-bottom:16px;">Los reportes muestran únicamente los datos de tu sucursal (${Estado.usuario.sucursal_nombre || 'sin asignar'}).</p>`;
  }

  contenedor.innerHTML = `
    ${selectorHTML}
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr));">
      ${reportes.map(r => `
        <div class="tarjeta tarjeta-pad">
          <h4 style="margin-top:0;">${r.titulo}</h4>
          <p style="font-size:.82rem; color:var(--texto-tenue);">${r.desc}</p>
          <div class="fila gap-8">
            <button class="btn btn-fantasma btn-sm" data-rep="${r.ruta}" data-archivo="${r.archivo}.csv" data-formato="csv">CSV</button>
            <button class="btn btn-fantasma btn-sm" data-rep="${r.ruta}" data-archivo="${r.archivo}.pdf" data-formato="pdf">PDF</button>
          </div>
        </div>
      `).join('')}
    </div>
  `;

  const selectorSucursal = document.getElementById('reportes-sucursal');
  if (selectorSucursal) {
    selectorSucursal.addEventListener('change', (e) => { sucursalSeleccionada = e.target.value; });
  }

  contenedor.querySelectorAll('[data-rep]').forEach(btn => {
    btn.addEventListener('click', () => {
      const ruta = sucursalSeleccionada ? `${btn.dataset.rep}?sucursal_id=${sucursalSeleccionada}` : btn.dataset.rep;
      descargarReporte(ruta, btn.dataset.archivo, btn.dataset.formato);
    });
  });
}

/* ============================================================
   TRANSFERENCIAS DE STOCK ENTRE SUCURSALES
   ============================================================ */
let transferenciasPaginaActual = 1;
let transferenciasFiltroSucursal = '';

async function renderTransferencias(contenedor) {
  const sucursales = await api.sucursales.listar();

  contenedor.innerHTML = `
    <div class="fila entre gap-12" style="margin-bottom:16px; flex-wrap:wrap;">
      <div class="fila gap-8">
        <select id="filtro-sucursal-transf" style="padding:8px 10px; border-radius:8px; border:1px solid var(--borde); background:var(--bg-elevado); color:var(--texto);">
          <option value="">Todas las sucursales</option>
          ${sucursales.map(s => `<option value="${s.id}">${s.nombre}</option>`).join('')}
        </select>
      </div>
      <button class="btn btn-acento" id="btn-nueva-transferencia">+ Nueva transferencia</button>
    </div>
    <div class="tarjeta">
      <table class="tabla">
        <thead><tr><th>Producto</th><th>Origen</th><th>Destino</th><th>Cantidad</th><th>Usuario</th><th>Fecha</th></tr></thead>
        <tbody id="cuerpo-transferencias"><tr><td colspan="6">Cargando…</td></tr></tbody>
      </table>
    </div>
    <div class="fila gap-8" id="paginacion-transferencias" style="justify-content:center; margin-top:16px;"></div>
  `;

  async function recargar() {
    try {
      const resp = await api.sucursales.listarTransferencias({
        sucursal_id: transferenciasFiltroSucursal,
        pagina: transferenciasPaginaActual,
        por_pagina: 15
      });
      const cuerpo = document.getElementById('cuerpo-transferencias');
      cuerpo.innerHTML = resp.transferencias.length ? resp.transferencias.map(t => `
        <tr>
          <td>${t.producto_nombre}${t.codigo ? ` (${t.codigo})` : ''}</td>
          <td>${t.sucursal_origen_nombre}</td>
          <td>${t.sucursal_destino_nombre}</td>
          <td>${t.cantidad}</td>
          <td>${t.usuario_nombre}</td>
          <td>${new Date(t.creado_en).toLocaleString('es-CO')}</td>
        </tr>
      `).join('') : `<tr><td colspan="6" style="text-align:center; color:var(--texto-tenue);">Sin transferencias registradas todavía.</td></tr>`;

      const totalPaginas = Math.max(1, Math.ceil(resp.total / resp.por_pagina));
      const paginacion = document.getElementById('paginacion-transferencias');
      if (totalPaginas > 1) {
        paginacion.innerHTML = `
          <button class="btn btn-fantasma btn-sm" id="btn-pag-anterior" ${transferenciasPaginaActual <= 1 ? 'disabled' : ''}>← Anterior</button>
          <span style="align-self:center; font-size:.85rem; color:var(--texto-tenue);">Página ${transferenciasPaginaActual} de ${totalPaginas}</span>
          <button class="btn btn-fantasma btn-sm" id="btn-pag-siguiente" ${transferenciasPaginaActual >= totalPaginas ? 'disabled' : ''}>Siguiente →</button>
        `;
        document.getElementById('btn-pag-anterior')?.addEventListener('click', () => { transferenciasPaginaActual--; recargar(); });
        document.getElementById('btn-pag-siguiente')?.addEventListener('click', () => { transferenciasPaginaActual++; recargar(); });
      } else {
        paginacion.innerHTML = '';
      }
    } catch (err) { mostrarToast(err.message, 'error'); }
  }

  document.getElementById('filtro-sucursal-transf').addEventListener('change', (e) => {
    transferenciasFiltroSucursal = e.target.value;
    transferenciasPaginaActual = 1;
    recargar();
  });

  document.getElementById('btn-nueva-transferencia').addEventListener('click', async () => {
    if (sucursales.length < 2) return mostrarToast('Necesitas al menos 2 sucursales activas para transferir stock.', 'error');

    let productoSeleccionado = null;

    const fondo = crearModal(`
      <h3>Nueva transferencia de stock</h3>
      <div class="campo">
        <label>Buscar producto</label>
        <input type="search" id="transf-buscador" placeholder="Nombre o código…">
        <div id="transf-resultados" style="max-height:140px; overflow-y:auto;"></div>
      </div>
      <div id="transf-producto-elegido" style="font-size:.85rem; margin-bottom:10px;"></div>
      <div id="transf-stock-actual" style="margin-bottom:10px;"></div>
      <div class="fila gap-12">
        <div class="campo" style="flex:1">
          <label>Sucursal origen</label>
          <select id="transf-origen">${sucursales.map(s => `<option value="${s.id}" ${s.id === Estado.usuario.sucursal_id ? 'selected' : ''}>${s.nombre}</option>`).join('')}</select>
        </div>
        <div class="campo" style="flex:1">
          <label>Sucursal destino</label>
          <select id="transf-destino">${sucursales.map(s => `<option value="${s.id}">${s.nombre}</option>`).join('')}</select>
        </div>
      </div>
      <div class="campo"><label>Cantidad a transferir</label><input type="number" id="transf-cantidad" min="1" value="1"></div>
      <div class="campo"><label>Notas (opcional)</label><input id="transf-notas"></div>
      <div class="fila entre gap-12" style="margin-top:14px;">
        <button type="button" class="btn btn-fantasma" data-cerrar>Cancelar</button>
        <button type="button" class="btn btn-acento" id="btn-confirmar-transferencia">Transferir</button>
      </div>
    `);

    document.getElementById('transf-buscador').addEventListener('input', async (e) => {
      const q = e.target.value;
      const cont = document.getElementById('transf-resultados');
      if (!q) { cont.innerHTML = ''; return; }
      const resp = await api.productos.buscar({ q, por_pagina: 6 });
      cont.innerHTML = resp.productos.map(p => `
        <div class="nav-item" style="color:var(--texto);" data-id="${p.id}" data-nombre="${p.nombre}">${p.nombre}</div>
      `).join('');
      cont.querySelectorAll('[data-id]').forEach(el => {
        el.addEventListener('click', async () => {
          productoSeleccionado = { id: Number(el.dataset.id), nombre: el.dataset.nombre };
          document.getElementById('transf-producto-elegido').innerHTML = `Producto: <strong>${productoSeleccionado.nombre}</strong>`;
          cont.innerHTML = '';
          document.getElementById('transf-buscador').value = '';

          const desglose = await api.sucursales.stockPorProducto(productoSeleccionado.id);
          document.getElementById('transf-stock-actual').innerHTML = `
            <div style="border:1px solid var(--borde); border-radius:8px; padding:8px 12px; font-size:.8rem;">
              ${desglose.map(s => `<div class="fila entre" style="padding:2px 0;"><span>${s.sucursal_nombre}</span><strong>${s.stock}</strong></div>`).join('')}
            </div>
          `;
        });
      });
    });

    document.getElementById('btn-confirmar-transferencia').addEventListener('click', async () => {
      if (!productoSeleccionado) return mostrarToast('Busca y selecciona un producto primero.', 'error');
      const origen = Number(document.getElementById('transf-origen').value);
      const destino = Number(document.getElementById('transf-destino').value);
      const cantidad = Number(document.getElementById('transf-cantidad').value);
      const notas = document.getElementById('transf-notas').value;

      try {
        await api.sucursales.transferir({ producto_id: productoSeleccionado.id, sucursal_origen_id: origen, sucursal_destino_id: destino, cantidad, notas });
        mostrarToast('Transferencia registrada. Stock actualizado en ambas sedes.', 'exito');
        fondo.remove();
        transferenciasPaginaActual = 1;
        recargar();
      } catch (err) { mostrarToast(err.message, 'error'); }
    });
  });

  recargar();
}


async function renderOfertas(contenedor) {
  contenedor.innerHTML = `
    <div class="fila entre gap-12" style="margin-bottom:16px;">
      <input type="search" id="buscador-ofertas" placeholder="Buscar producto para poner en oferta…" style="flex:1; max-width:340px; padding:10px 14px; border-radius:10px; border:1px solid var(--borde); background:var(--bg-elevado); color:var(--texto);">
    </div>
    <div id="resultados-buscar-oferta" class="grid grid-productos" style="margin-bottom:24px;"></div>
    <h3>Productos actualmente en oferta</h3>
    <div id="lista-ofertas" class="grid grid-productos"></div>
  `;

  async function cargarOfertas() {
    const cont = document.getElementById('lista-ofertas');
    cont.innerHTML = `<p style="color:var(--texto-tenue)">Cargando…</p>`;
    const resp = await api.productos.buscar({ en_oferta: 1, por_pagina: 100 });
    cont.innerHTML = resp.productos.length ? resp.productos.map(p => `
      <div class="tarjeta tarjeta-producto" style="cursor:default;">
        <div class="foto" style="${p.imagen_principal ? `background-image:url('${p.imagen_principal}')` : ''}">
          ${!p.imagen_principal ? 'Sin foto' : ''}
          <span class="oferta-tag">OFERTA</span>
        </div>
        <div class="info">
          <h4>${p.nombre}</h4>
          <div class="precio">
            <span style="text-decoration:line-through; color:var(--texto-tenue); font-size:.78rem; font-weight:400;">${formatoCOP(p.precio_detal)}</span>
            ${formatoCOP(p.precio_oferta)}
          </div>
          <button class="btn btn-peligro btn-sm" data-quitar-oferta="${p.id}" style="margin-top:8px; width:100%;">Quitar oferta</button>
        </div>
      </div>
    `).join('') : `<p style="color:var(--texto-tenue); grid-column:1/-1;">No hay productos en oferta todavía. Búscalos arriba para activarla.</p>`;

    cont.querySelectorAll('[data-quitar-oferta]').forEach(btn => {
      btn.addEventListener('click', async () => {
        try {
          await api.productos.actualizar(btn.dataset.quitarOferta, { en_oferta: 0 });
          mostrarToast('Oferta desactivada.', 'exito');
          cargarOfertas();
        } catch (err) { mostrarToast(err.message, 'error'); }
      });
    });
  }

  document.getElementById('buscador-ofertas').addEventListener('input', async (e) => {
    const q = e.target.value;
    const cont = document.getElementById('resultados-buscar-oferta');
    if (!q) { cont.innerHTML = ''; return; }
    const resp = await api.productos.buscar({ q, por_pagina: 8 });
    cont.innerHTML = resp.productos.map(p => `
      <div class="tarjeta tarjeta-pad" style="font-size:.85rem;">
        <strong>${p.nombre}</strong>
        <div style="color:var(--texto-tenue); margin:4px 0;">Precio normal: ${formatoCOP(p.precio_detal)}</div>
        <div class="fila gap-8">
          <input type="number" placeholder="Precio oferta" id="precio-oferta-${p.id}" style="flex:1; padding:6px 8px; border-radius:6px; border:1px solid var(--borde); background:var(--bg); color:var(--texto);">
          <button class="btn btn-acento btn-sm" data-poner-oferta="${p.id}">Activar</button>
        </div>
      </div>
    `).join('') || `<p style="color:var(--texto-tenue); grid-column:1/-1;">Sin resultados.</p>`;

    cont.querySelectorAll('[data-poner-oferta]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const precioOferta = Number(document.getElementById(`precio-oferta-${btn.dataset.ponerOferta}`).value);
        if (!precioOferta || precioOferta <= 0) return mostrarToast('Ingresa un precio de oferta válido.', 'error');
        try {
          await api.productos.actualizar(btn.dataset.ponerOferta, { en_oferta: 1, precio_oferta: precioOferta });
          mostrarToast('Oferta activada.', 'exito');
          document.getElementById('buscador-ofertas').value = '';
          cont.innerHTML = '';
          cargarOfertas();
        } catch (err) { mostrarToast(err.message, 'error'); }
      });
    });
  });

  cargarOfertas();
}

function renderImportador(contenedor) {
  contenedor.innerHTML = `
    <div class="tarjeta tarjeta-pad" style="max-width:720px;">
      <h3 style="margin-top:0;">Importar productos desde Excel o CSV</h3>
      <p style="color:var(--texto-tenue); font-size:.85rem;">
        Columnas admitidas: <code>nombre</code> (obligatoria), <code>codigo</code>, <code>precio_detal</code> (obligatoria),
        <code>precio_mayorista</code>, <code>costo</code>, <code>stock_total</code>, <code>categoria</code>, <code>descripcion</code>.
        Si el <code>codigo</code> ya existe, el producto se actualiza; si no, se crea uno nuevo.
        Acepta archivos <strong>.csv, .xlsx y .xls</strong> directamente — no necesitas convertir tu Excel.
      </p>
      <input type="file" id="input-csv" accept=".csv,.xlsx,.xls">

      <div class="fila gap-12" style="margin-top:14px;">
        <button class="btn btn-fantasma" id="btn-previsualizar">Previsualizar</button>
        <button class="btn btn-acento" id="btn-importar" disabled>Importar productos</button>
      </div>
      <div id="resultado-importacion" style="margin-top:20px;"></div>
    </div>
  `;

  document.getElementById('btn-previsualizar').addEventListener('click', async () => {
    const archivo = document.getElementById('input-csv').files[0];
    if (!archivo) return mostrarToast('Selecciona un archivo CSV primero.', 'error');

    const formData = new FormData();
    formData.append('archivo', archivo);

    const resultadoDiv = document.getElementById('resultado-importacion');
    resultadoDiv.innerHTML = 'Analizando archivo…';

    try {
      const resp = await api.importador.previsualizar(formData);
      resultadoDiv.innerHTML = `
        <div class="fila gap-16" style="margin-bottom:12px;">
          <span class="badge badge-verde">${resp.validas} válidas</span>
          <span class="badge ${resp.invalidas ? 'badge-rojo' : 'badge-verde'}">${resp.invalidas} con errores</span>
          <span style="color:var(--texto-tenue); font-size:.8rem;">Total: ${resp.total} filas</span>
        </div>
        <div style="max-height:280px; overflow:auto;">
          <table class="tabla">
            <thead><tr><th>Fila</th><th>Nombre</th><th>Precio detal</th><th>Acción</th><th>Errores</th></tr></thead>
            <tbody>
              ${resp.filas.map(f => `
                <tr>
                  <td>${f.fila}</td><td>${f.nombre || '—'}</td><td>${f.precio_detal || '—'}</td>
                  <td><span class="badge ${f._accion === 'crear' ? 'badge-verde' : 'badge-ocre'}">${f._accion}</span></td>
                  <td style="color:var(--rojo-600); font-size:.78rem;">${f._errores.join(', ')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
      document.getElementById('btn-importar').disabled = resp.validas === 0;
    } catch (err) {
      resultadoDiv.innerHTML = `<p style="color:var(--rojo-600)">${err.message}</p>`;
    }
  });

  document.getElementById('btn-importar').addEventListener('click', async () => {
    const archivo = document.getElementById('input-csv').files[0];
    const formData = new FormData();
    formData.append('archivo', archivo);
    try {
      const resp = await api.importador.importar(formData);
      mostrarToast(`Importación completa: ${resp.creados} creados, ${resp.actualizados} actualizados.`, 'exito');
      document.getElementById('resultado-importacion').innerHTML = `<p style="color:var(--verde-600)">✔ ${resp.mensaje} — ${resp.creados} creados, ${resp.actualizados} actualizados, ${resp.omitidos} omitidos por errores.</p>`;
    } catch (err) {
      mostrarToast(err.message, 'error');
    }
  });
}
