let carrito = []; // { producto_id, nombre, precio_unitario, cantidad, descuento }
let metodosPagoCache = [];
let impuestosCache = [];
let sesionCajaActual = null;
let cuponAplicado = null; // { id, codigo, tipo, valor }

async function renderPOS(contenedor) {
  contenedor.innerHTML = `
    <div class="pos-layout">
      <div>
        <input type="search" id="buscador-pos" class="pos-buscador" placeholder="Buscar producto por nombre, código o código de barras… (Enter para agregar el primero)"
          style="width:100%; padding:12px 16px; border-radius:10px; border:1px solid var(--borde); background:var(--bg-elevado); color:var(--texto); font-size:1rem;">
        <div id="resultados-pos" class="grid grid-productos"></div>
      </div>
      <div class="tarjeta tarjeta-pad carrito">
        <div id="estado-caja"></div>
        <h3 style="margin-top:14px;">Carrito</h3>
        <div id="carrito-items" class="carrito-items"><p style="color:var(--texto-tenue); font-size:.85rem;">Aún no hay productos agregados.</p></div>

        <div class="fila gap-8" style="margin-bottom:10px;">
          <input type="text" id="input-cupon" placeholder="Código de cupón" style="flex:1; padding:8px 10px; border-radius:8px; border:1px solid var(--borde); background:var(--bg); color:var(--texto); font-size:.82rem;">
          <button class="btn btn-fantasma btn-sm" id="btn-aplicar-cupon">Aplicar</button>
        </div>
        <div id="cupon-estado" style="font-size:.78rem; margin-bottom:8px;"></div>

        <div class="fila entre" style="font-size:.82rem; color:var(--texto-tenue); margin-top:4px;"><span>Subtotal</span><span id="pos-subtotal">${formatoCOP(0)}</span></div>
        <div class="fila entre" style="font-size:.82rem; color:var(--texto-tenue);"><span>Descuento</span><span id="pos-descuento">${formatoCOP(0)}</span></div>
        <div class="fila entre" style="font-size:.82rem; color:var(--texto-tenue);"><span>Impuesto</span><span id="pos-impuesto">${formatoCOP(0)}</span></div>
        <div class="carrito-total"><span>Total</span><span id="carrito-total-valor">${formatoCOP(0)}</span></div>
        <button class="btn btn-acento" id="btn-cobrar" style="width:100%; margin-top:16px;" disabled>Cobrar</button>
      </div>
    </div>
  `;

  await cargarEstadoCaja();
  try { impuestosCache = await api.impuestos.listar(); } catch (_) { impuestosCache = []; }

  const buscador = document.getElementById('buscador-pos');
  let temporizador;
  buscador.addEventListener('input', () => {
    clearTimeout(temporizador);
    temporizador = setTimeout(() => buscarProductosPOS(buscador.value), 300);
  });

  document.getElementById('btn-cobrar').addEventListener('click', abrirModalCobro);
  document.getElementById('btn-aplicar-cupon').addEventListener('click', aplicarCupon);
  renderCarrito();
}

async function cargarEstadoCaja() {
  const contenedor = document.getElementById('estado-caja');
  try {
    sesionCajaActual = await api.caja.actual();
  } catch (_) { sesionCajaActual = null; }

  if (sesionCajaActual) {
    contenedor.innerHTML = `<div class="badge badge-verde">Caja abierta${sesionCajaActual.sucursal_nombre ? ' · ' + sesionCajaActual.sucursal_nombre : ''} · Apertura: ${formatoCOP(sesionCajaActual.monto_apertura)}</div>`;
    document.getElementById('btn-cobrar').disabled = carrito.length === 0;
  } else {
    contenedor.innerHTML = `
      <div class="badge badge-ocre">Caja cerrada</div>
      <button class="btn btn-primario btn-sm" id="btn-abrir-caja" style="width:100%; margin-top:10px;">Abrir caja para vender</button>
    `;
    document.getElementById('btn-cobrar').disabled = true;
    document.getElementById('btn-abrir-caja')?.addEventListener('click', abrirModalAperturaCaja);
  }
}

async function abrirModalAperturaCaja() {
  let sucursales = [];
  try { sucursales = await api.sucursales.listar(); } catch (_) { sucursales = []; }

  const fondo = crearModal(`
    <h3>Apertura de caja</h3>
    <form id="form-apertura">
      ${sucursales.length > 1 ? `
        <div class="campo">
          <label>Sucursal</label>
          <select name="sucursal_id">
            ${sucursales.map(s => `<option value="${s.id}" ${s.id === Estado.usuario.sucursal_id ? 'selected' : ''}>${s.nombre}</option>`).join('')}
          </select>
        </div>
      ` : ''}
      <div class="campo"><label>Monto inicial en efectivo</label><input type="number" name="monto_apertura" value="0" required></div>
      <div class="campo"><label>Notas (opcional)</label><input name="notas"></div>
      <div class="fila entre gap-12" style="margin-top:18px;">
        <button type="button" class="btn btn-fantasma" data-cerrar>Cancelar</button>
        <button type="submit" class="btn btn-primario">Abrir caja</button>
      </div>
    </form>
  `);

  fondo.querySelector('#form-apertura').addEventListener('submit', async (e) => {
    e.preventDefault();
    const datos = Object.fromEntries(new FormData(e.target).entries());
    try {
      await api.caja.abrir({ monto_apertura: Number(datos.monto_apertura), notas: datos.notas, sucursal_id: datos.sucursal_id ? Number(datos.sucursal_id) : undefined });
      mostrarToast('Caja abierta correctamente.', 'exito');
      fondo.remove();
      cargarEstadoCaja();
    } catch (err) { mostrarToast(err.message, 'error'); }
  });
}

async function buscarProductosPOS(q) {
  const contenedor = document.getElementById('resultados-pos');
  if (!q) { contenedor.innerHTML = ''; return; }

  try {
    const resp = await api.productos.buscar({ q, por_pagina: 12 });
    contenedor.innerHTML = resp.productos.map(p => {
      const precioFinal = (p.en_oferta && p.precio_oferta) ? p.precio_oferta : p.precio_detal;
      return `
      <div class="tarjeta tarjeta-producto" data-id="${p.id}" data-nombre="${p.nombre}" data-precio="${precioFinal}">
        <div class="foto" style="${p.imagen_principal ? `background-image:url('${p.imagen_principal}')` : ''}">
          ${!p.imagen_principal ? 'Sin foto' : ''}
          ${p.en_oferta ? '<span class="oferta-tag">OFERTA</span>' : ''}
        </div>
        <div class="info">
          <h4>${p.nombre}</h4>
          <div class="precio">
            ${p.en_oferta && p.precio_oferta ? `<span style="text-decoration:line-through; color:var(--texto-tenue); font-size:.78rem; font-weight:400; margin-right:6px;">${formatoCOP(p.precio_detal)}</span>` : ''}
            ${formatoCOP(precioFinal)}
          </div>
          <div class="stock" style="font-size:.72rem; color:var(--texto-tenue);">Stock: ${p.stock_total}</div>
        </div>
      </div>
    `;
    }).join('') || `<p style="color:var(--texto-tenue);">Sin resultados.</p>`;

    contenedor.querySelectorAll('.tarjeta-producto').forEach(t => {
      t.addEventListener('click', () => agregarAlCarrito({
        producto_id: Number(t.dataset.id), nombre: t.dataset.nombre, precio_unitario: Number(t.dataset.precio)
      }));
    });
  } catch (err) {
    contenedor.innerHTML = `<p style="color:var(--rojo-600)">${err.message}</p>`;
  }
}

function agregarAlCarrito(item) {
  const existente = carrito.find(i => i.producto_id === item.producto_id);
  if (existente) existente.cantidad += 1;
  else carrito.push({ ...item, cantidad: 1, descuento: 0 });
  renderCarrito();
}

async function aplicarCupon() {
  const input = document.getElementById('input-cupon');
  const estado = document.getElementById('cupon-estado');
  const codigo = input.value.trim();
  if (!codigo) return;

  try {
    const cupon = await api.cupones.validar(codigo);
    cuponAplicado = cupon;
    estado.innerHTML = `<span style="color:var(--verde-600);">✔ Cupón "${cupon.codigo}" aplicado (${cupon.tipo === 'porcentaje' ? cupon.valor + '%' : formatoCOP(cupon.valor)})</span>`;
  } catch (err) {
    cuponAplicado = null;
    estado.innerHTML = `<span style="color:var(--rojo-600);">${err.message}</span>`;
  }
  renderCarrito();
}

function calcularTotalesPOS() {
  const subtotal = carrito.reduce((acc, i) => acc + (i.precio_unitario * i.cantidad - i.descuento), 0);

  let descuento = 0;
  if (cuponAplicado) {
    descuento = cuponAplicado.tipo === 'porcentaje' ? subtotal * (cuponAplicado.valor / 100) : Math.min(cuponAplicado.valor, subtotal);
  }

  const impuestoPorDefecto = impuestosCache.find(i => i.por_defecto === 1 && i.activo === 1);
  const baseImponible = subtotal - descuento;
  const impuesto = impuestoPorDefecto ? baseImponible * (impuestoPorDefecto.porcentaje / 100) : 0;

  const total = baseImponible + impuesto;
  return { subtotal, descuento, impuesto, total, impuestoPorDefecto };
}

function renderCarrito() {
  const contenedor = document.getElementById('carrito-items');
  const btnCobrar = document.getElementById('btn-cobrar');
  if (!contenedor) return;

  if (!carrito.length) {
    contenedor.innerHTML = `<p style="color:var(--texto-tenue); font-size:.85rem;">Aún no hay productos agregados.</p>`;
  } else {
    contenedor.innerHTML = carrito.map((item, i) => `
      <div class="carrito-item">
        <div>
          <div class="nombre">${item.nombre}</div>
          <div class="detalle">${formatoCOP(item.precio_unitario)} c/u</div>
        </div>
        <div class="qty-control">
          <button data-accion="restar" data-i="${i}">−</button>
          <span>${item.cantidad}</span>
          <button data-accion="sumar" data-i="${i}">+</button>
          <button data-accion="quitar" data-i="${i}" style="color:var(--rojo-600); border-color:var(--rojo-600);">×</button>
        </div>
      </div>
    `).join('');

    contenedor.querySelectorAll('[data-accion]').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.i);
        if (btn.dataset.accion === 'sumar') carrito[i].cantidad++;
        if (btn.dataset.accion === 'restar') carrito[i].cantidad = Math.max(1, carrito[i].cantidad - 1);
        if (btn.dataset.accion === 'quitar') carrito.splice(i, 1);
        renderCarrito();
      });
    });
  }

  const { subtotal, descuento, impuesto, total } = calcularTotalesPOS();
  document.getElementById('pos-subtotal').textContent = formatoCOP(subtotal);
  document.getElementById('pos-descuento').textContent = `- ${formatoCOP(descuento)}`;
  document.getElementById('pos-impuesto').textContent = formatoCOP(impuesto);
  document.getElementById('carrito-total-valor').textContent = formatoCOP(total);
  if (btnCobrar) btnCobrar.disabled = carrito.length === 0 || !sesionCajaActual;
}

function crearModal(html) {
  const fondo = document.createElement('div');
  fondo.className = 'modal-fondo';
  fondo.innerHTML = `<div class="tarjeta modal-caja">${html}</div>`;
  document.body.appendChild(fondo);
  fondo.querySelectorAll('[data-cerrar]').forEach(b => b.addEventListener('click', () => fondo.remove()));
  fondo.addEventListener('click', (e) => { if (e.target === fondo) fondo.remove(); });
  return fondo;
}

async function abrirModalCobro() {
  if (!metodosPagoCache.length) {
    try { metodosPagoCache = await api.metodosPago.listar(); } catch (_) { metodosPagoCache = []; }
  }
  const { subtotal, descuento, impuesto, total, impuestoPorDefecto } = calcularTotalesPOS();

  const fondo = crearModal(`
    <h3>Cobrar ${formatoCOP(total)}</h3>
    <div style="font-size:.85rem; color:var(--texto-tenue); margin-bottom:14px;">
      <div class="fila entre"><span>Subtotal</span><span>${formatoCOP(subtotal)}</span></div>
      ${descuento > 0 ? `<div class="fila entre"><span>Descuento (${cuponAplicado?.codigo})</span><span>- ${formatoCOP(descuento)}</span></div>` : ''}
      ${impuesto > 0 ? `<div class="fila entre"><span>${impuestoPorDefecto.nombre}</span><span>${formatoCOP(impuesto)}</span></div>` : ''}
    </div>
    <div class="campo">
      <label>Método de pago</label>
      <select id="select-metodo-pago">
        ${metodosPagoCache.map(m => `<option value="${m.id}">${m.nombre}</option>`).join('')}
      </select>
    </div>
    <div class="fila entre gap-12" style="margin-top:18px;">
      <button class="btn btn-fantasma" data-cerrar>Cancelar</button>
      <button class="btn btn-acento" id="btn-confirmar-cobro">Confirmar venta</button>
    </div>
  `);

  fondo.querySelector('#btn-confirmar-cobro').addEventListener('click', async () => {
    const metodoPagoId = Number(document.getElementById('select-metodo-pago').value);
    try {
      const venta = await api.ventas.registrar({
        caja_sesion_id: sesionCajaActual.id,
        tipo_precio: 'detal',
        items: carrito.map(i => ({ producto_id: i.producto_id, cantidad: i.cantidad, precio_unitario: i.precio_unitario, descuento: i.descuento })),
        pagos: [{ metodo_pago_id: metodoPagoId, monto: total }],
        descuento_total: descuento,
        impuesto_total: impuesto,
        cupon_id: cuponAplicado?.id || null
      });
      fondo.remove();
      mostrarFacturaGenerada(venta);
      carrito = [];
      cuponAplicado = null;
      document.getElementById('input-cupon').value = '';
      document.getElementById('cupon-estado').innerHTML = '';
      renderCarrito();
    } catch (err) {
      mostrarToast(err.message, 'error');
    }
  });
}

function mostrarFacturaGenerada(venta) {
  const fondo = crearModal(`
    <h3>Venta registrada · ${venta.numero_factura}</h3>
    <div style="font-size:.85rem; color:var(--texto-tenue); margin-bottom:8px;">
      <div class="fila entre"><span>Subtotal</span><span>${formatoCOP(venta.subtotal)}</span></div>
      ${venta.descuento_total > 0 ? `<div class="fila entre"><span>Descuento</span><span>- ${formatoCOP(venta.descuento_total)}</span></div>` : ''}
      ${venta.impuesto_total > 0 ? `<div class="fila entre"><span>Impuesto</span><span>${formatoCOP(venta.impuesto_total)}</span></div>` : ''}
    </div>
    <p style="font-size:1rem;">Total: <strong>${formatoCOP(venta.total)}</strong></p>
    <div class="fila gap-16" style="justify-content:center; margin:16px 0;">
      <div style="text-align:center;">
        <img src="${venta.qr_factura}" width="130" height="130" style="border-radius:8px;">
        <div style="font-size:.7rem; color:var(--texto-tenue); margin-top:4px;">Datos de factura</div>
      </div>
      <div style="text-align:center;">
        <img src="${venta.qr_sitio_web}" width="130" height="130" style="border-radius:8px;">
        <div style="font-size:.7rem; color:var(--texto-tenue); margin-top:4px;">Sitio web</div>
      </div>
    </div>
    <div class="fila gap-8">
      <button class="btn btn-fantasma" id="btn-imprimir-58">Imprimir 58mm</button>
      <button class="btn btn-fantasma" id="btn-imprimir-80">Imprimir 80mm</button>
    </div>
    <button class="btn btn-primario" data-cerrar style="width:100%; margin-top:10px;">Listo</button>
  `);

  document.getElementById('btn-imprimir-58').addEventListener('click', () => imprimirFacturaTermica(venta, 58));
  document.getElementById('btn-imprimir-80').addEventListener('click', () => imprimirFacturaTermica(venta, 80));
}

/**
 * Abre una ventana con el formato de factura angosto (58mm u 80mm) listo
 * para enviarse a una impresora térmica con el diálogo de impresión del
 * navegador (Ctrl+P / el botón nativo de la impresora térmica USB).
 */
function imprimirFacturaTermica(venta, anchoMM) {
  const ventana = window.open('', '_blank', 'width=400,height=600');
  const filasProductos = (venta.detalle || []).map(d => `
    <tr>
      <td>${d.cantidad}x ${d.producto_nombre}${d.talla ? ` (${d.talla})` : ''}</td>
      <td style="text-align:right;">${formatoCOP(d.subtotal)}</td>
    </tr>
  `).join('');

  ventana.document.write(`
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Factura ${venta.numero_factura}</title>
      <style>
        @page { size: ${anchoMM}mm auto; margin: 2mm; }
        body { width: ${anchoMM}mm; font-family: 'Courier New', monospace; font-size: ${anchoMM === 58 ? '10px' : '11px'}; margin:0; padding:4px; }
        h1 { font-size: ${anchoMM === 58 ? '13px' : '15px'}; text-align:center; margin:4px 0; }
        p { margin:2px 0; text-align:center; }
        hr { border-top: 1px dashed #000; margin:6px 0; }
        table { width:100%; border-collapse:collapse; }
        td { padding:2px 0; vertical-align:top; }
        .total-final { font-size: ${anchoMM === 58 ? '12px' : '14px'}; font-weight:bold; }
        .centro { text-align:center; }
        img { display:block; margin:6px auto; }
      </style>
    </head>
    <body onload="window.print()">
      <h1>TEJIDOS CASTAÑEDA</h1>
      <p>Otanche, Boyacá · Colombia</p>
      <p>Factura: ${venta.numero_factura}</p>
      <p>${new Date(venta.creado_en).toLocaleString('es-CO')}</p>
      <p>Vendedor: ${venta.vendedor_nombre}</p>
      <hr>
      <table>${filasProductos}</table>
      <hr>
      <table>
        <tr><td>Subtotal</td><td style="text-align:right;">${formatoCOP(venta.subtotal)}</td></tr>
        ${venta.descuento_total > 0 ? `<tr><td>Descuento</td><td style="text-align:right;">-${formatoCOP(venta.descuento_total)}</td></tr>` : ''}
        ${venta.impuesto_total > 0 ? `<tr><td>Impuesto</td><td style="text-align:right;">${formatoCOP(venta.impuesto_total)}</td></tr>` : ''}
        <tr class="total-final"><td>TOTAL</td><td style="text-align:right;">${formatoCOP(venta.total)}</td></tr>
      </table>
      <hr>
      <div class="centro"><img src="${venta.qr_factura}" width="${anchoMM === 58 ? 90 : 110}"></div>
      <p>¡Gracias por tu compra!</p>
    </body>
    </html>
  `);
  ventana.document.close();
}
