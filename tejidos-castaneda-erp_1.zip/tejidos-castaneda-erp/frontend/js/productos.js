let paginaProductosActual = 1;

async function renderProductos(contenedor) {
  contenedor.innerHTML = `
    <div class="fila entre barra-productos gap-12">
      <input type="search" id="buscador-productos" placeholder="Buscar por nombre, código, SKU o código de barras…">
      ${tienePermiso('productos.crear') ? '<button class="btn btn-acento" id="btn-nuevo-producto">+ Nuevo producto</button>' : ''}
    </div>
    <div id="grid-productos" class="grid grid-productos"></div>
    <div id="paginacion-productos" class="fila gap-8" style="justify-content:center; margin-top:20px;"></div>
  `;

  const buscador = document.getElementById('buscador-productos');
  let temporizador;
  buscador.addEventListener('input', () => {
    clearTimeout(temporizador);
    temporizador = setTimeout(() => cargarProductos(buscador.value), 350);
  });

  const btnNuevo = document.getElementById('btn-nuevo-producto');
  if (btnNuevo) btnNuevo.addEventListener('click', () => abrirModalProducto());

  cargarProductos();
}

async function cargarProductos(q = '') {
  const grid = document.getElementById('grid-productos');
  grid.innerHTML = `<p style="color:var(--texto-tenue)">Cargando productos…</p>`;

  try {
    const resp = await api.productos.buscar({ q, pagina: paginaProductosActual, por_pagina: 24 });

    if (!resp.productos.length) {
      grid.innerHTML = `<p style="color:var(--texto-tenue); grid-column:1/-1;">No se encontraron productos. ${tienePermiso('productos.crear') ? 'Crea el primero con el botón "+ Nuevo producto".' : ''}</p>`;
      return;
    }

    grid.innerHTML = resp.productos.map(p => `
      <div class="tarjeta tarjeta-producto" data-id="${p.id}">
        <div class="foto" style="${p.imagen_principal ? `background-image:url('${p.imagen_principal}')` : ''}">
          ${!p.imagen_principal ? 'Sin foto' : ''}
          ${p.en_oferta ? '<span class="oferta-tag">OFERTA</span>' : ''}
        </div>
        <div class="info">
          <div class="cat">${p.categoria_nombre || 'Sin categoría'}</div>
          <h4>${p.nombre}</h4>
          <div class="precio">${formatoCOP(p.en_oferta && p.precio_oferta ? p.precio_oferta : p.precio_detal)}</div>
          <div class="stock ${p.stock_total <= p.stock_minimo ? 'badge badge-rojo' : 'badge badge-verde'}" style="display:inline-block; margin-top:6px;">
            Stock: ${p.stock_total}
          </div>
        </div>
      </div>
    `).join('');

    grid.querySelectorAll('.tarjeta-producto').forEach(tarjeta => {
      tarjeta.addEventListener('click', () => abrirModalProducto(tarjeta.dataset.id));
    });
  } catch (err) {
    grid.innerHTML = `<p style="color:var(--rojo-600)">Error al cargar productos: ${err.message}</p>`;
  }
}

async function abrirModalProducto(id = null) {
  let producto = { nombre: '', codigo: '', sku: '', codigo_barras: '', precio_detal: 0, precio_mayorista: 0, costo: 0, stock_total: 0, stock_minimo: 0, descripcion: '', en_oferta: 0, precio_oferta: '' };
  if (id) {
    try { producto = await api.productos.obtener(id); } catch (err) { mostrarToast(err.message, 'error'); return; }
  }

  const fondo = document.createElement('div');
  fondo.className = 'modal-fondo';
  fondo.innerHTML = `
    <div class="tarjeta modal-caja">
      <h3>${id ? 'Editar producto' : 'Nuevo producto'}</h3>
      <form id="form-producto">
        <div class="campo"><label>Nombre</label><input name="nombre" value="${producto.nombre || ''}" required></div>
        <div class="fila gap-12">
          <div class="campo" style="flex:1"><label>Código</label><input name="codigo" value="${producto.codigo || ''}"></div>
          <div class="campo" style="flex:1"><label>SKU</label><input name="sku" value="${producto.sku || ''}"></div>
        </div>
        <div class="campo"><label>Código de barras</label><input name="codigo_barras" value="${producto.codigo_barras || ''}"></div>
        <div class="fila gap-12">
          <div class="campo" style="flex:1"><label>Precio detal</label><input type="number" name="precio_detal" value="${producto.precio_detal || 0}" required></div>
          <div class="campo" style="flex:1"><label>Precio mayorista</label><input type="number" name="precio_mayorista" value="${producto.precio_mayorista || 0}"></div>
        </div>
        <div class="fila gap-12">
          <div class="campo" style="flex:1"><label>Costo</label><input type="number" name="costo" value="${producto.costo || 0}"></div>
          <div class="campo" style="flex:1"><label>Stock inicial</label><input type="number" name="stock_total" value="${producto.stock_total || 0}"></div>
        </div>
        <div class="campo" style="border:1px solid var(--borde); border-radius:10px; padding:12px;">
          <label class="fila gap-8" style="cursor:pointer;">
            <input type="checkbox" name="en_oferta" id="chk-en-oferta" ${producto.en_oferta ? 'checked' : ''}>
            Producto en oferta
          </label>
          <div id="campo-precio-oferta" style="margin-top:10px; ${producto.en_oferta ? '' : 'display:none;'}">
            <label style="font-size:.8rem; font-weight:600; color:var(--texto-suave);">Precio de oferta</label>
            <input type="number" name="precio_oferta" value="${producto.precio_oferta || ''}" style="width:100%; margin-top:4px;">
          </div>
        </div>
        <div class="campo"><label>Descripción</label><textarea name="descripcion" rows="3">${producto.descripcion || ''}</textarea></div>
        ${id ? '<div id="stock-por-sucursal" style="margin-bottom:14px;"></div>' : ''}
        <div class="fila entre gap-12" style="margin-top:18px;">
          <button type="button" class="btn btn-fantasma" id="btn-cerrar-modal">Cancelar</button>
          <button type="submit" class="btn btn-primario">Guardar producto</button>
        </div>
      </form>
    </div>
  `;
  document.body.appendChild(fondo);

  if (id) {
    api.sucursales.stockPorProducto(id).then(desglose => {
      const cont = document.getElementById('stock-por-sucursal');
      if (!cont || !desglose.length) return;
      cont.innerHTML = `
        <label style="font-size:.8rem; font-weight:600; color:var(--texto-suave);">Stock por sucursal</label>
        <div style="border:1px solid var(--borde); border-radius:8px; padding:8px 12px; margin-top:6px;">
          ${desglose.map(s => `<div class="fila entre" style="font-size:.82rem; padding:3px 0;"><span>${s.sucursal_nombre}</span><strong>${s.stock}</strong></div>`).join('')}
        </div>
      `;
    }).catch(() => {});
  }

  fondo.querySelector('#chk-en-oferta').addEventListener('change', (e) => {
    fondo.querySelector('#campo-precio-oferta').style.display = e.target.checked ? '' : 'none';
  });

  fondo.querySelector('#btn-cerrar-modal').addEventListener('click', () => fondo.remove());
  fondo.addEventListener('click', (e) => { if (e.target === fondo) fondo.remove(); });

  fondo.querySelector('#form-producto').addEventListener('submit', async (e) => {
    e.preventDefault();
    const datos = Object.fromEntries(new FormData(e.target).entries());
    datos.en_oferta = fondo.querySelector('#chk-en-oferta').checked ? 1 : 0;
    ['precio_detal', 'precio_mayorista', 'costo', 'stock_total', 'precio_oferta'].forEach(k => datos[k] = Number(datos[k]) || 0);

    try {
      if (id) await api.productos.actualizar(id, datos);
      else await api.productos.crear(datos);
      mostrarToast('Producto guardado correctamente.', 'exito');
      fondo.remove();
      cargarProductos();
    } catch (err) {
      mostrarToast(err.message, 'error');
    }
  });
}
