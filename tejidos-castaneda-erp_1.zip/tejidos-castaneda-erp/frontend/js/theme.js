/**
 * Alterna y persiste el tema claro/oscuro en localStorage.
 * Nota: esto corre en el navegador del cliente final (no en un
 * artifact de Claude.ai), así que localStorage es válido aquí.
 */
(function () {
  const CLAVE = 'tc_tema';
  const body = document.body;

  function aplicarTema(tema) {
    body.setAttribute('data-tema', tema);
    localStorage.setItem(CLAVE, tema);
  }

  const guardado = localStorage.getItem(CLAVE) || 'claro';
  aplicarTema(guardado);

  document.addEventListener('DOMContentLoaded', () => {
    const boton = document.getElementById('btn-tema');
    if (!boton) return;
    boton.addEventListener('click', () => {
      const actual = body.getAttribute('data-tema');
      aplicarTema(actual === 'claro' ? 'oscuro' : 'claro');
    });
  });
})();
